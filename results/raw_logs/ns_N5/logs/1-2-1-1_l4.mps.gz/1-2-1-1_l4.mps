* Signature: 0xaa1b7eac2a07f364
NAME TowerOfLire_M1_OrderPrune
OBJSENSE MAX
ROWS
 N  OBJ
 G  BaseContact_LB
 L  BaseContact_UB
 E  BaseTorque_Linear
 G  DAGSupMin_2
 L  DAGSupMax_2
 L  ForceCap_2_1
 G  PCapLB_2_1
 L  PCapUB_2_1
 G  TCapLB_2_1
 L  TCapUB_2_1
 G  R10     
 L  R11     
 G  R12     
 L  R13     
 L  LayerUB_2_1
 G  LayerLB_2_1
 G  DAGSupMin_3
 L  DAGSupMax_3
 L  ForceCap_3_1
 G  PCapLB_3_1
 L  PCapUB_3_1
 G  TCapLB_3_1
 L  TCapUB_3_1
 G  R23     
 L  R24     
 G  R25     
 L  R26     
 L  LayerUB_3_1
 G  LayerLB_3_1
 L  ForceCap_3_2
 G  PCapLB_3_2
 L  PCapUB_3_2
 G  TCapLB_3_2
 L  TCapUB_3_2
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 L  LayerUB_3_2
 G  LayerLB_3_2
 G  DAGSupMin_4
 L  DAGSupMax_4
 L  ForceCap_4_1
 G  PCapLB_4_1
 L  PCapUB_4_1
 G  TCapLB_4_1
 L  TCapUB_4_1
 G  R47     
 L  R48     
 G  R49     
 L  R50     
 L  LayerUB_4_1
 G  LayerLB_4_1
 L  ForceCap_4_2
 G  PCapLB_4_2
 L  PCapUB_4_2
 G  TCapLB_4_2
 L  TCapUB_4_2
 G  R58     
 L  R59     
 G  R60     
 L  R61     
 L  LayerUB_4_2
 G  LayerLB_4_2
 L  ForceCap_4_3
 G  PCapLB_4_3
 L  PCapUB_4_3
 G  TCapLB_4_3
 L  TCapUB_4_3
 G  R69     
 L  R70     
 G  R71     
 L  R72     
 L  LayerUB_4_3
 G  LayerLB_4_3
 G  DAGSupMin_5
 L  DAGSupMax_5
 L  ForceCap_5_1
 G  PCapLB_5_1
 L  PCapUB_5_1
 G  TCapLB_5_1
 L  TCapUB_5_1
 G  R82     
 L  R83     
 G  R84     
 L  R85     
 L  LayerUB_5_1
 G  LayerLB_5_1
 L  ForceCap_5_2
 G  PCapLB_5_2
 L  PCapUB_5_2
 G  TCapLB_5_2
 L  TCapUB_5_2
 G  R93     
 L  R94     
 G  R95     
 L  R96     
 L  LayerUB_5_2
 G  LayerLB_5_2
 L  ForceCap_5_3
 G  PCapLB_5_3
 L  PCapUB_5_3
 G  TCapLB_5_3
 L  TCapUB_5_3
 G  R104    
 L  R105    
 G  R106    
 L  R107    
 L  LayerUB_5_3
 G  LayerLB_5_3
 L  ForceCap_5_4
 G  PCapLB_5_4
 L  PCapUB_5_4
 G  TCapLB_5_4
 L  TCapUB_5_4
 G  R115    
 L  R116    
 G  R117    
 L  R118    
 L  LayerUB_5_4
 G  LayerLB_5_4
 L  SymLayer_1
 G  R122    
 L  R123    
 G  NonOverlap_1
 L  SymLayer_2
 G  R126    
 L  R127    
 G  NonOverlap_2
 L  SymLayer_3
 G  R130    
 L  R131    
 G  NonOverlap_3
 L  SymLayer_4
 G  R134    
 L  R135    
 G  NonOverlap_4
 E  Global_CoM
 E  ForceBal_1
 E  TorqueBal_1
 E  ForceBal_2
 E  TorqueBal_2
 E  ForceBal_3
 E  TorqueBal_3
 E  ForceBal_4
 E  TorqueBal_4
 E  ForceBal_5
 E  TorqueBal_5
 E  R148    
 E  R149    
 E  R150    
 E  R151    
 E  R152    
 G  S2_Lmin_3
 G  S2_Lmin_5
 E  S2_T21  
 E  S2_T31  
 E  S2_T32  
 G  S2_F21lo
 L  S2_F21hi
 G  S2_F31lo
 L  S2_F31hi
 G  S2_sign2
 L  S2_sign3
 L  TightUp_2
 L  TightDn_2
 L  TightUp_3
 L  TightDn_3
 L  TightUp_4
 L  TightDn_4
 L  TightUp_5
 L  TightDn_5
 E  S4_BaseRightCorner
 G  C2_a    
 G  C2_b    
 L  C2_c    
 L  C2_d    
 L  RB_up_2 
 L  RB_dn_2 
 L  RB_up_3 
 L  RB_dn_3 
 L  RB_up_4 
 L  RB_dn_4 
 L  RB_up_5 
 L  RB_dn_5 
 L  SP_3    
 L  SP_4    
 L  C2L_DeltaUB_2
 G  C2L_a_2 
 G  C2L_b_2 
 L  C2L_c_2 
 L  C2L_d_2 
 L  RM_dom_2
 L  RM_dom_3
 L  RM_dom_1
 G  RM_beats_cutoff
 G  NonSpinal
 E  Bilinear_2_1
 E  Bilinear_3_1
 E  Bilinear_3_2
 E  Bilinear_4_1
 E  Bilinear_4_2
 E  Bilinear_4_3
 E  Bilinear_5_1
 E  Bilinear_5_2
 E  Bilinear_5_3
 E  Bilinear_5_4
COLUMNS
    X_0       OBJ       0
    X_1       BaseContact_LB  -1
    X_1       BaseContact_UB  -1
    X_1       R12       -1
    X_1       R13       -1
    X_1       R25       -1
    X_1       R26       -1
    X_1       R49       -1
    X_1       R50       -1
    X_1       R84       -1
    X_1       R85       -1
    X_1       NonOverlap_1  1
    X_1       Global_CoM  1
    X_1       TorqueBal_1  1
    X_1       R148      -1
    X_1       S2_sign2  -1
    X_1       S2_sign3  -1
    X_1       TightUp_2  -1
    X_1       TightDn_2  1
    X_1       TightUp_3  -1
    X_1       TightDn_3  1
    X_1       TightUp_4  -1
    X_1       TightDn_4  1
    X_1       TightUp_5  -1
    X_1       TightDn_5  1
    X_1       S4_BaseRightCorner  -1
    X_1       C2_a      -1
    X_1       C2_b      -1
    X_1       C2_c      -1
    X_1       C2_d      -1
    X_1       RB_up_2   -1
    X_1       RB_dn_2   1
    X_1       RB_up_3   -1
    X_1       RB_dn_3   1
    X_1       RB_up_4   -1
    X_1       RB_dn_4   1
    X_1       RB_up_5   -1
    X_1       RB_dn_5   1
    X_1       RM_dom_1  1
    X_2       R10       -1
    X_2       R11       -1
    X_2       R36       -1
    X_2       R37       -1
    X_2       R60       -1
    X_2       R61       -1
    X_2       R95       -1
    X_2       R96       -1
    X_2       NonOverlap_1  -1
    X_2       NonOverlap_2  1
    X_2       Global_CoM  1
    X_2       TorqueBal_2  1
    X_2       R149      -1
    X_2       S2_sign2  1
    X_2       TightUp_2  1
    X_2       TightDn_2  -1
    X_2       RB_up_2   1
    X_2       RB_dn_2   -1
    X_2       C2L_DeltaUB_2  1
    X_2       C2L_b_2   -2
    X_2       C2L_c_2   -2
    X_2       RM_dom_2  1
    X_3       R23       -1
    X_3       R24       -1
    X_3       R34       -1
    X_3       R35       -1
    X_3       R71       -1
    X_3       R72       -1
    X_3       R106      -1
    X_3       R107      -1
    X_3       NonOverlap_2  -1
    X_3       NonOverlap_3  1
    X_3       Global_CoM  1
    X_3       TorqueBal_3  1
    X_3       R150      -1
    X_3       S2_sign3  1
    X_3       TightUp_3  1
    X_3       TightDn_3  -1
    X_3       RB_up_3   1
    X_3       RB_dn_3   -1
    X_3       C2L_DeltaUB_2  -1
    X_3       C2L_a_2   -2
    X_3       C2L_d_2   -2
    X_4       R47       -1
    X_4       R48       -1
    X_4       R58       -1
    X_4       R59       -1
    X_4       R69       -1
    X_4       R70       -1
    X_4       R117      -1
    X_4       R118      -1
    X_4       NonOverlap_3  -1
    X_4       NonOverlap_4  1
    X_4       Global_CoM  1
    X_4       TorqueBal_4  1
    X_4       R151      -1
    X_4       TightUp_4  1
    X_4       TightDn_4  -1
    X_4       RB_up_4   1
    X_4       RB_dn_4   -1
    X_4       SP_3      1
    X_4       C2L_a_2   1
    X_4       C2L_b_2   1
    X_4       C2L_c_2   1
    X_4       C2L_d_2   1
    X_4       RM_dom_3  1
    X_5       OBJ       1
    X_5       R82       -1
    X_5       R83       -1
    X_5       R93       -1
    X_5       R94       -1
    X_5       R104      -1
    X_5       R105      -1
    X_5       R115      -1
    X_5       R116      -1
    X_5       NonOverlap_4  -1
    X_5       Global_CoM  1
    X_5       TorqueBal_5  1
    X_5       R152      -1
    X_5       TightUp_5  1
    X_5       TightDn_5  -1
    X_5       RB_up_5   1
    X_5       RB_dn_5   -1
    X_5       SP_4      1
    X_5       C2L_a_2   1
    X_5       C2L_b_2   1
    X_5       C2L_c_2   1
    X_5       C2L_d_2   1
    X_5       RM_dom_2  -1
    X_5       RM_dom_3  -1
    X_5       RM_dom_1  -1
    X_5       RM_beats_cutoff  1
    MARKER    'MARKER'                 'INTORG'
    L_0       OBJ       0
    L_1       LayerUB_2_1  -1
    L_1       LayerLB_2_1  -1
    L_1       LayerUB_3_1  -1
    L_1       LayerLB_3_1  -1
    L_1       LayerUB_4_1  -1
    L_1       LayerLB_4_1  -1
    L_1       LayerUB_5_1  -1
    L_1       LayerLB_5_1  -1
    L_1       SymLayer_1  1
    L_1       R122      -1
    L_1       R123      -1
    L_2       LayerUB_2_1  1
    L_2       LayerLB_2_1  1
    L_2       LayerUB_3_2  -1
    L_2       LayerLB_3_2  -1
    L_2       LayerUB_4_2  -1
    L_2       LayerLB_4_2  -1
    L_2       LayerUB_5_2  -1
    L_2       LayerLB_5_2  -1
    L_2       SymLayer_1  -1
    L_2       R122      1
    L_2       R123      1
    L_2       SymLayer_2  1
    L_2       R126      -1
    L_2       R127      -1
    L_2       TightUp_2  -1
    L_2       TightDn_2  -1
    L_3       LayerUB_3_1  1
    L_3       LayerLB_3_1  1
    L_3       LayerUB_3_2  1
    L_3       LayerLB_3_2  1
    L_3       LayerUB_4_3  -1
    L_3       LayerLB_4_3  -1
    L_3       LayerUB_5_3  -1
    L_3       LayerLB_5_3  -1
    L_3       SymLayer_2  -1
    L_3       R126      1
    L_3       R127      1
    L_3       SymLayer_3  1
    L_3       R130      -1
    L_3       R131      -1
    L_3       S2_Lmin_3  1
    L_3       TightUp_3  -1
    L_3       TightDn_3  -1
    L_4       LayerUB_4_1  1
    L_4       LayerLB_4_1  1
    L_4       LayerUB_4_2  1
    L_4       LayerLB_4_2  1
    L_4       LayerUB_4_3  1
    L_4       LayerLB_4_3  1
    L_4       LayerUB_5_4  -1
    L_4       LayerLB_5_4  -1
    L_4       SymLayer_3  -1
    L_4       R130      1
    L_4       R131      1
    L_4       SymLayer_4  1
    L_4       R134      -1
    L_4       R135      -1
    L_4       TightUp_4  -1
    L_4       TightDn_4  -1
    L_5       LayerUB_5_1  1
    L_5       LayerLB_5_1  1
    L_5       LayerUB_5_2  1
    L_5       LayerLB_5_2  1
    L_5       LayerUB_5_3  1
    L_5       LayerLB_5_3  1
    L_5       LayerUB_5_4  1
    L_5       LayerLB_5_4  1
    L_5       SymLayer_4  -1
    L_5       R134      1
    L_5       R135      1
    L_5       S2_Lmin_5  1
    L_5       TightUp_5  -1
    L_5       TightDn_5  -1
    T_1_0     OBJ       0
    MARKER    'MARKER'                 'INTEND'
    F_1_0     ForceBal_1  -1
    P_1_0     BaseContact_LB  1
    P_1_0     BaseContact_UB  1
    P_1_0     BaseTorque_Linear  -5
    Torque_1_0  BaseTorque_Linear  1
    Torque_1_0  TorqueBal_1  -1
    Torque_1_0  C2_a      1
    Torque_1_0  C2_b      1
    Torque_1_0  C2_c      1
    Torque_1_0  C2_d      1
    MARKER    'MARKER'                 'INTORG'
    T_2_1     DAGSupMin_2  1
    T_2_1     DAGSupMax_2  1
    T_2_1     ForceCap_2_1  -4
    T_2_1     PCapLB_2_1  5
    T_2_1     PCapUB_2_1  -5
    T_2_1     TCapLB_2_1  20
    T_2_1     TCapUB_2_1  -20
    T_2_1     R10       -11
    T_2_1     R11       11
    T_2_1     R12       -11
    T_2_1     R13       11
    T_2_1     LayerUB_2_1  1
    T_2_1     LayerLB_2_1  -1
    T_2_1     S2_T21    1
    MARKER    'MARKER'                 'INTEND'
    F_2_1     ForceCap_2_1  1
    F_2_1     ForceBal_1  1
    F_2_1     ForceBal_2  -1
    F_2_1     S2_F21lo  1
    F_2_1     S2_F21hi  1
    F_2_1     C2_b      -1
    F_2_1     C2_d      -1
    P_2_1     PCapLB_2_1  1
    P_2_1     PCapUB_2_1  1
    P_2_1     R10       1
    P_2_1     R11       1
    P_2_1     R12       1
    P_2_1     R13       1
    P_2_1     S4_BaseRightCorner  1
    P_2_1     C2_a      -1
    P_2_1     C2_b      -3
    P_2_1     C2_c      -3
    P_2_1     C2_d      -1
    Torque_2_1  TCapLB_2_1  1
    Torque_2_1  TCapUB_2_1  1
    Torque_2_1  TorqueBal_1  1
    Torque_2_1  TorqueBal_2  -1
    Torque_2_1  Bilinear_2_1  1
    MARKER    'MARKER'                 'INTORG'
    T_3_1     DAGSupMin_3  1
    T_3_1     DAGSupMax_3  1
    T_3_1     ForceCap_3_1  -3
    T_3_1     PCapLB_3_1  5
    T_3_1     PCapUB_3_1  -5
    T_3_1     TCapLB_3_1  15
    T_3_1     TCapUB_3_1  -15
    T_3_1     R23       -11
    T_3_1     R24       11
    T_3_1     R25       -11
    T_3_1     R26       11
    T_3_1     LayerUB_3_1  2
    T_3_1     LayerLB_3_1  -1
    T_3_1     S2_T31    1
    MARKER    'MARKER'                 'INTEND'
    F_3_1     ForceCap_3_1  1
    F_3_1     ForceBal_1  1
    F_3_1     ForceBal_3  -1
    F_3_1     S2_F31lo  1
    F_3_1     S2_F31hi  1
    P_3_1     PCapLB_3_1  1
    P_3_1     PCapUB_3_1  1
    P_3_1     R23       1
    P_3_1     R24       1
    P_3_1     R25       1
    P_3_1     R26       1
    P_3_1     C2_a      -3
    P_3_1     C2_b      -1
    P_3_1     C2_c      -1
    P_3_1     C2_d      -3
    Torque_3_1  TCapLB_3_1  1
    Torque_3_1  TCapUB_3_1  1
    Torque_3_1  TorqueBal_1  1
    Torque_3_1  TorqueBal_3  -1
    Torque_3_1  Bilinear_3_1  1
    MARKER    'MARKER'                 'INTORG'
    T_3_2     DAGSupMin_3  1
    T_3_2     DAGSupMax_3  1
    T_3_2     ForceCap_3_2  -3
    T_3_2     PCapLB_3_2  5
    T_3_2     PCapUB_3_2  -5
    T_3_2     TCapLB_3_2  15
    T_3_2     TCapUB_3_2  -15
    T_3_2     R34       -11
    T_3_2     R35       11
    T_3_2     R36       -11
    T_3_2     R37       11
    T_3_2     LayerUB_3_2  2
    T_3_2     LayerLB_3_2  -2
    T_3_2     S2_T32    1
    MARKER    'MARKER'                 'INTEND'
    F_3_2     ForceCap_3_2  1
    F_3_2     ForceBal_2  1
    F_3_2     ForceBal_3  -1
    P_3_2     PCapLB_3_2  1
    P_3_2     PCapUB_3_2  1
    P_3_2     R34       1
    P_3_2     R35       1
    P_3_2     R36       1
    P_3_2     R37       1
    Torque_3_2  TCapLB_3_2  1
    Torque_3_2  TCapUB_3_2  1
    Torque_3_2  TorqueBal_2  1
    Torque_3_2  TorqueBal_3  -1
    Torque_3_2  Bilinear_3_2  1
    MARKER    'MARKER'                 'INTORG'
    T_4_1     DAGSupMin_4  1
    T_4_1     DAGSupMax_4  1
    T_4_1     ForceCap_4_1  -2
    T_4_1     PCapLB_4_1  5
    T_4_1     PCapUB_4_1  -5
    T_4_1     TCapLB_4_1  10
    T_4_1     TCapUB_4_1  -10
    T_4_1     R47       -11
    T_4_1     R48       11
    T_4_1     R49       -11
    T_4_1     R50       11
    T_4_1     LayerUB_4_1  3
    T_4_1     LayerLB_4_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_4_1     ForceCap_4_1  1
    F_4_1     ForceBal_1  1
    F_4_1     ForceBal_4  -1
    P_4_1     PCapLB_4_1  1
    P_4_1     PCapUB_4_1  1
    P_4_1     R47       1
    P_4_1     R48       1
    P_4_1     R49       1
    P_4_1     R50       1
    Torque_4_1  TCapLB_4_1  1
    Torque_4_1  TCapUB_4_1  1
    Torque_4_1  TorqueBal_1  1
    Torque_4_1  TorqueBal_4  -1
    Torque_4_1  Bilinear_4_1  1
    MARKER    'MARKER'                 'INTORG'
    T_4_2     DAGSupMin_4  1
    T_4_2     DAGSupMax_4  1
    T_4_2     ForceCap_4_2  -2
    T_4_2     PCapLB_4_2  5
    T_4_2     PCapUB_4_2  -5
    T_4_2     TCapLB_4_2  10
    T_4_2     TCapUB_4_2  -10
    T_4_2     R58       -11
    T_4_2     R59       11
    T_4_2     R60       -11
    T_4_2     R61       11
    T_4_2     LayerUB_4_2  3
    T_4_2     LayerLB_4_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_4_2     ForceCap_4_2  1
    F_4_2     ForceBal_2  1
    F_4_2     ForceBal_4  -1
    F_4_2     C2L_a_2   -1
    F_4_2     C2L_b_2   -2
    F_4_2     C2L_c_2   -1
    F_4_2     C2L_d_2   -2
    P_4_2     PCapLB_4_2  1
    P_4_2     PCapUB_4_2  1
    P_4_2     R58       1
    P_4_2     R59       1
    P_4_2     R60       1
    P_4_2     R61       1
    Torque_4_2  TCapLB_4_2  1
    Torque_4_2  TCapUB_4_2  1
    Torque_4_2  TorqueBal_2  1
    Torque_4_2  TorqueBal_4  -1
    Torque_4_2  Bilinear_4_2  1
    MARKER    'MARKER'                 'INTORG'
    T_4_3     DAGSupMin_4  1
    T_4_3     DAGSupMax_4  1
    T_4_3     ForceCap_4_3  -2
    T_4_3     PCapLB_4_3  5
    T_4_3     PCapUB_4_3  -5
    T_4_3     TCapLB_4_3  10
    T_4_3     TCapUB_4_3  -10
    T_4_3     R69       -11
    T_4_3     R70       11
    T_4_3     R71       -11
    T_4_3     R72       11
    T_4_3     LayerUB_4_3  3
    T_4_3     LayerLB_4_3  -3
    T_4_3     SP_3      -1.1828382068035057e+00
    T_4_3     SP_4      -1.2436186873895179e+00
    T_4_3     NonSpinal  1
    MARKER    'MARKER'                 'INTEND'
    F_4_3     ForceCap_4_3  1
    F_4_3     ForceBal_3  1
    F_4_3     ForceBal_4  -1
    P_4_3     PCapLB_4_3  1
    P_4_3     PCapUB_4_3  1
    P_4_3     R69       1
    P_4_3     R70       1
    P_4_3     R71       1
    P_4_3     R72       1
    Torque_4_3  TCapLB_4_3  1
    Torque_4_3  TCapUB_4_3  1
    Torque_4_3  TorqueBal_3  1
    Torque_4_3  TorqueBal_4  -1
    Torque_4_3  Bilinear_4_3  1
    MARKER    'MARKER'                 'INTORG'
    T_5_1     DAGSupMin_5  1
    T_5_1     DAGSupMax_5  1
    T_5_1     ForceCap_5_1  -1
    T_5_1     PCapLB_5_1  5
    T_5_1     PCapUB_5_1  -5
    T_5_1     TCapLB_5_1  5
    T_5_1     TCapUB_5_1  -5
    T_5_1     R82       -11
    T_5_1     R83       11
    T_5_1     R84       -11
    T_5_1     R85       11
    T_5_1     LayerUB_5_1  4
    T_5_1     LayerLB_5_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_5_1     ForceCap_5_1  1
    F_5_1     ForceBal_1  1
    F_5_1     ForceBal_5  -1
    P_5_1     PCapLB_5_1  1
    P_5_1     PCapUB_5_1  1
    P_5_1     R82       1
    P_5_1     R83       1
    P_5_1     R84       1
    P_5_1     R85       1
    Torque_5_1  TCapLB_5_1  1
    Torque_5_1  TCapUB_5_1  1
    Torque_5_1  TorqueBal_1  1
    Torque_5_1  TorqueBal_5  -1
    Torque_5_1  Bilinear_5_1  1
    MARKER    'MARKER'                 'INTORG'
    T_5_2     DAGSupMin_5  1
    T_5_2     DAGSupMax_5  1
    T_5_2     ForceCap_5_2  -1
    T_5_2     PCapLB_5_2  5
    T_5_2     PCapUB_5_2  -5
    T_5_2     TCapLB_5_2  5
    T_5_2     TCapUB_5_2  -5
    T_5_2     R93       -11
    T_5_2     R94       11
    T_5_2     R95       -11
    T_5_2     R96       11
    T_5_2     LayerUB_5_2  4
    T_5_2     LayerLB_5_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_5_2     ForceCap_5_2  1
    F_5_2     ForceBal_2  1
    F_5_2     ForceBal_5  -1
    P_5_2     PCapLB_5_2  1
    P_5_2     PCapUB_5_2  1
    P_5_2     R93       1
    P_5_2     R94       1
    P_5_2     R95       1
    P_5_2     R96       1
    Torque_5_2  TCapLB_5_2  1
    Torque_5_2  TCapUB_5_2  1
    Torque_5_2  TorqueBal_2  1
    Torque_5_2  TorqueBal_5  -1
    Torque_5_2  Bilinear_5_2  1
    MARKER    'MARKER'                 'INTORG'
    T_5_3     DAGSupMin_5  1
    T_5_3     DAGSupMax_5  1
    T_5_3     ForceCap_5_3  -1
    T_5_3     PCapLB_5_3  5
    T_5_3     PCapUB_5_3  -5
    T_5_3     TCapLB_5_3  5
    T_5_3     TCapUB_5_3  -5
    T_5_3     R104      -11
    T_5_3     R105      11
    T_5_3     R106      -11
    T_5_3     R107      11
    T_5_3     LayerUB_5_3  4
    T_5_3     LayerLB_5_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_5_3     ForceCap_5_3  1
    F_5_3     ForceBal_3  1
    F_5_3     ForceBal_5  -1
    P_5_3     PCapLB_5_3  1
    P_5_3     PCapUB_5_3  1
    P_5_3     R104      1
    P_5_3     R105      1
    P_5_3     R106      1
    P_5_3     R107      1
    Torque_5_3  TCapLB_5_3  1
    Torque_5_3  TCapUB_5_3  1
    Torque_5_3  TorqueBal_3  1
    Torque_5_3  TorqueBal_5  -1
    Torque_5_3  Bilinear_5_3  1
    MARKER    'MARKER'                 'INTORG'
    T_5_4     DAGSupMin_5  1
    T_5_4     DAGSupMax_5  1
    T_5_4     ForceCap_5_4  -1
    T_5_4     PCapLB_5_4  5
    T_5_4     PCapUB_5_4  -5
    T_5_4     TCapLB_5_4  5
    T_5_4     TCapUB_5_4  -5
    T_5_4     R115      -11
    T_5_4     R116      11
    T_5_4     R117      -11
    T_5_4     R118      11
    T_5_4     LayerUB_5_4  4
    T_5_4     LayerLB_5_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_5_4     ForceCap_5_4  1
    F_5_4     ForceBal_4  1
    F_5_4     ForceBal_5  -1
    P_5_4     PCapLB_5_4  1
    P_5_4     PCapUB_5_4  1
    P_5_4     R115      1
    P_5_4     R116      1
    P_5_4     R117      1
    P_5_4     R118      1
    Torque_5_4  TCapLB_5_4  1
    Torque_5_4  TCapUB_5_4  1
    Torque_5_4  TorqueBal_4  1
    Torque_5_4  TorqueBal_5  -1
    Torque_5_4  Bilinear_5_4  1
    MARKER    'MARKER'                 'INTORG'
    LayerJump_1  R122      -1
    LayerJump_1  R123      -1
    LayerJump_1  NonOverlap_1  11
    LayerJump_2  R126      -1
    LayerJump_2  R127      -2
    LayerJump_2  NonOverlap_2  11
    LayerJump_2  S2_Lmin_3  -1
    LayerJump_2  S2_Lmin_5  -1
    LayerJump_2  S2_T31    1
    LayerJump_2  S2_T32    -1
    LayerJump_2  S2_F21lo  -3
    LayerJump_2  S2_F21hi  -1
    LayerJump_2  S2_F31lo  1
    LayerJump_2  S2_F31hi  3
    LayerJump_2  S2_sign2  1
    LayerJump_2  S2_sign3  -2
    LayerJump_3  R130      -1
    LayerJump_3  R131      -3
    LayerJump_3  NonOverlap_3  11
    LayerJump_4  R134      -1
    LayerJump_4  R135      -4
    LayerJump_4  NonOverlap_4  11
    MARKER    'MARKER'                 'INTEND'
    RE_1      R148      1
    RE_2      R149      1
    RE_3      R150      1
    RE_4      R151      1
    RE_5      R152      1
    max_overhang  OBJ       0
RHS
    RHS1      OBJ       -0.5
    RHS1      BaseContact_LB  -0.5
    RHS1      BaseContact_UB  0.5
    RHS1      DAGSupMin_2  1
    RHS1      DAGSupMax_2  3
    RHS1      R10       -11.5
    RHS1      R11       11.5
    RHS1      R12       -11.5
    RHS1      R13       11.5
    RHS1      LayerUB_2_1  2
    RHS1      DAGSupMin_3  1
    RHS1      DAGSupMax_3  3
    RHS1      R23       -11.5
    RHS1      R24       11.5
    RHS1      R25       -11.5
    RHS1      R26       11.5
    RHS1      LayerUB_3_1  3
    RHS1      R34       -11.5
    RHS1      R35       11.5
    RHS1      R36       -11.5
    RHS1      R37       11.5
    RHS1      LayerUB_3_2  3
    RHS1      LayerLB_3_2  -1
    RHS1      DAGSupMin_4  1
    RHS1      DAGSupMax_4  3
    RHS1      R47       -11.5
    RHS1      R48       11.5
    RHS1      R49       -11.5
    RHS1      R50       11.5
    RHS1      LayerUB_4_1  4
    RHS1      R58       -11.5
    RHS1      R59       11.5
    RHS1      R60       -11.5
    RHS1      R61       11.5
    RHS1      LayerUB_4_2  4
    RHS1      LayerLB_4_2  -1
    RHS1      R69       -11.5
    RHS1      R70       11.5
    RHS1      R71       -11.5
    RHS1      R72       11.5
    RHS1      LayerUB_4_3  4
    RHS1      LayerLB_4_3  -2
    RHS1      DAGSupMin_5  1
    RHS1      DAGSupMax_5  3
    RHS1      R82       -11.5
    RHS1      R83       11.5
    RHS1      R84       -11.5
    RHS1      R85       11.5
    RHS1      LayerUB_5_1  5
    RHS1      R93       -11.5
    RHS1      R94       11.5
    RHS1      R95       -11.5
    RHS1      R96       11.5
    RHS1      LayerUB_5_2  5
    RHS1      LayerLB_5_2  -1
    RHS1      R104      -11.5
    RHS1      R105      11.5
    RHS1      R106      -11.5
    RHS1      R107      11.5
    RHS1      LayerUB_5_3  5
    RHS1      LayerLB_5_3  -2
    RHS1      R115      -11.5
    RHS1      R116      11.5
    RHS1      R117      -11.5
    RHS1      R118      11.5
    RHS1      LayerUB_5_4  5
    RHS1      LayerLB_5_4  -3
    RHS1      NonOverlap_1  1
    RHS1      NonOverlap_2  1
    RHS1      NonOverlap_3  1
    RHS1      NonOverlap_4  1
    RHS1      ForceBal_1  -1
    RHS1      ForceBal_2  -1
    RHS1      ForceBal_3  -1
    RHS1      ForceBal_4  -1
    RHS1      ForceBal_5  -1
    RHS1      R148      0.5
    RHS1      R149      0.5
    RHS1      R150      0.5
    RHS1      R151      0.5
    RHS1      R152      0.5
    RHS1      S2_Lmin_3  2
    RHS1      S2_Lmin_5  3
    RHS1      S2_T21    1
    RHS1      S2_T31    1
    RHS1      S2_F21lo  1
    RHS1      S2_F21hi  3
    RHS1      S2_F31lo  1
    RHS1      S2_F31hi  3
    RHS1      TightUp_2  -1
    RHS1      TightDn_2  -1
    RHS1      TightUp_3  -1
    RHS1      TightDn_3  -1
    RHS1      TightUp_4  -1
    RHS1      TightDn_4  -1
    RHS1      TightUp_5  -1
    RHS1      TightDn_5  -1
    RHS1      S4_BaseRightCorner  0.5
    RHS1      C2_b      -3
    RHS1      C2_d      -1
    RHS1      RB_up_2   1
    RHS1      RB_dn_3   1
    RHS1      RB_up_4   2
    RHS1      RB_dn_4   2
    RHS1      RB_up_5   3
    RHS1      RB_dn_5   3
    RHS1      SP_3      8.1716179319649429e-01
    RHS1      SP_4      7.5638131261048214e-01
    RHS1      C2L_DeltaUB_2  2
    RHS1      C2L_a_2   -1
    RHS1      C2L_b_2   -5
    RHS1      C2L_c_2   -1
    RHS1      C2L_d_2   1
    RHS1      RM_beats_cutoff  8.0399017427452923e-01
    RHS1      NonSpinal  1
BOUNDS
 FX BND1      X_0       0
 LO BND1      X_1       -0.5
 UP BND1      X_1       0.2
 LO BND1      X_2       -0.5
 UP BND1      X_2       7.6754446896632422e-01
 LO BND1      X_3       -1.5
 UP BND1      X_3       0.2
 LO BND1      X_4       -1.9600982572547077e-01
 UP BND1      X_4       2
 LO BND1      X_5       8.0399017427452923e-01
 UP BND1      X_5       2
 FX BND1      L_0       0
 FX BND1      L_1       1
 FX BND1      L_2       2
 FX BND1      L_3       2
 FX BND1      L_4       3
 FX BND1      L_5       4
 FX BND1      T_1_0     1
 BV BND1      T_1_0   
 FX BND1      F_1_0     5
 FX BND1      P_1_0     0
 LO BND1      Torque_1_0  -5
 UP BND1      Torque_1_0  0
 FX BND1      T_2_1     1
 BV BND1      T_2_1   
 UP BND1      F_2_1     3
 UP BND1      P_2_1     0.7
 UP BND1      Torque_2_1  2.0999999999999996e+00
 FX BND1      T_3_1     1
 BV BND1      T_3_1   
 UP BND1      F_3_1     3
 LO BND1      P_3_1     -1
 UP BND1      P_3_1     0.7
 LO BND1      Torque_3_1  -3
 UP BND1      Torque_3_1  2.0999999999999996e+00
 FX BND1      T_3_2     0
 BV BND1      T_3_2   
 FX BND1      F_3_2     0
 FX BND1      P_3_2     0
 FX BND1      Torque_3_2  0
 FX BND1      T_4_1     0
 BV BND1      T_4_1   
 FX BND1      F_4_1     0
 FX BND1      P_4_1     0
 FX BND1      Torque_4_1  0
 BV BND1      T_4_2   
 UP BND1      F_4_2     2
 LO BND1      P_4_2     -6.9600982572547077e-01
 UP BND1      P_4_2     1.2675444689663242e+00
 LO BND1      Torque_4_2  -1.3920196514509415e+00
 UP BND1      Torque_4_2  2.5350889379326484e+00
 BV BND1      T_4_3   
 UP BND1      F_4_3     2
 LO BND1      P_4_3     -6.9600982572547077e-01
 UP BND1      P_4_3     0.7
 LO BND1      Torque_4_3  -1.3920196514509415e+00
 UP BND1      Torque_4_3  1.4
 FX BND1      T_5_1     0
 BV BND1      T_5_1   
 FX BND1      F_5_1     0
 FX BND1      P_5_1     0
 FX BND1      Torque_5_1  0
 FX BND1      T_5_2     0
 BV BND1      T_5_2   
 FX BND1      F_5_2     0
 FX BND1      P_5_2     0
 FX BND1      Torque_5_2  0
 FX BND1      T_5_3     0
 BV BND1      T_5_3   
 FX BND1      F_5_3     0
 FX BND1      P_5_3     0
 FX BND1      Torque_5_3  0
 FX BND1      T_5_4     1
 BV BND1      T_5_4   
 FX BND1      F_5_4     1
 LO BND1      P_5_4     3.0399017427452923e-01
 UP BND1      P_5_4     2.5
 LO BND1      Torque_5_4  3.0399017427452923e-01
 UP BND1      Torque_5_4  2.5
 FX BND1      LayerJump_1  1
 BV BND1      LayerJump_1
 FX BND1      LayerJump_2  0
 BV BND1      LayerJump_2
 FX BND1      LayerJump_3  1
 BV BND1      LayerJump_3
 FX BND1      LayerJump_4  1
 BV BND1      LayerJump_4
 LO BND1      RE_1      -5
 UP BND1      RE_1      5
 LO BND1      RE_2      -5
 UP BND1      RE_2      5
 LO BND1      RE_3      -5
 UP BND1      RE_3      5
 LO BND1      RE_4      -5
 UP BND1      RE_4      5
 LO BND1      RE_5      -5
 UP BND1      RE_5      5
 LO BND1      max_overhang  0.5
 UP BND1      max_overhang  5
QCMATRIX   Bilinear_2_1
    F_2_1     P_2_1     -0.5
    P_2_1     F_2_1     -0.5
QCMATRIX   Bilinear_3_1
    F_3_1     P_3_1     -0.5
    P_3_1     F_3_1     -0.5
QCMATRIX   Bilinear_3_2
    F_3_2     P_3_2     -0.5
    P_3_2     F_3_2     -0.5
QCMATRIX   Bilinear_4_1
    F_4_1     P_4_1     -0.5
    P_4_1     F_4_1     -0.5
QCMATRIX   Bilinear_4_2
    F_4_2     P_4_2     -0.5
    P_4_2     F_4_2     -0.5
QCMATRIX   Bilinear_4_3
    F_4_3     P_4_3     -0.5
    P_4_3     F_4_3     -0.5
QCMATRIX   Bilinear_5_1
    F_5_1     P_5_1     -0.5
    P_5_1     F_5_1     -0.5
QCMATRIX   Bilinear_5_2
    F_5_2     P_5_2     -0.5
    P_5_2     F_5_2     -0.5
QCMATRIX   Bilinear_5_3
    F_5_3     P_5_3     -0.5
    P_5_3     F_5_3     -0.5
QCMATRIX   Bilinear_5_4
    F_5_4     P_5_4     -0.5
    P_5_4     F_5_4     -0.5
ENDATA
