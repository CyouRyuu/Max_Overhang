* Signature: 0xc1d84907976f0790
NAME TowerOfLire_M1_OrderPrune
OBJSENSE MAX
ROWS
 N  OBJ
 G  BaseContact_LB
 L  BaseContact_UB
 E  BaseTorque_Linear
 G  DAGSupMin_2
 L  DAGSupMax_2
 L  ForceCap_2_1
 G  PCapLB_2_1
 L  PCapUB_2_1
 G  TCapLB_2_1
 L  TCapUB_2_1
 G  R10     
 L  R11     
 G  R12     
 L  R13     
 L  LayerUB_2_1
 G  LayerLB_2_1
 G  DAGSupMin_3
 L  DAGSupMax_3
 L  ForceCap_3_1
 G  PCapLB_3_1
 L  PCapUB_3_1
 G  TCapLB_3_1
 L  TCapUB_3_1
 G  R23     
 L  R24     
 G  R25     
 L  R26     
 L  LayerUB_3_1
 G  LayerLB_3_1
 L  ForceCap_3_2
 G  PCapLB_3_2
 L  PCapUB_3_2
 G  TCapLB_3_2
 L  TCapUB_3_2
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 L  LayerUB_3_2
 G  LayerLB_3_2
 G  DAGSupMin_4
 L  DAGSupMax_4
 L  ForceCap_4_1
 G  PCapLB_4_1
 L  PCapUB_4_1
 G  TCapLB_4_1
 L  TCapUB_4_1
 G  R47     
 L  R48     
 G  R49     
 L  R50     
 L  LayerUB_4_1
 G  LayerLB_4_1
 L  ForceCap_4_2
 G  PCapLB_4_2
 L  PCapUB_4_2
 G  TCapLB_4_2
 L  TCapUB_4_2
 G  R58     
 L  R59     
 G  R60     
 L  R61     
 L  LayerUB_4_2
 G  LayerLB_4_2
 L  ForceCap_4_3
 G  PCapLB_4_3
 L  PCapUB_4_3
 G  TCapLB_4_3
 L  TCapUB_4_3
 G  R69     
 L  R70     
 G  R71     
 L  R72     
 L  LayerUB_4_3
 G  LayerLB_4_3
 G  DAGSupMin_5
 L  DAGSupMax_5
 L  ForceCap_5_1
 G  PCapLB_5_1
 L  PCapUB_5_1
 G  TCapLB_5_1
 L  TCapUB_5_1
 G  R82     
 L  R83     
 G  R84     
 L  R85     
 L  LayerUB_5_1
 G  LayerLB_5_1
 L  ForceCap_5_2
 G  PCapLB_5_2
 L  PCapUB_5_2
 G  TCapLB_5_2
 L  TCapUB_5_2
 G  R93     
 L  R94     
 G  R95     
 L  R96     
 L  LayerUB_5_2
 G  LayerLB_5_2
 L  ForceCap_5_3
 G  PCapLB_5_3
 L  PCapUB_5_3
 G  TCapLB_5_3
 L  TCapUB_5_3
 G  R104    
 L  R105    
 G  R106    
 L  R107    
 L  LayerUB_5_3
 G  LayerLB_5_3
 L  ForceCap_5_4
 G  PCapLB_5_4
 L  PCapUB_5_4
 G  TCapLB_5_4
 L  TCapUB_5_4
 G  R115    
 L  R116    
 G  R117    
 L  R118    
 L  LayerUB_5_4
 G  LayerLB_5_4
 G  DAGSupMin_6
 L  DAGSupMax_6
 L  ForceCap_6_1
 G  PCapLB_6_1
 L  PCapUB_6_1
 G  TCapLB_6_1
 L  TCapUB_6_1
 G  R128    
 L  R129    
 G  R130    
 L  R131    
 L  LayerUB_6_1
 G  LayerLB_6_1
 L  ForceCap_6_2
 G  PCapLB_6_2
 L  PCapUB_6_2
 G  TCapLB_6_2
 L  TCapUB_6_2
 G  R139    
 L  R140    
 G  R141    
 L  R142    
 L  LayerUB_6_2
 G  LayerLB_6_2
 L  ForceCap_6_3
 G  PCapLB_6_3
 L  PCapUB_6_3
 G  TCapLB_6_3
 L  TCapUB_6_3
 G  R150    
 L  R151    
 G  R152    
 L  R153    
 L  LayerUB_6_3
 G  LayerLB_6_3
 L  ForceCap_6_4
 G  PCapLB_6_4
 L  PCapUB_6_4
 G  TCapLB_6_4
 L  TCapUB_6_4
 G  R161    
 L  R162    
 G  R163    
 L  R164    
 L  LayerUB_6_4
 G  LayerLB_6_4
 L  ForceCap_6_5
 G  PCapLB_6_5
 L  PCapUB_6_5
 G  TCapLB_6_5
 L  TCapUB_6_5
 G  R172    
 L  R173    
 G  R174    
 L  R175    
 L  LayerUB_6_5
 G  LayerLB_6_5
 G  DAGSupMin_7
 L  DAGSupMax_7
 L  ForceCap_7_1
 G  PCapLB_7_1
 L  PCapUB_7_1
 G  TCapLB_7_1
 L  TCapUB_7_1
 G  R185    
 L  R186    
 G  R187    
 L  R188    
 L  LayerUB_7_1
 G  LayerLB_7_1
 L  ForceCap_7_2
 G  PCapLB_7_2
 L  PCapUB_7_2
 G  TCapLB_7_2
 L  TCapUB_7_2
 G  R196    
 L  R197    
 G  R198    
 L  R199    
 L  LayerUB_7_2
 G  LayerLB_7_2
 L  ForceCap_7_3
 G  PCapLB_7_3
 L  PCapUB_7_3
 G  TCapLB_7_3
 L  TCapUB_7_3
 G  R207    
 L  R208    
 G  R209    
 L  R210    
 L  LayerUB_7_3
 G  LayerLB_7_3
 L  ForceCap_7_4
 G  PCapLB_7_4
 L  PCapUB_7_4
 G  TCapLB_7_4
 L  TCapUB_7_4
 G  R218    
 L  R219    
 G  R220    
 L  R221    
 L  LayerUB_7_4
 G  LayerLB_7_4
 L  ForceCap_7_5
 G  PCapLB_7_5
 L  PCapUB_7_5
 G  TCapLB_7_5
 L  TCapUB_7_5
 G  R229    
 L  R230    
 G  R231    
 L  R232    
 L  LayerUB_7_5
 G  LayerLB_7_5
 L  ForceCap_7_6
 G  PCapLB_7_6
 L  PCapUB_7_6
 G  TCapLB_7_6
 L  TCapUB_7_6
 G  R240    
 L  R241    
 G  R242    
 L  R243    
 L  LayerUB_7_6
 G  LayerLB_7_6
 L  SymLayer_1
 G  R247    
 L  R248    
 G  NonOverlap_1
 L  SymLayer_2
 G  R251    
 L  R252    
 G  NonOverlap_2
 L  SymLayer_3
 G  R255    
 L  R256    
 G  NonOverlap_3
 L  SymLayer_4
 G  R259    
 L  R260    
 G  NonOverlap_4
 L  SymLayer_5
 G  R263    
 L  R264    
 G  NonOverlap_5
 L  SymLayer_6
 G  R267    
 L  R268    
 G  NonOverlap_6
 E  Global_CoM
 E  ForceBal_1
 E  TorqueBal_1
 E  ForceBal_2
 E  TorqueBal_2
 E  ForceBal_3
 E  TorqueBal_3
 E  ForceBal_4
 E  TorqueBal_4
 E  ForceBal_5
 E  TorqueBal_5
 E  ForceBal_6
 E  TorqueBal_6
 E  ForceBal_7
 E  TorqueBal_7
 E  R285    
 E  R286    
 E  R287    
 E  R288    
 E  R289    
 E  R290    
 E  R291    
 G  S2_Lmin_3
 G  S2_Lmin_5
 G  S2_Lmin_6
 G  S2_Lmin_7
 E  S2_T21  
 E  S2_T31  
 E  S2_T32  
 G  S2_F21lo
 L  S2_F21hi
 G  S2_F31lo
 L  S2_F31hi
 G  S2_sign2
 L  S2_sign3
 L  TightUp_2
 L  TightDn_2
 L  TightUp_3
 L  TightDn_3
 L  TightUp_4
 L  TightDn_4
 L  TightUp_5
 L  TightDn_5
 L  TightUp_6
 L  TightDn_6
 L  TightUp_7
 L  TightDn_7
 E  S4_BaseRightCorner
 G  C2_a    
 G  C2_b    
 L  C2_c    
 L  C2_d    
 L  RB_up_2 
 L  RB_dn_2 
 L  RB_up_3 
 L  RB_dn_3 
 L  RB_up_4 
 L  RB_dn_4 
 L  RB_up_5 
 L  RB_dn_5 
 L  RB_up_6 
 L  RB_dn_6 
 L  RB_up_7 
 L  RB_dn_7 
 L  SP_3    
 L  SP_4    
 L  SP_5    
 L  C2L_DeltaUB_2
 G  C2L_a_2 
 G  C2L_b_2 
 L  C2L_c_2 
 L  C2L_d_2 
 L  C2L_DeltaUB_3
 G  C2L_a_3 
 G  C2L_b_3 
 L  C2L_c_3 
 L  C2L_d_3 
 L  RM_dom_2
 L  RM_dom_3
 L  RM_dom_5
 L  RM_dom_1
 G  RM_beats_cutoff
 G  NonSpinal
 E  Bilinear_2_1
 E  Bilinear_3_1
 E  Bilinear_3_2
 E  Bilinear_4_1
 E  Bilinear_4_2
 E  Bilinear_4_3
 E  Bilinear_5_1
 E  Bilinear_5_2
 E  Bilinear_5_3
 E  Bilinear_5_4
 E  Bilinear_6_1
 E  Bilinear_6_2
 E  Bilinear_6_3
 E  Bilinear_6_4
 E  Bilinear_6_5
 E  Bilinear_7_1
 E  Bilinear_7_2
 E  Bilinear_7_3
 E  Bilinear_7_4
 E  Bilinear_7_5
 E  Bilinear_7_6
COLUMNS
    X_0       OBJ       0
    X_1       BaseContact_LB  -1
    X_1       BaseContact_UB  -1
    X_1       R12       -1
    X_1       R13       -1
    X_1       R25       -1
    X_1       R26       -1
    X_1       R49       -1
    X_1       R50       -1
    X_1       R84       -1
    X_1       R85       -1
    X_1       R130      -1
    X_1       R131      -1
    X_1       R187      -1
    X_1       R188      -1
    X_1       NonOverlap_1  1
    X_1       Global_CoM  1
    X_1       TorqueBal_1  1
    X_1       R285      -1
    X_1       S2_sign2  -1
    X_1       S2_sign3  -1
    X_1       TightUp_2  -1
    X_1       TightDn_2  1
    X_1       TightUp_3  -1
    X_1       TightDn_3  1
    X_1       TightUp_4  -1
    X_1       TightDn_4  1
    X_1       TightUp_5  -1
    X_1       TightDn_5  1
    X_1       TightUp_6  -1
    X_1       TightDn_6  1
    X_1       TightUp_7  -1
    X_1       TightDn_7  1
    X_1       S4_BaseRightCorner  -1
    X_1       C2_a      -1
    X_1       C2_b      -1
    X_1       C2_c      -1
    X_1       C2_d      -1
    X_1       RB_up_2   -1
    X_1       RB_dn_2   1
    X_1       RB_up_3   -1
    X_1       RB_dn_3   1
    X_1       RB_up_4   -1
    X_1       RB_dn_4   1
    X_1       RB_up_5   -1
    X_1       RB_dn_5   1
    X_1       RB_up_6   -1
    X_1       RB_dn_6   1
    X_1       RB_up_7   -1
    X_1       RB_dn_7   1
    X_1       RM_dom_1  1
    X_2       R10       -1
    X_2       R11       -1
    X_2       R36       -1
    X_2       R37       -1
    X_2       R60       -1
    X_2       R61       -1
    X_2       R95       -1
    X_2       R96       -1
    X_2       R141      -1
    X_2       R142      -1
    X_2       R198      -1
    X_2       R199      -1
    X_2       NonOverlap_1  -1
    X_2       NonOverlap_2  1
    X_2       Global_CoM  1
    X_2       TorqueBal_2  1
    X_2       R286      -1
    X_2       S2_sign2  1
    X_2       TightUp_2  1
    X_2       TightDn_2  -1
    X_2       RB_up_2   1
    X_2       RB_dn_2   -1
    X_2       C2L_DeltaUB_2  1
    X_2       C2L_b_2   -4
    X_2       C2L_c_2   -4
    X_2       RM_dom_2  1
    X_3       R23       -1
    X_3       R24       -1
    X_3       R34       -1
    X_3       R35       -1
    X_3       R71       -1
    X_3       R72       -1
    X_3       R106      -1
    X_3       R107      -1
    X_3       R152      -1
    X_3       R153      -1
    X_3       R209      -1
    X_3       R210      -1
    X_3       NonOverlap_2  -1
    X_3       NonOverlap_3  1
    X_3       Global_CoM  1
    X_3       TorqueBal_3  1
    X_3       R287      -1
    X_3       S2_sign3  1
    X_3       TightUp_3  1
    X_3       TightDn_3  -1
    X_3       RB_up_3   1
    X_3       RB_dn_3   -1
    X_3       C2L_DeltaUB_2  -1
    X_3       C2L_a_2   -4
    X_3       C2L_d_2   -4
    X_4       R47       -1
    X_4       R48       -1
    X_4       R58       -1
    X_4       R59       -1
    X_4       R69       -1
    X_4       R70       -1
    X_4       R117      -1
    X_4       R118      -1
    X_4       R163      -1
    X_4       R164      -1
    X_4       R220      -1
    X_4       R221      -1
    X_4       NonOverlap_3  -1
    X_4       NonOverlap_4  1
    X_4       Global_CoM  1
    X_4       TorqueBal_4  1
    X_4       R288      -1
    X_4       TightUp_4  1
    X_4       TightDn_4  -1
    X_4       RB_up_4   1
    X_4       RB_dn_4   -1
    X_4       SP_3      1
    X_4       C2L_a_2   1
    X_4       C2L_b_2   1
    X_4       C2L_c_2   1
    X_4       C2L_d_2   1
    X_4       C2L_DeltaUB_3  1
    X_4       C2L_b_3   -2
    X_4       C2L_c_3   -2
    X_4       RM_dom_3  1
    X_5       R82       -1
    X_5       R83       -1
    X_5       R93       -1
    X_5       R94       -1
    X_5       R104      -1
    X_5       R105      -1
    X_5       R115      -1
    X_5       R116      -1
    X_5       R174      -1
    X_5       R175      -1
    X_5       R231      -1
    X_5       R232      -1
    X_5       NonOverlap_4  -1
    X_5       NonOverlap_5  1
    X_5       Global_CoM  1
    X_5       TorqueBal_5  1
    X_5       R289      -1
    X_5       TightUp_5  1
    X_5       TightDn_5  -1
    X_5       RB_up_5   1
    X_5       RB_dn_5   -1
    X_5       C2L_a_2   1
    X_5       C2L_b_2   1
    X_5       C2L_c_2   1
    X_5       C2L_d_2   1
    X_5       C2L_DeltaUB_3  -1
    X_5       C2L_a_3   -2
    X_5       C2L_d_3   -2
    X_6       OBJ       1
    X_6       R128      -1
    X_6       R129      -1
    X_6       R139      -1
    X_6       R140      -1
    X_6       R150      -1
    X_6       R151      -1
    X_6       R161      -1
    X_6       R162      -1
    X_6       R172      -1
    X_6       R173      -1
    X_6       R242      -1
    X_6       R243      -1
    X_6       NonOverlap_5  -1
    X_6       NonOverlap_6  1
    X_6       Global_CoM  1
    X_6       TorqueBal_6  1
    X_6       R290      -1
    X_6       TightUp_6  1
    X_6       TightDn_6  -1
    X_6       RB_up_6   1
    X_6       RB_dn_6   -1
    X_6       SP_4      1
    X_6       C2L_a_2   1
    X_6       C2L_b_2   1
    X_6       C2L_c_2   1
    X_6       C2L_d_2   1
    X_6       C2L_a_3   1
    X_6       C2L_b_3   1
    X_6       C2L_c_3   1
    X_6       C2L_d_3   1
    X_6       RM_dom_2  -1
    X_6       RM_dom_3  -1
    X_6       RM_dom_5  -1
    X_6       RM_dom_1  -1
    X_6       RM_beats_cutoff  1
    X_7       R185      -1
    X_7       R186      -1
    X_7       R196      -1
    X_7       R197      -1
    X_7       R207      -1
    X_7       R208      -1
    X_7       R218      -1
    X_7       R219      -1
    X_7       R229      -1
    X_7       R230      -1
    X_7       R240      -1
    X_7       R241      -1
    X_7       NonOverlap_6  -1
    X_7       Global_CoM  1
    X_7       TorqueBal_7  1
    X_7       R291      -1
    X_7       TightUp_7  1
    X_7       TightDn_7  -1
    X_7       RB_up_7   1
    X_7       RB_dn_7   -1
    X_7       SP_5      1
    X_7       C2L_a_2   1
    X_7       C2L_b_2   1
    X_7       C2L_c_2   1
    X_7       C2L_d_2   1
    X_7       C2L_a_3   1
    X_7       C2L_b_3   1
    X_7       C2L_c_3   1
    X_7       C2L_d_3   1
    X_7       RM_dom_5  1
    MARKER    'MARKER'                 'INTORG'
    L_0       OBJ       0
    L_1       LayerUB_2_1  -1
    L_1       LayerLB_2_1  -1
    L_1       LayerUB_3_1  -1
    L_1       LayerLB_3_1  -1
    L_1       LayerUB_4_1  -1
    L_1       LayerLB_4_1  -1
    L_1       LayerUB_5_1  -1
    L_1       LayerLB_5_1  -1
    L_1       LayerUB_6_1  -1
    L_1       LayerLB_6_1  -1
    L_1       LayerUB_7_1  -1
    L_1       LayerLB_7_1  -1
    L_1       SymLayer_1  1
    L_1       R247      -1
    L_1       R248      -1
    L_2       LayerUB_2_1  1
    L_2       LayerLB_2_1  1
    L_2       LayerUB_3_2  -1
    L_2       LayerLB_3_2  -1
    L_2       LayerUB_4_2  -1
    L_2       LayerLB_4_2  -1
    L_2       LayerUB_5_2  -1
    L_2       LayerLB_5_2  -1
    L_2       LayerUB_6_2  -1
    L_2       LayerLB_6_2  -1
    L_2       LayerUB_7_2  -1
    L_2       LayerLB_7_2  -1
    L_2       SymLayer_1  -1
    L_2       R247      1
    L_2       R248      1
    L_2       SymLayer_2  1
    L_2       R251      -1
    L_2       R252      -1
    L_2       TightUp_2  -1
    L_2       TightDn_2  -1
    L_3       LayerUB_3_1  1
    L_3       LayerLB_3_1  1
    L_3       LayerUB_3_2  1
    L_3       LayerLB_3_2  1
    L_3       LayerUB_4_3  -1
    L_3       LayerLB_4_3  -1
    L_3       LayerUB_5_3  -1
    L_3       LayerLB_5_3  -1
    L_3       LayerUB_6_3  -1
    L_3       LayerLB_6_3  -1
    L_3       LayerUB_7_3  -1
    L_3       LayerLB_7_3  -1
    L_3       SymLayer_2  -1
    L_3       R251      1
    L_3       R252      1
    L_3       SymLayer_3  1
    L_3       R255      -1
    L_3       R256      -1
    L_3       S2_Lmin_3  1
    L_3       TightUp_3  -1
    L_3       TightDn_3  -1
    L_4       LayerUB_4_1  1
    L_4       LayerLB_4_1  1
    L_4       LayerUB_4_2  1
    L_4       LayerLB_4_2  1
    L_4       LayerUB_4_3  1
    L_4       LayerLB_4_3  1
    L_4       LayerUB_5_4  -1
    L_4       LayerLB_5_4  -1
    L_4       LayerUB_6_4  -1
    L_4       LayerLB_6_4  -1
    L_4       LayerUB_7_4  -1
    L_4       LayerLB_7_4  -1
    L_4       SymLayer_3  -1
    L_4       R255      1
    L_4       R256      1
    L_4       SymLayer_4  1
    L_4       R259      -1
    L_4       R260      -1
    L_4       TightUp_4  -1
    L_4       TightDn_4  -1
    L_5       LayerUB_5_1  1
    L_5       LayerLB_5_1  1
    L_5       LayerUB_5_2  1
    L_5       LayerLB_5_2  1
    L_5       LayerUB_5_3  1
    L_5       LayerLB_5_3  1
    L_5       LayerUB_5_4  1
    L_5       LayerLB_5_4  1
    L_5       LayerUB_6_5  -1
    L_5       LayerLB_6_5  -1
    L_5       LayerUB_7_5  -1
    L_5       LayerLB_7_5  -1
    L_5       SymLayer_4  -1
    L_5       R259      1
    L_5       R260      1
    L_5       SymLayer_5  1
    L_5       R263      -1
    L_5       R264      -1
    L_5       S2_Lmin_5  1
    L_5       TightUp_5  -1
    L_5       TightDn_5  -1
    L_6       LayerUB_6_1  1
    L_6       LayerLB_6_1  1
    L_6       LayerUB_6_2  1
    L_6       LayerLB_6_2  1
    L_6       LayerUB_6_3  1
    L_6       LayerLB_6_3  1
    L_6       LayerUB_6_4  1
    L_6       LayerLB_6_4  1
    L_6       LayerUB_6_5  1
    L_6       LayerLB_6_5  1
    L_6       LayerUB_7_6  -1
    L_6       LayerLB_7_6  -1
    L_6       SymLayer_5  -1
    L_6       R263      1
    L_6       R264      1
    L_6       SymLayer_6  1
    L_6       R267      -1
    L_6       R268      -1
    L_6       S2_Lmin_6  1
    L_6       TightUp_6  -1
    L_6       TightDn_6  -1
    L_7       LayerUB_7_1  1
    L_7       LayerLB_7_1  1
    L_7       LayerUB_7_2  1
    L_7       LayerLB_7_2  1
    L_7       LayerUB_7_3  1
    L_7       LayerLB_7_3  1
    L_7       LayerUB_7_4  1
    L_7       LayerLB_7_4  1
    L_7       LayerUB_7_5  1
    L_7       LayerLB_7_5  1
    L_7       LayerUB_7_6  1
    L_7       LayerLB_7_6  1
    L_7       SymLayer_6  -1
    L_7       R267      1
    L_7       R268      1
    L_7       S2_Lmin_7  1
    L_7       TightUp_7  -1
    L_7       TightDn_7  -1
    T_1_0     OBJ       0
    MARKER    'MARKER'                 'INTEND'
    F_1_0     ForceBal_1  -1
    P_1_0     BaseContact_LB  1
    P_1_0     BaseContact_UB  1
    P_1_0     BaseTorque_Linear  -7
    Torque_1_0  BaseTorque_Linear  1
    Torque_1_0  TorqueBal_1  -1
    Torque_1_0  C2_a      1
    Torque_1_0  C2_b      1
    Torque_1_0  C2_c      1
    Torque_1_0  C2_d      1
    MARKER    'MARKER'                 'INTORG'
    T_2_1     DAGSupMin_2  1
    T_2_1     DAGSupMax_2  1
    T_2_1     ForceCap_2_1  -6
    T_2_1     PCapLB_2_1  7
    T_2_1     PCapUB_2_1  -7
    T_2_1     TCapLB_2_1  42
    T_2_1     TCapUB_2_1  -42
    T_2_1     R10       -15
    T_2_1     R11       15
    T_2_1     R12       -15
    T_2_1     R13       15
    T_2_1     LayerUB_2_1  1
    T_2_1     LayerLB_2_1  -1
    T_2_1     S2_T21    1
    MARKER    'MARKER'                 'INTEND'
    F_2_1     ForceCap_2_1  1
    F_2_1     ForceBal_1  1
    F_2_1     ForceBal_2  -1
    F_2_1     S2_F21lo  1
    F_2_1     S2_F21hi  1
    F_2_1     C2_b      -1
    F_2_1     C2_d      -1
    P_2_1     PCapLB_2_1  1
    P_2_1     PCapUB_2_1  1
    P_2_1     R10       1
    P_2_1     R11       1
    P_2_1     R12       1
    P_2_1     R13       1
    P_2_1     S4_BaseRightCorner  1
    P_2_1     C2_a      -1
    P_2_1     C2_b      -5
    P_2_1     C2_c      -5
    P_2_1     C2_d      -1
    Torque_2_1  TCapLB_2_1  1
    Torque_2_1  TCapUB_2_1  1
    Torque_2_1  TorqueBal_1  1
    Torque_2_1  TorqueBal_2  -1
    Torque_2_1  Bilinear_2_1  1
    MARKER    'MARKER'                 'INTORG'
    T_3_1     DAGSupMin_3  1
    T_3_1     DAGSupMax_3  1
    T_3_1     ForceCap_3_1  -5
    T_3_1     PCapLB_3_1  7
    T_3_1     PCapUB_3_1  -7
    T_3_1     TCapLB_3_1  35
    T_3_1     TCapUB_3_1  -35
    T_3_1     R23       -15
    T_3_1     R24       15
    T_3_1     R25       -15
    T_3_1     R26       15
    T_3_1     LayerUB_3_1  2
    T_3_1     LayerLB_3_1  -1
    T_3_1     S2_T31    1
    MARKER    'MARKER'                 'INTEND'
    F_3_1     ForceCap_3_1  1
    F_3_1     ForceBal_1  1
    F_3_1     ForceBal_3  -1
    F_3_1     S2_F31lo  1
    F_3_1     S2_F31hi  1
    P_3_1     PCapLB_3_1  1
    P_3_1     PCapUB_3_1  1
    P_3_1     R23       1
    P_3_1     R24       1
    P_3_1     R25       1
    P_3_1     R26       1
    P_3_1     C2_a      -5
    P_3_1     C2_b      -1
    P_3_1     C2_c      -1
    P_3_1     C2_d      -5
    Torque_3_1  TCapLB_3_1  1
    Torque_3_1  TCapUB_3_1  1
    Torque_3_1  TorqueBal_1  1
    Torque_3_1  TorqueBal_3  -1
    Torque_3_1  Bilinear_3_1  1
    MARKER    'MARKER'                 'INTORG'
    T_3_2     DAGSupMin_3  1
    T_3_2     DAGSupMax_3  1
    T_3_2     ForceCap_3_2  -5
    T_3_2     PCapLB_3_2  7
    T_3_2     PCapUB_3_2  -7
    T_3_2     TCapLB_3_2  35
    T_3_2     TCapUB_3_2  -35
    T_3_2     R34       -15
    T_3_2     R35       15
    T_3_2     R36       -15
    T_3_2     R37       15
    T_3_2     LayerUB_3_2  2
    T_3_2     LayerLB_3_2  -2
    T_3_2     S2_T32    1
    MARKER    'MARKER'                 'INTEND'
    F_3_2     ForceCap_3_2  1
    F_3_2     ForceBal_2  1
    F_3_2     ForceBal_3  -1
    P_3_2     PCapLB_3_2  1
    P_3_2     PCapUB_3_2  1
    P_3_2     R34       1
    P_3_2     R35       1
    P_3_2     R36       1
    P_3_2     R37       1
    Torque_3_2  TCapLB_3_2  1
    Torque_3_2  TCapUB_3_2  1
    Torque_3_2  TorqueBal_2  1
    Torque_3_2  TorqueBal_3  -1
    Torque_3_2  Bilinear_3_2  1
    MARKER    'MARKER'                 'INTORG'
    T_4_1     DAGSupMin_4  1
    T_4_1     DAGSupMax_4  1
    T_4_1     ForceCap_4_1  -4
    T_4_1     PCapLB_4_1  7
    T_4_1     PCapUB_4_1  -7
    T_4_1     TCapLB_4_1  28
    T_4_1     TCapUB_4_1  -28
    T_4_1     R47       -15
    T_4_1     R48       15
    T_4_1     R49       -15
    T_4_1     R50       15
    T_4_1     LayerUB_4_1  3
    T_4_1     LayerLB_4_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_4_1     ForceCap_4_1  1
    F_4_1     ForceBal_1  1
    F_4_1     ForceBal_4  -1
    P_4_1     PCapLB_4_1  1
    P_4_1     PCapUB_4_1  1
    P_4_1     R47       1
    P_4_1     R48       1
    P_4_1     R49       1
    P_4_1     R50       1
    Torque_4_1  TCapLB_4_1  1
    Torque_4_1  TCapUB_4_1  1
    Torque_4_1  TorqueBal_1  1
    Torque_4_1  TorqueBal_4  -1
    Torque_4_1  Bilinear_4_1  1
    MARKER    'MARKER'                 'INTORG'
    T_4_2     DAGSupMin_4  1
    T_4_2     DAGSupMax_4  1
    T_4_2     ForceCap_4_2  -4
    T_4_2     PCapLB_4_2  7
    T_4_2     PCapUB_4_2  -7
    T_4_2     TCapLB_4_2  28
    T_4_2     TCapUB_4_2  -28
    T_4_2     R58       -15
    T_4_2     R59       15
    T_4_2     R60       -15
    T_4_2     R61       15
    T_4_2     LayerUB_4_2  3
    T_4_2     LayerLB_4_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_4_2     ForceCap_4_2  1
    F_4_2     ForceBal_2  1
    F_4_2     ForceBal_4  -1
    F_4_2     C2L_a_2   -1
    F_4_2     C2L_b_2   -2
    F_4_2     C2L_c_2   -1
    F_4_2     C2L_d_2   -2
    P_4_2     PCapLB_4_2  1
    P_4_2     PCapUB_4_2  1
    P_4_2     R58       1
    P_4_2     R59       1
    P_4_2     R60       1
    P_4_2     R61       1
    Torque_4_2  TCapLB_4_2  1
    Torque_4_2  TCapUB_4_2  1
    Torque_4_2  TorqueBal_2  1
    Torque_4_2  TorqueBal_4  -1
    Torque_4_2  Bilinear_4_2  1
    MARKER    'MARKER'                 'INTORG'
    T_4_3     DAGSupMin_4  1
    T_4_3     DAGSupMax_4  1
    T_4_3     ForceCap_4_3  -4
    T_4_3     PCapLB_4_3  7
    T_4_3     PCapUB_4_3  -7
    T_4_3     TCapLB_4_3  28
    T_4_3     TCapUB_4_3  -28
    T_4_3     R69       -15
    T_4_3     R70       15
    T_4_3     R71       -15
    T_4_3     R72       15
    T_4_3     LayerUB_4_3  3
    T_4_3     LayerLB_4_3  -3
    T_4_3     SP_3      -1.2556690476532459e+00
    T_4_3     SP_4      -1.9681292070216632e+00
    T_4_3     SP_5      -2.0175280196018988e+00
    T_4_3     NonSpinal  1
    MARKER    'MARKER'                 'INTEND'
    F_4_3     ForceCap_4_3  1
    F_4_3     ForceBal_3  1
    F_4_3     ForceBal_4  -1
    P_4_3     PCapLB_4_3  1
    P_4_3     PCapUB_4_3  1
    P_4_3     R69       1
    P_4_3     R70       1
    P_4_3     R71       1
    P_4_3     R72       1
    Torque_4_3  TCapLB_4_3  1
    Torque_4_3  TCapUB_4_3  1
    Torque_4_3  TorqueBal_3  1
    Torque_4_3  TorqueBal_4  -1
    Torque_4_3  Bilinear_4_3  1
    MARKER    'MARKER'                 'INTORG'
    T_5_1     DAGSupMin_5  1
    T_5_1     DAGSupMax_5  1
    T_5_1     ForceCap_5_1  -3
    T_5_1     PCapLB_5_1  7
    T_5_1     PCapUB_5_1  -7
    T_5_1     TCapLB_5_1  21
    T_5_1     TCapUB_5_1  -21
    T_5_1     R82       -15
    T_5_1     R83       15
    T_5_1     R84       -15
    T_5_1     R85       15
    T_5_1     LayerUB_5_1  4
    T_5_1     LayerLB_5_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_5_1     ForceCap_5_1  1
    F_5_1     ForceBal_1  1
    F_5_1     ForceBal_5  -1
    P_5_1     PCapLB_5_1  1
    P_5_1     PCapUB_5_1  1
    P_5_1     R82       1
    P_5_1     R83       1
    P_5_1     R84       1
    P_5_1     R85       1
    Torque_5_1  TCapLB_5_1  1
    Torque_5_1  TCapUB_5_1  1
    Torque_5_1  TorqueBal_1  1
    Torque_5_1  TorqueBal_5  -1
    Torque_5_1  Bilinear_5_1  1
    MARKER    'MARKER'                 'INTORG'
    T_5_2     DAGSupMin_5  1
    T_5_2     DAGSupMax_5  1
    T_5_2     ForceCap_5_2  -3
    T_5_2     PCapLB_5_2  7
    T_5_2     PCapUB_5_2  -7
    T_5_2     TCapLB_5_2  21
    T_5_2     TCapUB_5_2  -21
    T_5_2     R93       -15
    T_5_2     R94       15
    T_5_2     R95       -15
    T_5_2     R96       15
    T_5_2     LayerUB_5_2  4
    T_5_2     LayerLB_5_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_5_2     ForceCap_5_2  1
    F_5_2     ForceBal_2  1
    F_5_2     ForceBal_5  -1
    F_5_2     C2L_a_2   -1
    F_5_2     C2L_b_2   -2
    F_5_2     C2L_c_2   -1
    F_5_2     C2L_d_2   -2
    P_5_2     PCapLB_5_2  1
    P_5_2     PCapUB_5_2  1
    P_5_2     R93       1
    P_5_2     R94       1
    P_5_2     R95       1
    P_5_2     R96       1
    Torque_5_2  TCapLB_5_2  1
    Torque_5_2  TCapUB_5_2  1
    Torque_5_2  TorqueBal_2  1
    Torque_5_2  TorqueBal_5  -1
    Torque_5_2  Bilinear_5_2  1
    MARKER    'MARKER'                 'INTORG'
    T_5_3     DAGSupMin_5  1
    T_5_3     DAGSupMax_5  1
    T_5_3     ForceCap_5_3  -3
    T_5_3     PCapLB_5_3  7
    T_5_3     PCapUB_5_3  -7
    T_5_3     TCapLB_5_3  21
    T_5_3     TCapUB_5_3  -21
    T_5_3     R104      -15
    T_5_3     R105      15
    T_5_3     R106      -15
    T_5_3     R107      15
    T_5_3     LayerUB_5_3  4
    T_5_3     LayerLB_5_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_5_3     ForceCap_5_3  1
    F_5_3     ForceBal_3  1
    F_5_3     ForceBal_5  -1
    P_5_3     PCapLB_5_3  1
    P_5_3     PCapUB_5_3  1
    P_5_3     R104      1
    P_5_3     R105      1
    P_5_3     R106      1
    P_5_3     R107      1
    Torque_5_3  TCapLB_5_3  1
    Torque_5_3  TCapUB_5_3  1
    Torque_5_3  TorqueBal_3  1
    Torque_5_3  TorqueBal_5  -1
    Torque_5_3  Bilinear_5_3  1
    MARKER    'MARKER'                 'INTORG'
    T_5_4     DAGSupMin_5  1
    T_5_4     DAGSupMax_5  1
    T_5_4     ForceCap_5_4  -3
    T_5_4     PCapLB_5_4  7
    T_5_4     PCapUB_5_4  -7
    T_5_4     TCapLB_5_4  21
    T_5_4     TCapUB_5_4  -21
    T_5_4     R115      -15
    T_5_4     R116      15
    T_5_4     R117      -15
    T_5_4     R118      15
    T_5_4     LayerUB_5_4  4
    T_5_4     LayerLB_5_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_5_4     ForceCap_5_4  1
    F_5_4     ForceBal_4  1
    F_5_4     ForceBal_5  -1
    P_5_4     PCapLB_5_4  1
    P_5_4     PCapUB_5_4  1
    P_5_4     R115      1
    P_5_4     R116      1
    P_5_4     R117      1
    P_5_4     R118      1
    Torque_5_4  TCapLB_5_4  1
    Torque_5_4  TCapUB_5_4  1
    Torque_5_4  TorqueBal_4  1
    Torque_5_4  TorqueBal_5  -1
    Torque_5_4  Bilinear_5_4  1
    MARKER    'MARKER'                 'INTORG'
    T_6_1     DAGSupMin_6  1
    T_6_1     DAGSupMax_6  1
    T_6_1     ForceCap_6_1  -2
    T_6_1     PCapLB_6_1  7
    T_6_1     PCapUB_6_1  -7
    T_6_1     TCapLB_6_1  14
    T_6_1     TCapUB_6_1  -14
    T_6_1     R128      -15
    T_6_1     R129      15
    T_6_1     R130      -15
    T_6_1     R131      15
    T_6_1     LayerUB_6_1  5
    T_6_1     LayerLB_6_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_6_1     ForceCap_6_1  1
    F_6_1     ForceBal_1  1
    F_6_1     ForceBal_6  -1
    P_6_1     PCapLB_6_1  1
    P_6_1     PCapUB_6_1  1
    P_6_1     R128      1
    P_6_1     R129      1
    P_6_1     R130      1
    P_6_1     R131      1
    Torque_6_1  TCapLB_6_1  1
    Torque_6_1  TCapUB_6_1  1
    Torque_6_1  TorqueBal_1  1
    Torque_6_1  TorqueBal_6  -1
    Torque_6_1  Bilinear_6_1  1
    MARKER    'MARKER'                 'INTORG'
    T_6_2     DAGSupMin_6  1
    T_6_2     DAGSupMax_6  1
    T_6_2     ForceCap_6_2  -2
    T_6_2     PCapLB_6_2  7
    T_6_2     PCapUB_6_2  -7
    T_6_2     TCapLB_6_2  14
    T_6_2     TCapUB_6_2  -14
    T_6_2     R139      -15
    T_6_2     R140      15
    T_6_2     R141      -15
    T_6_2     R142      15
    T_6_2     LayerUB_6_2  5
    T_6_2     LayerLB_6_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_6_2     ForceCap_6_2  1
    F_6_2     ForceBal_2  1
    F_6_2     ForceBal_6  -1
    P_6_2     PCapLB_6_2  1
    P_6_2     PCapUB_6_2  1
    P_6_2     R139      1
    P_6_2     R140      1
    P_6_2     R141      1
    P_6_2     R142      1
    Torque_6_2  TCapLB_6_2  1
    Torque_6_2  TCapUB_6_2  1
    Torque_6_2  TorqueBal_2  1
    Torque_6_2  TorqueBal_6  -1
    Torque_6_2  Bilinear_6_2  1
    MARKER    'MARKER'                 'INTORG'
    T_6_3     DAGSupMin_6  1
    T_6_3     DAGSupMax_6  1
    T_6_3     ForceCap_6_3  -2
    T_6_3     PCapLB_6_3  7
    T_6_3     PCapUB_6_3  -7
    T_6_3     TCapLB_6_3  14
    T_6_3     TCapUB_6_3  -14
    T_6_3     R150      -15
    T_6_3     R151      15
    T_6_3     R152      -15
    T_6_3     R153      15
    T_6_3     LayerUB_6_3  5
    T_6_3     LayerLB_6_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_6_3     ForceCap_6_3  1
    F_6_3     ForceBal_3  1
    F_6_3     ForceBal_6  -1
    P_6_3     PCapLB_6_3  1
    P_6_3     PCapUB_6_3  1
    P_6_3     R150      1
    P_6_3     R151      1
    P_6_3     R152      1
    P_6_3     R153      1
    Torque_6_3  TCapLB_6_3  1
    Torque_6_3  TCapUB_6_3  1
    Torque_6_3  TorqueBal_3  1
    Torque_6_3  TorqueBal_6  -1
    Torque_6_3  Bilinear_6_3  1
    MARKER    'MARKER'                 'INTORG'
    T_6_4     DAGSupMin_6  1
    T_6_4     DAGSupMax_6  1
    T_6_4     ForceCap_6_4  -2
    T_6_4     PCapLB_6_4  7
    T_6_4     PCapUB_6_4  -7
    T_6_4     TCapLB_6_4  14
    T_6_4     TCapUB_6_4  -14
    T_6_4     R161      -15
    T_6_4     R162      15
    T_6_4     R163      -15
    T_6_4     R164      15
    T_6_4     LayerUB_6_4  5
    T_6_4     LayerLB_6_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_6_4     ForceCap_6_4  1
    F_6_4     ForceBal_4  1
    F_6_4     ForceBal_6  -1
    F_6_4     C2L_a_3   -1
    F_6_4     C2L_b_3   -4
    F_6_4     C2L_c_3   -1
    F_6_4     C2L_d_3   -4
    P_6_4     PCapLB_6_4  1
    P_6_4     PCapUB_6_4  1
    P_6_4     R161      1
    P_6_4     R162      1
    P_6_4     R163      1
    P_6_4     R164      1
    Torque_6_4  TCapLB_6_4  1
    Torque_6_4  TCapUB_6_4  1
    Torque_6_4  TorqueBal_4  1
    Torque_6_4  TorqueBal_6  -1
    Torque_6_4  Bilinear_6_4  1
    MARKER    'MARKER'                 'INTORG'
    T_6_5     DAGSupMin_6  1
    T_6_5     DAGSupMax_6  1
    T_6_5     ForceCap_6_5  -2
    T_6_5     PCapLB_6_5  7
    T_6_5     PCapUB_6_5  -7
    T_6_5     TCapLB_6_5  14
    T_6_5     TCapUB_6_5  -14
    T_6_5     R172      -15
    T_6_5     R173      15
    T_6_5     R174      -15
    T_6_5     R175      15
    T_6_5     LayerUB_6_5  5
    T_6_5     LayerLB_6_5  -5
    T_6_5     SP_4      -1.9681292070216632e+00
    T_6_5     SP_5      -2.0175280196018988e+00
    T_6_5     NonSpinal  1
    MARKER    'MARKER'                 'INTEND'
    F_6_5     ForceCap_6_5  1
    F_6_5     ForceBal_5  1
    F_6_5     ForceBal_6  -1
    P_6_5     PCapLB_6_5  1
    P_6_5     PCapUB_6_5  1
    P_6_5     R172      1
    P_6_5     R173      1
    P_6_5     R174      1
    P_6_5     R175      1
    Torque_6_5  TCapLB_6_5  1
    Torque_6_5  TCapUB_6_5  1
    Torque_6_5  TorqueBal_5  1
    Torque_6_5  TorqueBal_6  -1
    Torque_6_5  Bilinear_6_5  1
    MARKER    'MARKER'                 'INTORG'
    T_7_1     DAGSupMin_7  1
    T_7_1     DAGSupMax_7  1
    T_7_1     ForceCap_7_1  -1
    T_7_1     PCapLB_7_1  7
    T_7_1     PCapUB_7_1  -7
    T_7_1     TCapLB_7_1  7
    T_7_1     TCapUB_7_1  -7
    T_7_1     R185      -15
    T_7_1     R186      15
    T_7_1     R187      -15
    T_7_1     R188      15
    T_7_1     LayerUB_7_1  6
    T_7_1     LayerLB_7_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_7_1     ForceCap_7_1  1
    F_7_1     ForceBal_1  1
    F_7_1     ForceBal_7  -1
    P_7_1     PCapLB_7_1  1
    P_7_1     PCapUB_7_1  1
    P_7_1     R185      1
    P_7_1     R186      1
    P_7_1     R187      1
    P_7_1     R188      1
    Torque_7_1  TCapLB_7_1  1
    Torque_7_1  TCapUB_7_1  1
    Torque_7_1  TorqueBal_1  1
    Torque_7_1  TorqueBal_7  -1
    Torque_7_1  Bilinear_7_1  1
    MARKER    'MARKER'                 'INTORG'
    T_7_2     DAGSupMin_7  1
    T_7_2     DAGSupMax_7  1
    T_7_2     ForceCap_7_2  -1
    T_7_2     PCapLB_7_2  7
    T_7_2     PCapUB_7_2  -7
    T_7_2     TCapLB_7_2  7
    T_7_2     TCapUB_7_2  -7
    T_7_2     R196      -15
    T_7_2     R197      15
    T_7_2     R198      -15
    T_7_2     R199      15
    T_7_2     LayerUB_7_2  6
    T_7_2     LayerLB_7_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_7_2     ForceCap_7_2  1
    F_7_2     ForceBal_2  1
    F_7_2     ForceBal_7  -1
    P_7_2     PCapLB_7_2  1
    P_7_2     PCapUB_7_2  1
    P_7_2     R196      1
    P_7_2     R197      1
    P_7_2     R198      1
    P_7_2     R199      1
    Torque_7_2  TCapLB_7_2  1
    Torque_7_2  TCapUB_7_2  1
    Torque_7_2  TorqueBal_2  1
    Torque_7_2  TorqueBal_7  -1
    Torque_7_2  Bilinear_7_2  1
    MARKER    'MARKER'                 'INTORG'
    T_7_3     DAGSupMin_7  1
    T_7_3     DAGSupMax_7  1
    T_7_3     ForceCap_7_3  -1
    T_7_3     PCapLB_7_3  7
    T_7_3     PCapUB_7_3  -7
    T_7_3     TCapLB_7_3  7
    T_7_3     TCapUB_7_3  -7
    T_7_3     R207      -15
    T_7_3     R208      15
    T_7_3     R209      -15
    T_7_3     R210      15
    T_7_3     LayerUB_7_3  6
    T_7_3     LayerLB_7_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_7_3     ForceCap_7_3  1
    F_7_3     ForceBal_3  1
    F_7_3     ForceBal_7  -1
    P_7_3     PCapLB_7_3  1
    P_7_3     PCapUB_7_3  1
    P_7_3     R207      1
    P_7_3     R208      1
    P_7_3     R209      1
    P_7_3     R210      1
    Torque_7_3  TCapLB_7_3  1
    Torque_7_3  TCapUB_7_3  1
    Torque_7_3  TorqueBal_3  1
    Torque_7_3  TorqueBal_7  -1
    Torque_7_3  Bilinear_7_3  1
    MARKER    'MARKER'                 'INTORG'
    T_7_4     DAGSupMin_7  1
    T_7_4     DAGSupMax_7  1
    T_7_4     ForceCap_7_4  -1
    T_7_4     PCapLB_7_4  7
    T_7_4     PCapUB_7_4  -7
    T_7_4     TCapLB_7_4  7
    T_7_4     TCapUB_7_4  -7
    T_7_4     R218      -15
    T_7_4     R219      15
    T_7_4     R220      -15
    T_7_4     R221      15
    T_7_4     LayerUB_7_4  6
    T_7_4     LayerLB_7_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_7_4     ForceCap_7_4  1
    F_7_4     ForceBal_4  1
    F_7_4     ForceBal_7  -1
    P_7_4     PCapLB_7_4  1
    P_7_4     PCapUB_7_4  1
    P_7_4     R218      1
    P_7_4     R219      1
    P_7_4     R220      1
    P_7_4     R221      1
    Torque_7_4  TCapLB_7_4  1
    Torque_7_4  TCapUB_7_4  1
    Torque_7_4  TorqueBal_4  1
    Torque_7_4  TorqueBal_7  -1
    Torque_7_4  Bilinear_7_4  1
    MARKER    'MARKER'                 'INTORG'
    T_7_5     DAGSupMin_7  1
    T_7_5     DAGSupMax_7  1
    T_7_5     ForceCap_7_5  -1
    T_7_5     PCapLB_7_5  7
    T_7_5     PCapUB_7_5  -7
    T_7_5     TCapLB_7_5  7
    T_7_5     TCapUB_7_5  -7
    T_7_5     R229      -15
    T_7_5     R230      15
    T_7_5     R231      -15
    T_7_5     R232      15
    T_7_5     LayerUB_7_5  6
    T_7_5     LayerLB_7_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_7_5     ForceCap_7_5  1
    F_7_5     ForceBal_5  1
    F_7_5     ForceBal_7  -1
    P_7_5     PCapLB_7_5  1
    P_7_5     PCapUB_7_5  1
    P_7_5     R229      1
    P_7_5     R230      1
    P_7_5     R231      1
    P_7_5     R232      1
    Torque_7_5  TCapLB_7_5  1
    Torque_7_5  TCapUB_7_5  1
    Torque_7_5  TorqueBal_5  1
    Torque_7_5  TorqueBal_7  -1
    Torque_7_5  Bilinear_7_5  1
    MARKER    'MARKER'                 'INTORG'
    T_7_6     DAGSupMin_7  1
    T_7_6     DAGSupMax_7  1
    T_7_6     ForceCap_7_6  -1
    T_7_6     PCapLB_7_6  7
    T_7_6     PCapUB_7_6  -7
    T_7_6     TCapLB_7_6  7
    T_7_6     TCapUB_7_6  -7
    T_7_6     R240      -15
    T_7_6     R241      15
    T_7_6     R242      -15
    T_7_6     R243      15
    T_7_6     LayerUB_7_6  6
    T_7_6     LayerLB_7_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_7_6     ForceCap_7_6  1
    F_7_6     ForceBal_6  1
    F_7_6     ForceBal_7  -1
    P_7_6     PCapLB_7_6  1
    P_7_6     PCapUB_7_6  1
    P_7_6     R240      1
    P_7_6     R241      1
    P_7_6     R242      1
    P_7_6     R243      1
    Torque_7_6  TCapLB_7_6  1
    Torque_7_6  TCapUB_7_6  1
    Torque_7_6  TorqueBal_6  1
    Torque_7_6  TorqueBal_7  -1
    Torque_7_6  Bilinear_7_6  1
    MARKER    'MARKER'                 'INTORG'
    LayerJump_1  R247      -1
    LayerJump_1  R248      -1
    LayerJump_1  NonOverlap_1  15
    LayerJump_2  R251      -1
    LayerJump_2  R252      -2
    LayerJump_2  NonOverlap_2  15
    LayerJump_2  S2_Lmin_3  -1
    LayerJump_2  S2_Lmin_5  -1
    LayerJump_2  S2_Lmin_6  -1
    LayerJump_2  S2_Lmin_7  -1
    LayerJump_2  S2_T31    1
    LayerJump_2  S2_T32    -1
    LayerJump_2  S2_F21lo  -5
    LayerJump_2  S2_F21hi  -1
    LayerJump_2  S2_F31lo  1
    LayerJump_2  S2_F31hi  5
    LayerJump_2  S2_sign2  1
    LayerJump_2  S2_sign3  -2
    LayerJump_3  R255      -1
    LayerJump_3  R256      -3
    LayerJump_3  NonOverlap_3  15
    LayerJump_4  R259      -1
    LayerJump_4  R260      -4
    LayerJump_4  NonOverlap_4  15
    LayerJump_5  R263      -1
    LayerJump_5  R264      -5
    LayerJump_5  NonOverlap_5  15
    LayerJump_6  R267      -1
    LayerJump_6  R268      -6
    LayerJump_6  NonOverlap_6  15
    MARKER    'MARKER'                 'INTEND'
    RE_1      R285      1
    RE_2      R286      1
    RE_3      R287      1
    RE_4      R288      1
    RE_5      R289      1
    RE_6      R290      1
    RE_7      R291      1
    max_overhang  OBJ       0
RHS
    RHS1      OBJ       -0.5
    RHS1      BaseContact_LB  -0.5
    RHS1      BaseContact_UB  0.5
    RHS1      DAGSupMin_2  1
    RHS1      DAGSupMax_2  3
    RHS1      R10       -15.5
    RHS1      R11       15.5
    RHS1      R12       -15.5
    RHS1      R13       15.5
    RHS1      LayerUB_2_1  2
    RHS1      DAGSupMin_3  1
    RHS1      DAGSupMax_3  3
    RHS1      R23       -15.5
    RHS1      R24       15.5
    RHS1      R25       -15.5
    RHS1      R26       15.5
    RHS1      LayerUB_3_1  3
    RHS1      R34       -15.5
    RHS1      R35       15.5
    RHS1      R36       -15.5
    RHS1      R37       15.5
    RHS1      LayerUB_3_2  3
    RHS1      LayerLB_3_2  -1
    RHS1      DAGSupMin_4  1
    RHS1      DAGSupMax_4  3
    RHS1      R47       -15.5
    RHS1      R48       15.5
    RHS1      R49       -15.5
    RHS1      R50       15.5
    RHS1      LayerUB_4_1  4
    RHS1      R58       -15.5
    RHS1      R59       15.5
    RHS1      R60       -15.5
    RHS1      R61       15.5
    RHS1      LayerUB_4_2  4
    RHS1      LayerLB_4_2  -1
    RHS1      R69       -15.5
    RHS1      R70       15.5
    RHS1      R71       -15.5
    RHS1      R72       15.5
    RHS1      LayerUB_4_3  4
    RHS1      LayerLB_4_3  -2
    RHS1      DAGSupMin_5  1
    RHS1      DAGSupMax_5  3
    RHS1      R82       -15.5
    RHS1      R83       15.5
    RHS1      R84       -15.5
    RHS1      R85       15.5
    RHS1      LayerUB_5_1  5
    RHS1      R93       -15.5
    RHS1      R94       15.5
    RHS1      R95       -15.5
    RHS1      R96       15.5
    RHS1      LayerUB_5_2  5
    RHS1      LayerLB_5_2  -1
    RHS1      R104      -15.5
    RHS1      R105      15.5
    RHS1      R106      -15.5
    RHS1      R107      15.5
    RHS1      LayerUB_5_3  5
    RHS1      LayerLB_5_3  -2
    RHS1      R115      -15.5
    RHS1      R116      15.5
    RHS1      R117      -15.5
    RHS1      R118      15.5
    RHS1      LayerUB_5_4  5
    RHS1      LayerLB_5_4  -3
    RHS1      DAGSupMin_6  1
    RHS1      DAGSupMax_6  3
    RHS1      R128      -15.5
    RHS1      R129      15.5
    RHS1      R130      -15.5
    RHS1      R131      15.5
    RHS1      LayerUB_6_1  6
    RHS1      R139      -15.5
    RHS1      R140      15.5
    RHS1      R141      -15.5
    RHS1      R142      15.5
    RHS1      LayerUB_6_2  6
    RHS1      LayerLB_6_2  -1
    RHS1      R150      -15.5
    RHS1      R151      15.5
    RHS1      R152      -15.5
    RHS1      R153      15.5
    RHS1      LayerUB_6_3  6
    RHS1      LayerLB_6_3  -2
    RHS1      R161      -15.5
    RHS1      R162      15.5
    RHS1      R163      -15.5
    RHS1      R164      15.5
    RHS1      LayerUB_6_4  6
    RHS1      LayerLB_6_4  -3
    RHS1      R172      -15.5
    RHS1      R173      15.5
    RHS1      R174      -15.5
    RHS1      R175      15.5
    RHS1      LayerUB_6_5  6
    RHS1      LayerLB_6_5  -4
    RHS1      DAGSupMin_7  1
    RHS1      DAGSupMax_7  3
    RHS1      R185      -15.5
    RHS1      R186      15.5
    RHS1      R187      -15.5
    RHS1      R188      15.5
    RHS1      LayerUB_7_1  7
    RHS1      R196      -15.5
    RHS1      R197      15.5
    RHS1      R198      -15.5
    RHS1      R199      15.5
    RHS1      LayerUB_7_2  7
    RHS1      LayerLB_7_2  -1
    RHS1      R207      -15.5
    RHS1      R208      15.5
    RHS1      R209      -15.5
    RHS1      R210      15.5
    RHS1      LayerUB_7_3  7
    RHS1      LayerLB_7_3  -2
    RHS1      R218      -15.5
    RHS1      R219      15.5
    RHS1      R220      -15.5
    RHS1      R221      15.5
    RHS1      LayerUB_7_4  7
    RHS1      LayerLB_7_4  -3
    RHS1      R229      -15.5
    RHS1      R230      15.5
    RHS1      R231      -15.5
    RHS1      R232      15.5
    RHS1      LayerUB_7_5  7
    RHS1      LayerLB_7_5  -4
    RHS1      R240      -15.5
    RHS1      R241      15.5
    RHS1      R242      -15.5
    RHS1      R243      15.5
    RHS1      LayerUB_7_6  7
    RHS1      LayerLB_7_6  -5
    RHS1      NonOverlap_1  1
    RHS1      NonOverlap_2  1
    RHS1      NonOverlap_3  1
    RHS1      NonOverlap_4  1
    RHS1      NonOverlap_5  1
    RHS1      NonOverlap_6  1
    RHS1      ForceBal_1  -1
    RHS1      ForceBal_2  -1
    RHS1      ForceBal_3  -1
    RHS1      ForceBal_4  -1
    RHS1      ForceBal_5  -1
    RHS1      ForceBal_6  -1
    RHS1      ForceBal_7  -1
    RHS1      R285      0.5
    RHS1      R286      0.5
    RHS1      R287      0.5
    RHS1      R288      0.5
    RHS1      R289      0.5
    RHS1      R290      0.5
    RHS1      R291      0.5
    RHS1      S2_Lmin_3  2
    RHS1      S2_Lmin_5  3
    RHS1      S2_Lmin_6  3
    RHS1      S2_Lmin_7  3
    RHS1      S2_T21    1
    RHS1      S2_T31    1
    RHS1      S2_F21lo  1
    RHS1      S2_F21hi  5
    RHS1      S2_F31lo  1
    RHS1      S2_F31hi  5
    RHS1      TightUp_2  -1
    RHS1      TightDn_2  -1
    RHS1      TightUp_3  -1
    RHS1      TightDn_3  -1
    RHS1      TightUp_4  -1
    RHS1      TightDn_4  -1
    RHS1      TightUp_5  -1
    RHS1      TightDn_5  -1
    RHS1      TightUp_6  -1
    RHS1      TightDn_6  -1
    RHS1      TightUp_7  -1
    RHS1      TightDn_7  -1
    RHS1      S4_BaseRightCorner  0.5
    RHS1      C2_b      -5
    RHS1      C2_d      -1
    RHS1      RB_up_2   1
    RHS1      RB_dn_3   1
    RHS1      RB_up_4   2
    RHS1      RB_dn_4   1
    RHS1      RB_up_5   1
    RHS1      RB_dn_5   2
    RHS1      RB_up_6   3
    RHS1      RB_dn_6   3
    RHS1      RB_up_7   4
    RHS1      RB_dn_7   4
    RHS1      SP_3      1.0300452380610396e+00
    RHS1      SP_4      1.0318707929783368e+00
    RHS1      SP_5      9.8247198039810124e-01
    RHS1      C2L_DeltaUB_2  2
    RHS1      C2L_a_2   -2
    RHS1      C2L_b_2   -10
    RHS1      C2L_c_2   -2
    RHS1      C2L_d_2   2
    RHS1      C2L_DeltaUB_3  4
    RHS1      C2L_a_3   -1
    RHS1      C2L_b_3   -9
    RHS1      C2L_c_3   -1
    RHS1      C2L_d_3   1
    RHS1      RM_beats_cutoff  1.0165520840585534e+00
    RHS1      NonSpinal  1
BOUNDS
 FX BND1      X_0       0
 LO BND1      X_1       -0.5
 UP BND1      X_1       2.8571428571428570e-01
 LO BND1      X_2       -0.5
 UP BND1      X_2       8.9404894574657989e-01
 LO BND1      X_3       -1.5
 UP BND1      X_3       2.8571428571428570e-01
 LO BND1      X_4       1.6552084058553351e-02
 UP BND1      X_4       2.2857142857142856e+00
 LO BND1      X_5       -2.5
 UP BND1      X_5       1.2857142857142856e+00
 LO BND1      X_6       1.0165520840585534e+00
 UP BND1      X_6       3
 LO BND1      X_7       -3.5
 UP BND1      X_7       3
 FX BND1      L_0       0
 FX BND1      L_1       1
 FX BND1      L_2       2
 FX BND1      L_3       2
 FX BND1      L_4       3
 FX BND1      L_5       3
 FX BND1      L_6       4
 FX BND1      L_7       5
 FX BND1      T_1_0     1
 BV BND1      T_1_0   
 FX BND1      F_1_0     7
 FX BND1      P_1_0     0
 LO BND1      Torque_1_0  -7
 UP BND1      Torque_1_0  0
 FX BND1      T_2_1     1
 BV BND1      T_2_1   
 UP BND1      F_2_1     5
 UP BND1      P_2_1     7.8571428571428570e-01
 UP BND1      Torque_2_1  3.9285714285714284e+00
 FX BND1      T_3_1     1
 BV BND1      T_3_1   
 UP BND1      F_3_1     5
 LO BND1      P_3_1     -1
 UP BND1      P_3_1     7.8571428571428570e-01
 LO BND1      Torque_3_1  -5
 UP BND1      Torque_3_1  3.9285714285714284e+00
 FX BND1      T_3_2     0
 BV BND1      T_3_2   
 FX BND1      F_3_2     0
 FX BND1      P_3_2     0
 FX BND1      Torque_3_2  0
 FX BND1      T_4_1     0
 BV BND1      T_4_1   
 FX BND1      F_4_1     0
 FX BND1      P_4_1     0
 FX BND1      Torque_4_1  0
 BV BND1      T_4_2   
 UP BND1      F_4_2     4
 LO BND1      P_4_2     -4.8344791594144665e-01
 UP BND1      P_4_2     1.39404894574658
 LO BND1      Torque_4_2  -1.9337916637657866e+00
 UP BND1      Torque_4_2  5.57619578298632
 BV BND1      T_4_3   
 UP BND1      F_4_3     4
 LO BND1      P_4_3     -4.8344791594144665e-01
 UP BND1      P_4_3     7.8571428571428570e-01
 LO BND1      Torque_4_3  -1.9337916637657866e+00
 UP BND1      Torque_4_3  3.1428571428571428e+00
 FX BND1      T_5_1     0
 BV BND1      T_5_1   
 FX BND1      F_5_1     0
 FX BND1      P_5_1     0
 FX BND1      Torque_5_1  0
 BV BND1      T_5_2   
 UP BND1      F_5_2     3
 LO BND1      P_5_2     -1
 UP BND1      P_5_2     1.39404894574658
 LO BND1      Torque_5_2  -3
 UP BND1      Torque_5_2  4.18214683723974
 BV BND1      T_5_3   
 UP BND1      F_5_3     3
 LO BND1      P_5_3     -2
 UP BND1      P_5_3     7.8571428571428570e-01
 LO BND1      Torque_5_3  -6
 UP BND1      Torque_5_3  2.3571428571428572e+00
 FX BND1      T_5_4     0
 BV BND1      T_5_4   
 FX BND1      F_5_4     0
 FX BND1      P_5_4     0
 FX BND1      Torque_5_4  0
 FX BND1      T_6_1     0
 BV BND1      T_6_1   
 FX BND1      F_6_1     0
 FX BND1      P_6_1     0
 FX BND1      Torque_6_1  0
 FX BND1      T_6_2     0
 BV BND1      T_6_2   
 FX BND1      F_6_2     0
 FX BND1      P_6_2     0
 FX BND1      Torque_6_2  0
 FX BND1      T_6_3     0
 BV BND1      T_6_3   
 FX BND1      F_6_3     0
 FX BND1      P_6_3     0
 FX BND1      Torque_6_3  0
 BV BND1      T_6_4   
 UP BND1      F_6_4     2
 UP BND1      P_6_4     2.7857142857142856e+00
 UP BND1      Torque_6_4  5.5714285714285712e+00
 BV BND1      T_6_5   
 UP BND1      F_6_5     2
 UP BND1      P_6_5     1.7857142857142856e+00
 UP BND1      Torque_6_5  3.5714285714285712e+00
 FX BND1      T_7_1     0
 BV BND1      T_7_1   
 FX BND1      F_7_1     0
 FX BND1      P_7_1     0
 FX BND1      Torque_7_1  0
 FX BND1      T_7_2     0
 BV BND1      T_7_2   
 FX BND1      F_7_2     0
 FX BND1      P_7_2     0
 FX BND1      Torque_7_2  0
 FX BND1      T_7_3     0
 BV BND1      T_7_3   
 FX BND1      F_7_3     0
 FX BND1      P_7_3     0
 FX BND1      Torque_7_3  0
 FX BND1      T_7_4     0
 BV BND1      T_7_4   
 FX BND1      F_7_4     0
 FX BND1      P_7_4     0
 FX BND1      Torque_7_4  0
 FX BND1      T_7_5     0
 BV BND1      T_7_5   
 FX BND1      F_7_5     0
 FX BND1      P_7_5     0
 FX BND1      Torque_7_5  0
 FX BND1      T_7_6     1
 BV BND1      T_7_6   
 FX BND1      F_7_6     1
 LO BND1      P_7_6     5.1655208405855335e-01
 UP BND1      P_7_6     3.5
 LO BND1      Torque_7_6  5.1655208405855335e-01
 UP BND1      Torque_7_6  3.5
 FX BND1      LayerJump_1  1
 BV BND1      LayerJump_1
 FX BND1      LayerJump_2  0
 BV BND1      LayerJump_2
 FX BND1      LayerJump_3  1
 BV BND1      LayerJump_3
 FX BND1      LayerJump_4  0
 BV BND1      LayerJump_4
 FX BND1      LayerJump_5  1
 BV BND1      LayerJump_5
 FX BND1      LayerJump_6  1
 BV BND1      LayerJump_6
 LO BND1      RE_1      -7
 UP BND1      RE_1      7
 LO BND1      RE_2      -7
 UP BND1      RE_2      7
 LO BND1      RE_3      -7
 UP BND1      RE_3      7
 LO BND1      RE_4      -7
 UP BND1      RE_4      7
 LO BND1      RE_5      -7
 UP BND1      RE_5      7
 LO BND1      RE_6      -7
 UP BND1      RE_6      7
 LO BND1      RE_7      -7
 UP BND1      RE_7      7
 LO BND1      max_overhang  0.5
 UP BND1      max_overhang  7
QCMATRIX   Bilinear_2_1
    F_2_1     P_2_1     -0.5
    P_2_1     F_2_1     -0.5
QCMATRIX   Bilinear_3_1
    F_3_1     P_3_1     -0.5
    P_3_1     F_3_1     -0.5
QCMATRIX   Bilinear_3_2
    F_3_2     P_3_2     -0.5
    P_3_2     F_3_2     -0.5
QCMATRIX   Bilinear_4_1
    F_4_1     P_4_1     -0.5
    P_4_1     F_4_1     -0.5
QCMATRIX   Bilinear_4_2
    F_4_2     P_4_2     -0.5
    P_4_2     F_4_2     -0.5
QCMATRIX   Bilinear_4_3
    F_4_3     P_4_3     -0.5
    P_4_3     F_4_3     -0.5
QCMATRIX   Bilinear_5_1
    F_5_1     P_5_1     -0.5
    P_5_1     F_5_1     -0.5
QCMATRIX   Bilinear_5_2
    F_5_2     P_5_2     -0.5
    P_5_2     F_5_2     -0.5
QCMATRIX   Bilinear_5_3
    F_5_3     P_5_3     -0.5
    P_5_3     F_5_3     -0.5
QCMATRIX   Bilinear_5_4
    F_5_4     P_5_4     -0.5
    P_5_4     F_5_4     -0.5
QCMATRIX   Bilinear_6_1
    F_6_1     P_6_1     -0.5
    P_6_1     F_6_1     -0.5
QCMATRIX   Bilinear_6_2
    F_6_2     P_6_2     -0.5
    P_6_2     F_6_2     -0.5
QCMATRIX   Bilinear_6_3
    F_6_3     P_6_3     -0.5
    P_6_3     F_6_3     -0.5
QCMATRIX   Bilinear_6_4
    F_6_4     P_6_4     -0.5
    P_6_4     F_6_4     -0.5
QCMATRIX   Bilinear_6_5
    F_6_5     P_6_5     -0.5
    P_6_5     F_6_5     -0.5
QCMATRIX   Bilinear_7_1
    F_7_1     P_7_1     -0.5
    P_7_1     F_7_1     -0.5
QCMATRIX   Bilinear_7_2
    F_7_2     P_7_2     -0.5
    P_7_2     F_7_2     -0.5
QCMATRIX   Bilinear_7_3
    F_7_3     P_7_3     -0.5
    P_7_3     F_7_3     -0.5
QCMATRIX   Bilinear_7_4
    F_7_4     P_7_4     -0.5
    P_7_4     F_7_4     -0.5
QCMATRIX   Bilinear_7_5
    F_7_5     P_7_5     -0.5
    P_7_5     F_7_5     -0.5
QCMATRIX   Bilinear_7_6
    F_7_6     P_7_6     -0.5
    P_7_6     F_7_6     -0.5
ENDATA
