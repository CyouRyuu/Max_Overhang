* Signature: 0xe7b07d41126ade0a
NAME TowerOfLire_M1_OrderPrune
OBJSENSE MAX
ROWS
 N  OBJ
 G  BaseContact_LB
 L  BaseContact_UB
 E  BaseTorque_Linear
 G  DAGSupMin_2
 L  DAGSupMax_2
 L  ForceCap_2_1
 G  PCapLB_2_1
 L  PCapUB_2_1
 G  TCapLB_2_1
 L  TCapUB_2_1
 G  R10     
 L  R11     
 G  R12     
 L  R13     
 L  LayerUB_2_1
 G  LayerLB_2_1
 G  DAGSupMin_3
 L  DAGSupMax_3
 L  ForceCap_3_1
 G  PCapLB_3_1
 L  PCapUB_3_1
 G  TCapLB_3_1
 L  TCapUB_3_1
 G  R23     
 L  R24     
 G  R25     
 L  R26     
 L  LayerUB_3_1
 G  LayerLB_3_1
 L  ForceCap_3_2
 G  PCapLB_3_2
 L  PCapUB_3_2
 G  TCapLB_3_2
 L  TCapUB_3_2
 G  R34     
 L  R35     
 G  R36     
 L  R37     
 L  LayerUB_3_2
 G  LayerLB_3_2
 G  DAGSupMin_4
 L  DAGSupMax_4
 L  ForceCap_4_1
 G  PCapLB_4_1
 L  PCapUB_4_1
 G  TCapLB_4_1
 L  TCapUB_4_1
 G  R47     
 L  R48     
 G  R49     
 L  R50     
 L  LayerUB_4_1
 G  LayerLB_4_1
 L  ForceCap_4_2
 G  PCapLB_4_2
 L  PCapUB_4_2
 G  TCapLB_4_2
 L  TCapUB_4_2
 G  R58     
 L  R59     
 G  R60     
 L  R61     
 L  LayerUB_4_2
 G  LayerLB_4_2
 L  ForceCap_4_3
 G  PCapLB_4_3
 L  PCapUB_4_3
 G  TCapLB_4_3
 L  TCapUB_4_3
 G  R69     
 L  R70     
 G  R71     
 L  R72     
 L  LayerUB_4_3
 G  LayerLB_4_3
 G  DAGSupMin_5
 L  DAGSupMax_5
 L  ForceCap_5_1
 G  PCapLB_5_1
 L  PCapUB_5_1
 G  TCapLB_5_1
 L  TCapUB_5_1
 G  R82     
 L  R83     
 G  R84     
 L  R85     
 L  LayerUB_5_1
 G  LayerLB_5_1
 L  ForceCap_5_2
 G  PCapLB_5_2
 L  PCapUB_5_2
 G  TCapLB_5_2
 L  TCapUB_5_2
 G  R93     
 L  R94     
 G  R95     
 L  R96     
 L  LayerUB_5_2
 G  LayerLB_5_2
 L  ForceCap_5_3
 G  PCapLB_5_3
 L  PCapUB_5_3
 G  TCapLB_5_3
 L  TCapUB_5_3
 G  R104    
 L  R105    
 G  R106    
 L  R107    
 L  LayerUB_5_3
 G  LayerLB_5_3
 L  ForceCap_5_4
 G  PCapLB_5_4
 L  PCapUB_5_4
 G  TCapLB_5_4
 L  TCapUB_5_4
 G  R115    
 L  R116    
 G  R117    
 L  R118    
 L  LayerUB_5_4
 G  LayerLB_5_4
 G  DAGSupMin_6
 L  DAGSupMax_6
 L  ForceCap_6_1
 G  PCapLB_6_1
 L  PCapUB_6_1
 G  TCapLB_6_1
 L  TCapUB_6_1
 G  R128    
 L  R129    
 G  R130    
 L  R131    
 L  LayerUB_6_1
 G  LayerLB_6_1
 L  ForceCap_6_2
 G  PCapLB_6_2
 L  PCapUB_6_2
 G  TCapLB_6_2
 L  TCapUB_6_2
 G  R139    
 L  R140    
 G  R141    
 L  R142    
 L  LayerUB_6_2
 G  LayerLB_6_2
 L  ForceCap_6_3
 G  PCapLB_6_3
 L  PCapUB_6_3
 G  TCapLB_6_3
 L  TCapUB_6_3
 G  R150    
 L  R151    
 G  R152    
 L  R153    
 L  LayerUB_6_3
 G  LayerLB_6_3
 L  ForceCap_6_4
 G  PCapLB_6_4
 L  PCapUB_6_4
 G  TCapLB_6_4
 L  TCapUB_6_4
 G  R161    
 L  R162    
 G  R163    
 L  R164    
 L  LayerUB_6_4
 G  LayerLB_6_4
 L  ForceCap_6_5
 G  PCapLB_6_5
 L  PCapUB_6_5
 G  TCapLB_6_5
 L  TCapUB_6_5
 G  R172    
 L  R173    
 G  R174    
 L  R175    
 L  LayerUB_6_5
 G  LayerLB_6_5
 G  DAGSupMin_7
 L  DAGSupMax_7
 L  ForceCap_7_1
 G  PCapLB_7_1
 L  PCapUB_7_1
 G  TCapLB_7_1
 L  TCapUB_7_1
 G  R185    
 L  R186    
 G  R187    
 L  R188    
 L  LayerUB_7_1
 G  LayerLB_7_1
 L  ForceCap_7_2
 G  PCapLB_7_2
 L  PCapUB_7_2
 G  TCapLB_7_2
 L  TCapUB_7_2
 G  R196    
 L  R197    
 G  R198    
 L  R199    
 L  LayerUB_7_2
 G  LayerLB_7_2
 L  ForceCap_7_3
 G  PCapLB_7_3
 L  PCapUB_7_3
 G  TCapLB_7_3
 L  TCapUB_7_3
 G  R207    
 L  R208    
 G  R209    
 L  R210    
 L  LayerUB_7_3
 G  LayerLB_7_3
 L  ForceCap_7_4
 G  PCapLB_7_4
 L  PCapUB_7_4
 G  TCapLB_7_4
 L  TCapUB_7_4
 G  R218    
 L  R219    
 G  R220    
 L  R221    
 L  LayerUB_7_4
 G  LayerLB_7_4
 L  ForceCap_7_5
 G  PCapLB_7_5
 L  PCapUB_7_5
 G  TCapLB_7_5
 L  TCapUB_7_5
 G  R229    
 L  R230    
 G  R231    
 L  R232    
 L  LayerUB_7_5
 G  LayerLB_7_5
 L  ForceCap_7_6
 G  PCapLB_7_6
 L  PCapUB_7_6
 G  TCapLB_7_6
 L  TCapUB_7_6
 G  R240    
 L  R241    
 G  R242    
 L  R243    
 L  LayerUB_7_6
 G  LayerLB_7_6
 G  DAGSupMin_8
 L  DAGSupMax_8
 L  ForceCap_8_1
 G  PCapLB_8_1
 L  PCapUB_8_1
 G  TCapLB_8_1
 L  TCapUB_8_1
 G  R253    
 L  R254    
 G  R255    
 L  R256    
 L  LayerUB_8_1
 G  LayerLB_8_1
 L  ForceCap_8_2
 G  PCapLB_8_2
 L  PCapUB_8_2
 G  TCapLB_8_2
 L  TCapUB_8_2
 G  R264    
 L  R265    
 G  R266    
 L  R267    
 L  LayerUB_8_2
 G  LayerLB_8_2
 L  ForceCap_8_3
 G  PCapLB_8_3
 L  PCapUB_8_3
 G  TCapLB_8_3
 L  TCapUB_8_3
 G  R275    
 L  R276    
 G  R277    
 L  R278    
 L  LayerUB_8_3
 G  LayerLB_8_3
 L  ForceCap_8_4
 G  PCapLB_8_4
 L  PCapUB_8_4
 G  TCapLB_8_4
 L  TCapUB_8_4
 G  R286    
 L  R287    
 G  R288    
 L  R289    
 L  LayerUB_8_4
 G  LayerLB_8_4
 L  ForceCap_8_5
 G  PCapLB_8_5
 L  PCapUB_8_5
 G  TCapLB_8_5
 L  TCapUB_8_5
 G  R297    
 L  R298    
 G  R299    
 L  R300    
 L  LayerUB_8_5
 G  LayerLB_8_5
 L  ForceCap_8_6
 G  PCapLB_8_6
 L  PCapUB_8_6
 G  TCapLB_8_6
 L  TCapUB_8_6
 G  R308    
 L  R309    
 G  R310    
 L  R311    
 L  LayerUB_8_6
 G  LayerLB_8_6
 L  ForceCap_8_7
 G  PCapLB_8_7
 L  PCapUB_8_7
 G  TCapLB_8_7
 L  TCapUB_8_7
 G  R319    
 L  R320    
 G  R321    
 L  R322    
 L  LayerUB_8_7
 G  LayerLB_8_7
 G  DAGSupMin_9
 L  DAGSupMax_9
 L  ForceCap_9_1
 G  PCapLB_9_1
 L  PCapUB_9_1
 G  TCapLB_9_1
 L  TCapUB_9_1
 G  R332    
 L  R333    
 G  R334    
 L  R335    
 L  LayerUB_9_1
 G  LayerLB_9_1
 L  ForceCap_9_2
 G  PCapLB_9_2
 L  PCapUB_9_2
 G  TCapLB_9_2
 L  TCapUB_9_2
 G  R343    
 L  R344    
 G  R345    
 L  R346    
 L  LayerUB_9_2
 G  LayerLB_9_2
 L  ForceCap_9_3
 G  PCapLB_9_3
 L  PCapUB_9_3
 G  TCapLB_9_3
 L  TCapUB_9_3
 G  R354    
 L  R355    
 G  R356    
 L  R357    
 L  LayerUB_9_3
 G  LayerLB_9_3
 L  ForceCap_9_4
 G  PCapLB_9_4
 L  PCapUB_9_4
 G  TCapLB_9_4
 L  TCapUB_9_4
 G  R365    
 L  R366    
 G  R367    
 L  R368    
 L  LayerUB_9_4
 G  LayerLB_9_4
 L  ForceCap_9_5
 G  PCapLB_9_5
 L  PCapUB_9_5
 G  TCapLB_9_5
 L  TCapUB_9_5
 G  R376    
 L  R377    
 G  R378    
 L  R379    
 L  LayerUB_9_5
 G  LayerLB_9_5
 L  ForceCap_9_6
 G  PCapLB_9_6
 L  PCapUB_9_6
 G  TCapLB_9_6
 L  TCapUB_9_6
 G  R387    
 L  R388    
 G  R389    
 L  R390    
 L  LayerUB_9_6
 G  LayerLB_9_6
 L  ForceCap_9_7
 G  PCapLB_9_7
 L  PCapUB_9_7
 G  TCapLB_9_7
 L  TCapUB_9_7
 G  R398    
 L  R399    
 G  R400    
 L  R401    
 L  LayerUB_9_7
 G  LayerLB_9_7
 L  ForceCap_9_8
 G  PCapLB_9_8
 L  PCapUB_9_8
 G  TCapLB_9_8
 L  TCapUB_9_8
 G  R409    
 L  R410    
 G  R411    
 L  R412    
 L  LayerUB_9_8
 G  LayerLB_9_8
 G  DAGSupMin_10
 L  DAGSupMax_10
 L  ForceCap_10_1
 G  PCapLB_10_1
 L  PCapUB_10_1
 G  TCapLB_10_1
 L  TCapUB_10_1
 G  R422    
 L  R423    
 G  R424    
 L  R425    
 L  LayerUB_10_1
 G  LayerLB_10_1
 L  ForceCap_10_2
 G  PCapLB_10_2
 L  PCapUB_10_2
 G  TCapLB_10_2
 L  TCapUB_10_2
 G  R433    
 L  R434    
 G  R435    
 L  R436    
 L  LayerUB_10_2
 G  LayerLB_10_2
 L  ForceCap_10_3
 G  PCapLB_10_3
 L  PCapUB_10_3
 G  TCapLB_10_3
 L  TCapUB_10_3
 G  R444    
 L  R445    
 G  R446    
 L  R447    
 L  LayerUB_10_3
 G  LayerLB_10_3
 L  ForceCap_10_4
 G  PCapLB_10_4
 L  PCapUB_10_4
 G  TCapLB_10_4
 L  TCapUB_10_4
 G  R455    
 L  R456    
 G  R457    
 L  R458    
 L  LayerUB_10_4
 G  LayerLB_10_4
 L  ForceCap_10_5
 G  PCapLB_10_5
 L  PCapUB_10_5
 G  TCapLB_10_5
 L  TCapUB_10_5
 G  R466    
 L  R467    
 G  R468    
 L  R469    
 L  LayerUB_10_5
 G  LayerLB_10_5
 L  ForceCap_10_6
 G  PCapLB_10_6
 L  PCapUB_10_6
 G  TCapLB_10_6
 L  TCapUB_10_6
 G  R477    
 L  R478    
 G  R479    
 L  R480    
 L  LayerUB_10_6
 G  LayerLB_10_6
 L  ForceCap_10_7
 G  PCapLB_10_7
 L  PCapUB_10_7
 G  TCapLB_10_7
 L  TCapUB_10_7
 G  R488    
 L  R489    
 G  R490    
 L  R491    
 L  LayerUB_10_7
 G  LayerLB_10_7
 L  ForceCap_10_8
 G  PCapLB_10_8
 L  PCapUB_10_8
 G  TCapLB_10_8
 L  TCapUB_10_8
 G  R499    
 L  R500    
 G  R501    
 L  R502    
 L  LayerUB_10_8
 G  LayerLB_10_8
 L  ForceCap_10_9
 G  PCapLB_10_9
 L  PCapUB_10_9
 G  TCapLB_10_9
 L  TCapUB_10_9
 G  R510    
 L  R511    
 G  R512    
 L  R513    
 L  LayerUB_10_9
 G  LayerLB_10_9
 G  DAGSupMin_11
 L  DAGSupMax_11
 L  ForceCap_11_1
 G  PCapLB_11_1
 L  PCapUB_11_1
 G  TCapLB_11_1
 L  TCapUB_11_1
 G  R523    
 L  R524    
 G  R525    
 L  R526    
 L  LayerUB_11_1
 G  LayerLB_11_1
 L  ForceCap_11_2
 G  PCapLB_11_2
 L  PCapUB_11_2
 G  TCapLB_11_2
 L  TCapUB_11_2
 G  R534    
 L  R535    
 G  R536    
 L  R537    
 L  LayerUB_11_2
 G  LayerLB_11_2
 L  ForceCap_11_3
 G  PCapLB_11_3
 L  PCapUB_11_3
 G  TCapLB_11_3
 L  TCapUB_11_3
 G  R545    
 L  R546    
 G  R547    
 L  R548    
 L  LayerUB_11_3
 G  LayerLB_11_3
 L  ForceCap_11_4
 G  PCapLB_11_4
 L  PCapUB_11_4
 G  TCapLB_11_4
 L  TCapUB_11_4
 G  R556    
 L  R557    
 G  R558    
 L  R559    
 L  LayerUB_11_4
 G  LayerLB_11_4
 L  ForceCap_11_5
 G  PCapLB_11_5
 L  PCapUB_11_5
 G  TCapLB_11_5
 L  TCapUB_11_5
 G  R567    
 L  R568    
 G  R569    
 L  R570    
 L  LayerUB_11_5
 G  LayerLB_11_5
 L  ForceCap_11_6
 G  PCapLB_11_6
 L  PCapUB_11_6
 G  TCapLB_11_6
 L  TCapUB_11_6
 G  R578    
 L  R579    
 G  R580    
 L  R581    
 L  LayerUB_11_6
 G  LayerLB_11_6
 L  ForceCap_11_7
 G  PCapLB_11_7
 L  PCapUB_11_7
 G  TCapLB_11_7
 L  TCapUB_11_7
 G  R589    
 L  R590    
 G  R591    
 L  R592    
 L  LayerUB_11_7
 G  LayerLB_11_7
 L  ForceCap_11_8
 G  PCapLB_11_8
 L  PCapUB_11_8
 G  TCapLB_11_8
 L  TCapUB_11_8
 G  R600    
 L  R601    
 G  R602    
 L  R603    
 L  LayerUB_11_8
 G  LayerLB_11_8
 L  ForceCap_11_9
 G  PCapLB_11_9
 L  PCapUB_11_9
 G  TCapLB_11_9
 L  TCapUB_11_9
 G  R611    
 L  R612    
 G  R613    
 L  R614    
 L  LayerUB_11_9
 G  LayerLB_11_9
 L  ForceCap_11_10
 G  PCapLB_11_10
 L  PCapUB_11_10
 G  TCapLB_11_10
 L  TCapUB_11_10
 G  R622    
 L  R623    
 G  R624    
 L  R625    
 L  LayerUB_11_10
 G  LayerLB_11_10
 G  DAGSupMin_12
 L  DAGSupMax_12
 L  ForceCap_12_1
 G  PCapLB_12_1
 L  PCapUB_12_1
 G  TCapLB_12_1
 L  TCapUB_12_1
 G  R635    
 L  R636    
 G  R637    
 L  R638    
 L  LayerUB_12_1
 G  LayerLB_12_1
 L  ForceCap_12_2
 G  PCapLB_12_2
 L  PCapUB_12_2
 G  TCapLB_12_2
 L  TCapUB_12_2
 G  R646    
 L  R647    
 G  R648    
 L  R649    
 L  LayerUB_12_2
 G  LayerLB_12_2
 L  ForceCap_12_3
 G  PCapLB_12_3
 L  PCapUB_12_3
 G  TCapLB_12_3
 L  TCapUB_12_3
 G  R657    
 L  R658    
 G  R659    
 L  R660    
 L  LayerUB_12_3
 G  LayerLB_12_3
 L  ForceCap_12_4
 G  PCapLB_12_4
 L  PCapUB_12_4
 G  TCapLB_12_4
 L  TCapUB_12_4
 G  R668    
 L  R669    
 G  R670    
 L  R671    
 L  LayerUB_12_4
 G  LayerLB_12_4
 L  ForceCap_12_5
 G  PCapLB_12_5
 L  PCapUB_12_5
 G  TCapLB_12_5
 L  TCapUB_12_5
 G  R679    
 L  R680    
 G  R681    
 L  R682    
 L  LayerUB_12_5
 G  LayerLB_12_5
 L  ForceCap_12_6
 G  PCapLB_12_6
 L  PCapUB_12_6
 G  TCapLB_12_6
 L  TCapUB_12_6
 G  R690    
 L  R691    
 G  R692    
 L  R693    
 L  LayerUB_12_6
 G  LayerLB_12_6
 L  ForceCap_12_7
 G  PCapLB_12_7
 L  PCapUB_12_7
 G  TCapLB_12_7
 L  TCapUB_12_7
 G  R701    
 L  R702    
 G  R703    
 L  R704    
 L  LayerUB_12_7
 G  LayerLB_12_7
 L  ForceCap_12_8
 G  PCapLB_12_8
 L  PCapUB_12_8
 G  TCapLB_12_8
 L  TCapUB_12_8
 G  R712    
 L  R713    
 G  R714    
 L  R715    
 L  LayerUB_12_8
 G  LayerLB_12_8
 L  ForceCap_12_9
 G  PCapLB_12_9
 L  PCapUB_12_9
 G  TCapLB_12_9
 L  TCapUB_12_9
 G  R723    
 L  R724    
 G  R725    
 L  R726    
 L  LayerUB_12_9
 G  LayerLB_12_9
 L  ForceCap_12_10
 G  PCapLB_12_10
 L  PCapUB_12_10
 G  TCapLB_12_10
 L  TCapUB_12_10
 G  R734    
 L  R735    
 G  R736    
 L  R737    
 L  LayerUB_12_10
 G  LayerLB_12_10
 L  ForceCap_12_11
 G  PCapLB_12_11
 L  PCapUB_12_11
 G  TCapLB_12_11
 L  TCapUB_12_11
 G  R745    
 L  R746    
 G  R747    
 L  R748    
 L  LayerUB_12_11
 G  LayerLB_12_11
 G  DAGSupMin_13
 L  DAGSupMax_13
 L  ForceCap_13_1
 G  PCapLB_13_1
 L  PCapUB_13_1
 G  TCapLB_13_1
 L  TCapUB_13_1
 G  R758    
 L  R759    
 G  R760    
 L  R761    
 L  LayerUB_13_1
 G  LayerLB_13_1
 L  ForceCap_13_2
 G  PCapLB_13_2
 L  PCapUB_13_2
 G  TCapLB_13_2
 L  TCapUB_13_2
 G  R769    
 L  R770    
 G  R771    
 L  R772    
 L  LayerUB_13_2
 G  LayerLB_13_2
 L  ForceCap_13_3
 G  PCapLB_13_3
 L  PCapUB_13_3
 G  TCapLB_13_3
 L  TCapUB_13_3
 G  R780    
 L  R781    
 G  R782    
 L  R783    
 L  LayerUB_13_3
 G  LayerLB_13_3
 L  ForceCap_13_4
 G  PCapLB_13_4
 L  PCapUB_13_4
 G  TCapLB_13_4
 L  TCapUB_13_4
 G  R791    
 L  R792    
 G  R793    
 L  R794    
 L  LayerUB_13_4
 G  LayerLB_13_4
 L  ForceCap_13_5
 G  PCapLB_13_5
 L  PCapUB_13_5
 G  TCapLB_13_5
 L  TCapUB_13_5
 G  R802    
 L  R803    
 G  R804    
 L  R805    
 L  LayerUB_13_5
 G  LayerLB_13_5
 L  ForceCap_13_6
 G  PCapLB_13_6
 L  PCapUB_13_6
 G  TCapLB_13_6
 L  TCapUB_13_6
 G  R813    
 L  R814    
 G  R815    
 L  R816    
 L  LayerUB_13_6
 G  LayerLB_13_6
 L  ForceCap_13_7
 G  PCapLB_13_7
 L  PCapUB_13_7
 G  TCapLB_13_7
 L  TCapUB_13_7
 G  R824    
 L  R825    
 G  R826    
 L  R827    
 L  LayerUB_13_7
 G  LayerLB_13_7
 L  ForceCap_13_8
 G  PCapLB_13_8
 L  PCapUB_13_8
 G  TCapLB_13_8
 L  TCapUB_13_8
 G  R835    
 L  R836    
 G  R837    
 L  R838    
 L  LayerUB_13_8
 G  LayerLB_13_8
 L  ForceCap_13_9
 G  PCapLB_13_9
 L  PCapUB_13_9
 G  TCapLB_13_9
 L  TCapUB_13_9
 G  R846    
 L  R847    
 G  R848    
 L  R849    
 L  LayerUB_13_9
 G  LayerLB_13_9
 L  ForceCap_13_10
 G  PCapLB_13_10
 L  PCapUB_13_10
 G  TCapLB_13_10
 L  TCapUB_13_10
 G  R857    
 L  R858    
 G  R859    
 L  R860    
 L  LayerUB_13_10
 G  LayerLB_13_10
 L  ForceCap_13_11
 G  PCapLB_13_11
 L  PCapUB_13_11
 G  TCapLB_13_11
 L  TCapUB_13_11
 G  R868    
 L  R869    
 G  R870    
 L  R871    
 L  LayerUB_13_11
 G  LayerLB_13_11
 L  ForceCap_13_12
 G  PCapLB_13_12
 L  PCapUB_13_12
 G  TCapLB_13_12
 L  TCapUB_13_12
 G  R879    
 L  R880    
 G  R881    
 L  R882    
 L  LayerUB_13_12
 G  LayerLB_13_12
 G  DAGSupMin_14
 L  DAGSupMax_14
 L  ForceCap_14_1
 G  PCapLB_14_1
 L  PCapUB_14_1
 G  TCapLB_14_1
 L  TCapUB_14_1
 G  R892    
 L  R893    
 G  R894    
 L  R895    
 L  LayerUB_14_1
 G  LayerLB_14_1
 L  ForceCap_14_2
 G  PCapLB_14_2
 L  PCapUB_14_2
 G  TCapLB_14_2
 L  TCapUB_14_2
 G  R903    
 L  R904    
 G  R905    
 L  R906    
 L  LayerUB_14_2
 G  LayerLB_14_2
 L  ForceCap_14_3
 G  PCapLB_14_3
 L  PCapUB_14_3
 G  TCapLB_14_3
 L  TCapUB_14_3
 G  R914    
 L  R915    
 G  R916    
 L  R917    
 L  LayerUB_14_3
 G  LayerLB_14_3
 L  ForceCap_14_4
 G  PCapLB_14_4
 L  PCapUB_14_4
 G  TCapLB_14_4
 L  TCapUB_14_4
 G  R925    
 L  R926    
 G  R927    
 L  R928    
 L  LayerUB_14_4
 G  LayerLB_14_4
 L  ForceCap_14_5
 G  PCapLB_14_5
 L  PCapUB_14_5
 G  TCapLB_14_5
 L  TCapUB_14_5
 G  R936    
 L  R937    
 G  R938    
 L  R939    
 L  LayerUB_14_5
 G  LayerLB_14_5
 L  ForceCap_14_6
 G  PCapLB_14_6
 L  PCapUB_14_6
 G  TCapLB_14_6
 L  TCapUB_14_6
 G  R947    
 L  R948    
 G  R949    
 L  R950    
 L  LayerUB_14_6
 G  LayerLB_14_6
 L  ForceCap_14_7
 G  PCapLB_14_7
 L  PCapUB_14_7
 G  TCapLB_14_7
 L  TCapUB_14_7
 G  R958    
 L  R959    
 G  R960    
 L  R961    
 L  LayerUB_14_7
 G  LayerLB_14_7
 L  ForceCap_14_8
 G  PCapLB_14_8
 L  PCapUB_14_8
 G  TCapLB_14_8
 L  TCapUB_14_8
 G  R969    
 L  R970    
 G  R971    
 L  R972    
 L  LayerUB_14_8
 G  LayerLB_14_8
 L  ForceCap_14_9
 G  PCapLB_14_9
 L  PCapUB_14_9
 G  TCapLB_14_9
 L  TCapUB_14_9
 G  R980    
 L  R981    
 G  R982    
 L  R983    
 L  LayerUB_14_9
 G  LayerLB_14_9
 L  ForceCap_14_10
 G  PCapLB_14_10
 L  PCapUB_14_10
 G  TCapLB_14_10
 L  TCapUB_14_10
 G  R991    
 L  R992    
 G  R993    
 L  R994    
 L  LayerUB_14_10
 G  LayerLB_14_10
 L  ForceCap_14_11
 G  PCapLB_14_11
 L  PCapUB_14_11
 G  TCapLB_14_11
 L  TCapUB_14_11
 G  R1002   
 L  R1003   
 G  R1004   
 L  R1005   
 L  LayerUB_14_11
 G  LayerLB_14_11
 L  ForceCap_14_12
 G  PCapLB_14_12
 L  PCapUB_14_12
 G  TCapLB_14_12
 L  TCapUB_14_12
 G  R1013   
 L  R1014   
 G  R1015   
 L  R1016   
 L  LayerUB_14_12
 G  LayerLB_14_12
 L  ForceCap_14_13
 G  PCapLB_14_13
 L  PCapUB_14_13
 G  TCapLB_14_13
 L  TCapUB_14_13
 G  R1024   
 L  R1025   
 G  R1026   
 L  R1027   
 L  LayerUB_14_13
 G  LayerLB_14_13
 G  DAGSupMin_15
 L  DAGSupMax_15
 L  ForceCap_15_1
 G  PCapLB_15_1
 L  PCapUB_15_1
 G  TCapLB_15_1
 L  TCapUB_15_1
 G  R1037   
 L  R1038   
 G  R1039   
 L  R1040   
 L  LayerUB_15_1
 G  LayerLB_15_1
 L  ForceCap_15_2
 G  PCapLB_15_2
 L  PCapUB_15_2
 G  TCapLB_15_2
 L  TCapUB_15_2
 G  R1048   
 L  R1049   
 G  R1050   
 L  R1051   
 L  LayerUB_15_2
 G  LayerLB_15_2
 L  ForceCap_15_3
 G  PCapLB_15_3
 L  PCapUB_15_3
 G  TCapLB_15_3
 L  TCapUB_15_3
 G  R1059   
 L  R1060   
 G  R1061   
 L  R1062   
 L  LayerUB_15_3
 G  LayerLB_15_3
 L  ForceCap_15_4
 G  PCapLB_15_4
 L  PCapUB_15_4
 G  TCapLB_15_4
 L  TCapUB_15_4
 G  R1070   
 L  R1071   
 G  R1072   
 L  R1073   
 L  LayerUB_15_4
 G  LayerLB_15_4
 L  ForceCap_15_5
 G  PCapLB_15_5
 L  PCapUB_15_5
 G  TCapLB_15_5
 L  TCapUB_15_5
 G  R1081   
 L  R1082   
 G  R1083   
 L  R1084   
 L  LayerUB_15_5
 G  LayerLB_15_5
 L  ForceCap_15_6
 G  PCapLB_15_6
 L  PCapUB_15_6
 G  TCapLB_15_6
 L  TCapUB_15_6
 G  R1092   
 L  R1093   
 G  R1094   
 L  R1095   
 L  LayerUB_15_6
 G  LayerLB_15_6
 L  ForceCap_15_7
 G  PCapLB_15_7
 L  PCapUB_15_7
 G  TCapLB_15_7
 L  TCapUB_15_7
 G  R1103   
 L  R1104   
 G  R1105   
 L  R1106   
 L  LayerUB_15_7
 G  LayerLB_15_7
 L  ForceCap_15_8
 G  PCapLB_15_8
 L  PCapUB_15_8
 G  TCapLB_15_8
 L  TCapUB_15_8
 G  R1114   
 L  R1115   
 G  R1116   
 L  R1117   
 L  LayerUB_15_8
 G  LayerLB_15_8
 L  ForceCap_15_9
 G  PCapLB_15_9
 L  PCapUB_15_9
 G  TCapLB_15_9
 L  TCapUB_15_9
 G  R1125   
 L  R1126   
 G  R1127   
 L  R1128   
 L  LayerUB_15_9
 G  LayerLB_15_9
 L  ForceCap_15_10
 G  PCapLB_15_10
 L  PCapUB_15_10
 G  TCapLB_15_10
 L  TCapUB_15_10
 G  R1136   
 L  R1137   
 G  R1138   
 L  R1139   
 L  LayerUB_15_10
 G  LayerLB_15_10
 L  ForceCap_15_11
 G  PCapLB_15_11
 L  PCapUB_15_11
 G  TCapLB_15_11
 L  TCapUB_15_11
 G  R1147   
 L  R1148   
 G  R1149   
 L  R1150   
 L  LayerUB_15_11
 G  LayerLB_15_11
 L  ForceCap_15_12
 G  PCapLB_15_12
 L  PCapUB_15_12
 G  TCapLB_15_12
 L  TCapUB_15_12
 G  R1158   
 L  R1159   
 G  R1160   
 L  R1161   
 L  LayerUB_15_12
 G  LayerLB_15_12
 L  ForceCap_15_13
 G  PCapLB_15_13
 L  PCapUB_15_13
 G  TCapLB_15_13
 L  TCapUB_15_13
 G  R1169   
 L  R1170   
 G  R1171   
 L  R1172   
 L  LayerUB_15_13
 G  LayerLB_15_13
 L  ForceCap_15_14
 G  PCapLB_15_14
 L  PCapUB_15_14
 G  TCapLB_15_14
 L  TCapUB_15_14
 G  R1180   
 L  R1181   
 G  R1182   
 L  R1183   
 L  LayerUB_15_14
 G  LayerLB_15_14
 G  DAGSupMin_16
 L  DAGSupMax_16
 L  ForceCap_16_1
 G  PCapLB_16_1
 L  PCapUB_16_1
 G  TCapLB_16_1
 L  TCapUB_16_1
 G  R1193   
 L  R1194   
 G  R1195   
 L  R1196   
 L  LayerUB_16_1
 G  LayerLB_16_1
 L  ForceCap_16_2
 G  PCapLB_16_2
 L  PCapUB_16_2
 G  TCapLB_16_2
 L  TCapUB_16_2
 G  R1204   
 L  R1205   
 G  R1206   
 L  R1207   
 L  LayerUB_16_2
 G  LayerLB_16_2
 L  ForceCap_16_3
 G  PCapLB_16_3
 L  PCapUB_16_3
 G  TCapLB_16_3
 L  TCapUB_16_3
 G  R1215   
 L  R1216   
 G  R1217   
 L  R1218   
 L  LayerUB_16_3
 G  LayerLB_16_3
 L  ForceCap_16_4
 G  PCapLB_16_4
 L  PCapUB_16_4
 G  TCapLB_16_4
 L  TCapUB_16_4
 G  R1226   
 L  R1227   
 G  R1228   
 L  R1229   
 L  LayerUB_16_4
 G  LayerLB_16_4
 L  ForceCap_16_5
 G  PCapLB_16_5
 L  PCapUB_16_5
 G  TCapLB_16_5
 L  TCapUB_16_5
 G  R1237   
 L  R1238   
 G  R1239   
 L  R1240   
 L  LayerUB_16_5
 G  LayerLB_16_5
 L  ForceCap_16_6
 G  PCapLB_16_6
 L  PCapUB_16_6
 G  TCapLB_16_6
 L  TCapUB_16_6
 G  R1248   
 L  R1249   
 G  R1250   
 L  R1251   
 L  LayerUB_16_6
 G  LayerLB_16_6
 L  ForceCap_16_7
 G  PCapLB_16_7
 L  PCapUB_16_7
 G  TCapLB_16_7
 L  TCapUB_16_7
 G  R1259   
 L  R1260   
 G  R1261   
 L  R1262   
 L  LayerUB_16_7
 G  LayerLB_16_7
 L  ForceCap_16_8
 G  PCapLB_16_8
 L  PCapUB_16_8
 G  TCapLB_16_8
 L  TCapUB_16_8
 G  R1270   
 L  R1271   
 G  R1272   
 L  R1273   
 L  LayerUB_16_8
 G  LayerLB_16_8
 L  ForceCap_16_9
 G  PCapLB_16_9
 L  PCapUB_16_9
 G  TCapLB_16_9
 L  TCapUB_16_9
 G  R1281   
 L  R1282   
 G  R1283   
 L  R1284   
 L  LayerUB_16_9
 G  LayerLB_16_9
 L  ForceCap_16_10
 G  PCapLB_16_10
 L  PCapUB_16_10
 G  TCapLB_16_10
 L  TCapUB_16_10
 G  R1292   
 L  R1293   
 G  R1294   
 L  R1295   
 L  LayerUB_16_10
 G  LayerLB_16_10
 L  ForceCap_16_11
 G  PCapLB_16_11
 L  PCapUB_16_11
 G  TCapLB_16_11
 L  TCapUB_16_11
 G  R1303   
 L  R1304   
 G  R1305   
 L  R1306   
 L  LayerUB_16_11
 G  LayerLB_16_11
 L  ForceCap_16_12
 G  PCapLB_16_12
 L  PCapUB_16_12
 G  TCapLB_16_12
 L  TCapUB_16_12
 G  R1314   
 L  R1315   
 G  R1316   
 L  R1317   
 L  LayerUB_16_12
 G  LayerLB_16_12
 L  ForceCap_16_13
 G  PCapLB_16_13
 L  PCapUB_16_13
 G  TCapLB_16_13
 L  TCapUB_16_13
 G  R1325   
 L  R1326   
 G  R1327   
 L  R1328   
 L  LayerUB_16_13
 G  LayerLB_16_13
 L  ForceCap_16_14
 G  PCapLB_16_14
 L  PCapUB_16_14
 G  TCapLB_16_14
 L  TCapUB_16_14
 G  R1336   
 L  R1337   
 G  R1338   
 L  R1339   
 L  LayerUB_16_14
 G  LayerLB_16_14
 L  ForceCap_16_15
 G  PCapLB_16_15
 L  PCapUB_16_15
 G  TCapLB_16_15
 L  TCapUB_16_15
 G  R1347   
 L  R1348   
 G  R1349   
 L  R1350   
 L  LayerUB_16_15
 G  LayerLB_16_15
 L  SymLayer_1
 G  R1354   
 L  R1355   
 G  NonOverlap_1
 L  SymLayer_2
 G  R1358   
 L  R1359   
 G  NonOverlap_2
 L  SymLayer_3
 G  R1362   
 L  R1363   
 G  NonOverlap_3
 L  SymLayer_4
 G  R1366   
 L  R1367   
 G  NonOverlap_4
 L  SymLayer_5
 G  R1370   
 L  R1371   
 G  NonOverlap_5
 L  SymLayer_6
 G  R1374   
 L  R1375   
 G  NonOverlap_6
 L  SymLayer_7
 G  R1378   
 L  R1379   
 G  NonOverlap_7
 L  SymLayer_8
 G  R1382   
 L  R1383   
 G  NonOverlap_8
 L  SymLayer_9
 G  R1386   
 L  R1387   
 G  NonOverlap_9
 L  SymLayer_10
 G  R1390   
 L  R1391   
 G  NonOverlap_10
 L  SymLayer_11
 G  R1394   
 L  R1395   
 G  NonOverlap_11
 L  SymLayer_12
 G  R1398   
 L  R1399   
 G  NonOverlap_12
 L  SymLayer_13
 G  R1402   
 L  R1403   
 G  NonOverlap_13
 L  SymLayer_14
 G  R1406   
 L  R1407   
 G  NonOverlap_14
 L  SymLayer_15
 G  R1410   
 L  R1411   
 G  NonOverlap_15
 E  Global_CoM
 E  ForceBal_1
 E  TorqueBal_1
 E  ForceBal_2
 E  TorqueBal_2
 E  ForceBal_3
 E  TorqueBal_3
 E  ForceBal_4
 E  TorqueBal_4
 E  ForceBal_5
 E  TorqueBal_5
 E  ForceBal_6
 E  TorqueBal_6
 E  ForceBal_7
 E  TorqueBal_7
 E  ForceBal_8
 E  TorqueBal_8
 E  ForceBal_9
 E  TorqueBal_9
 E  ForceBal_10
 E  TorqueBal_10
 E  ForceBal_11
 E  TorqueBal_11
 E  ForceBal_12
 E  TorqueBal_12
 E  ForceBal_13
 E  TorqueBal_13
 E  ForceBal_14
 E  TorqueBal_14
 E  ForceBal_15
 E  TorqueBal_15
 E  ForceBal_16
 E  TorqueBal_16
 E  R1446   
 E  R1447   
 E  R1448   
 E  R1449   
 E  R1450   
 E  R1451   
 E  R1452   
 E  R1453   
 E  R1454   
 E  R1455   
 E  R1456   
 E  R1457   
 E  R1458   
 E  R1459   
 E  R1460   
 E  R1461   
 G  S2_Lmin_3
 G  S2_Lmin_5
 G  S2_Lmin_6
 G  S2_Lmin_7
 G  S2_Lmin_9
 G  S2_Lmin_10
 G  S2_Lmin_11
 G  S2_Lmin_12
 G  S2_Lmin_13
 G  S2_Lmin_15
 G  S2_Lmin_16
 E  S2_T21  
 E  S2_T31  
 E  S2_T32  
 G  S2_F21lo
 L  S2_F21hi
 G  S2_F31lo
 L  S2_F31hi
 G  S2_sign2
 L  S2_sign3
 L  TightUp_2
 L  TightDn_2
 L  TightUp_3
 L  TightDn_3
 L  TightUp_4
 L  TightDn_4
 L  TightUp_5
 L  TightDn_5
 L  TightUp_6
 L  TightDn_6
 L  TightUp_7
 L  TightDn_7
 L  TightUp_8
 L  TightDn_8
 L  TightUp_9
 L  TightDn_9
 L  TightUp_10
 L  TightDn_10
 L  TightUp_11
 L  TightDn_11
 L  TightUp_12
 L  TightDn_12
 L  TightUp_13
 L  TightDn_13
 L  TightUp_14
 L  TightDn_14
 L  TightUp_15
 L  TightDn_15
 L  TightUp_16
 L  TightDn_16
 E  S4_BaseRightCorner
 G  C2_a    
 G  C2_b    
 L  C2_c    
 L  C2_d    
 L  RB_up_2 
 L  RB_dn_2 
 L  RB_up_3 
 L  RB_dn_3 
 L  RB_up_4 
 L  RB_dn_4 
 L  RB_up_5 
 L  RB_dn_5 
 L  RB_up_6 
 L  RB_dn_6 
 L  RB_up_7 
 L  RB_dn_7 
 L  RB_up_8 
 L  RB_dn_8 
 L  RB_up_9 
 L  RB_dn_9 
 L  RB_up_10
 L  RB_dn_10
 L  RB_up_11
 L  RB_dn_11
 L  RB_up_12
 L  RB_dn_12
 L  RB_up_13
 L  RB_dn_13
 L  RB_up_14
 L  RB_dn_14
 L  RB_up_15
 L  RB_dn_15
 L  RB_up_16
 L  RB_dn_16
 L  SP_3    
 L  SP_4    
 L  SP_5    
 L  SP_6    
 L  SP_7    
 L  SP_8    
 L  NC_10_12_8_9
 L  NC_13_14_10_12
 L  NC_13_15_10_11
 L  NC_13_15_10_12
 L  NC_13_15_11_12
 L  NC_14_15_10_12
 L  C2L_DeltaUB_2
 G  C2L_a_2 
 G  C2L_b_2 
 L  C2L_c_2 
 L  C2L_d_2 
 L  C2L_DeltaUB_3
 G  C2L_a_3 
 G  C2L_b_3 
 L  C2L_c_3 
 L  C2L_d_3 
 L  C2L_DeltaUB_4
 G  C2L_a_4 
 G  C2L_b_4 
 L  C2L_c_4 
 L  C2L_d_4 
 L  C2L_DeltaUB_5
 G  C2L_a_5 
 G  C2L_b_5 
 L  C2L_c_5 
 L  C2L_d_5 
 L  RM_dom_2
 L  RM_dom_3
 L  RM_dom_4
 L  RM_dom_5
 L  RM_dom_6
 L  RM_dom_8
 L  RM_dom_1
 G  RM_beats_cutoff
 G  NonSpinal_t0
 L  ImpureStep
 L  LowerSpine
 E  Bilinear_2_1
 E  Bilinear_3_1
 E  Bilinear_3_2
 E  Bilinear_4_1
 E  Bilinear_4_2
 E  Bilinear_4_3
 E  Bilinear_5_1
 E  Bilinear_5_2
 E  Bilinear_5_3
 E  Bilinear_5_4
 E  Bilinear_6_1
 E  Bilinear_6_2
 E  Bilinear_6_3
 E  Bilinear_6_4
 E  Bilinear_6_5
 E  Bilinear_7_1
 E  Bilinear_7_2
 E  Bilinear_7_3
 E  Bilinear_7_4
 E  Bilinear_7_5
 E  Bilinear_7_6
 E  Bilinear_8_1
 E  Bilinear_8_2
 E  Bilinear_8_3
 E  Bilinear_8_4
 E  Bilinear_8_5
 E  Bilinear_8_6
 E  Bilinear_8_7
 E  Bilinear_9_1
 E  Bilinear_9_2
 E  Bilinear_9_3
 E  Bilinear_9_4
 E  Bilinear_9_5
 E  Bilinear_9_6
 E  Bilinear_9_7
 E  Bilinear_9_8
 E  Bilinear_10_1
 E  Bilinear_10_2
 E  Bilinear_10_3
 E  Bilinear_10_4
 E  Bilinear_10_5
 E  Bilinear_10_6
 E  Bilinear_10_7
 E  Bilinear_10_8
 E  Bilinear_10_9
 E  Bilinear_11_1
 E  Bilinear_11_2
 E  Bilinear_11_3
 E  Bilinear_11_4
 E  Bilinear_11_5
 E  Bilinear_11_6
 E  Bilinear_11_7
 E  Bilinear_11_8
 E  Bilinear_11_9
 E  Bilinear_11_10
 E  Bilinear_12_1
 E  Bilinear_12_2
 E  Bilinear_12_3
 E  Bilinear_12_4
 E  Bilinear_12_5
 E  Bilinear_12_6
 E  Bilinear_12_7
 E  Bilinear_12_8
 E  Bilinear_12_9
 E  Bilinear_12_10
 E  Bilinear_12_11
 E  Bilinear_13_1
 E  Bilinear_13_2
 E  Bilinear_13_3
 E  Bilinear_13_4
 E  Bilinear_13_5
 E  Bilinear_13_6
 E  Bilinear_13_7
 E  Bilinear_13_8
 E  Bilinear_13_9
 E  Bilinear_13_10
 E  Bilinear_13_11
 E  Bilinear_13_12
 E  Bilinear_14_1
 E  Bilinear_14_2
 E  Bilinear_14_3
 E  Bilinear_14_4
 E  Bilinear_14_5
 E  Bilinear_14_6
 E  Bilinear_14_7
 E  Bilinear_14_8
 E  Bilinear_14_9
 E  Bilinear_14_10
 E  Bilinear_14_11
 E  Bilinear_14_12
 E  Bilinear_14_13
 E  Bilinear_15_1
 E  Bilinear_15_2
 E  Bilinear_15_3
 E  Bilinear_15_4
 E  Bilinear_15_5
 E  Bilinear_15_6
 E  Bilinear_15_7
 E  Bilinear_15_8
 E  Bilinear_15_9
 E  Bilinear_15_10
 E  Bilinear_15_11
 E  Bilinear_15_12
 E  Bilinear_15_13
 E  Bilinear_15_14
 E  Bilinear_16_1
 E  Bilinear_16_2
 E  Bilinear_16_3
 E  Bilinear_16_4
 E  Bilinear_16_5
 E  Bilinear_16_6
 E  Bilinear_16_7
 E  Bilinear_16_8
 E  Bilinear_16_9
 E  Bilinear_16_10
 E  Bilinear_16_11
 E  Bilinear_16_12
 E  Bilinear_16_13
 E  Bilinear_16_14
 E  Bilinear_16_15
COLUMNS
    X_0       OBJ       0
    X_1       BaseContact_LB  -1
    X_1       BaseContact_UB  -1
    X_1       R12       -1
    X_1       R13       -1
    X_1       R25       -1
    X_1       R26       -1
    X_1       R49       -1
    X_1       R50       -1
    X_1       R84       -1
    X_1       R85       -1
    X_1       R130      -1
    X_1       R131      -1
    X_1       R187      -1
    X_1       R188      -1
    X_1       R255      -1
    X_1       R256      -1
    X_1       R334      -1
    X_1       R335      -1
    X_1       R424      -1
    X_1       R425      -1
    X_1       R525      -1
    X_1       R526      -1
    X_1       R637      -1
    X_1       R638      -1
    X_1       R760      -1
    X_1       R761      -1
    X_1       R894      -1
    X_1       R895      -1
    X_1       R1039     -1
    X_1       R1040     -1
    X_1       R1195     -1
    X_1       R1196     -1
    X_1       NonOverlap_1  1
    X_1       Global_CoM  1
    X_1       TorqueBal_1  1
    X_1       R1446     -1
    X_1       S2_sign2  -1
    X_1       S2_sign3  -1
    X_1       TightUp_2  -1
    X_1       TightDn_2  1
    X_1       TightUp_3  -1
    X_1       TightDn_3  1
    X_1       TightUp_4  -1
    X_1       TightDn_4  1
    X_1       TightUp_5  -1
    X_1       TightDn_5  1
    X_1       TightUp_6  -1
    X_1       TightDn_6  1
    X_1       TightUp_7  -1
    X_1       TightDn_7  1
    X_1       TightUp_8  -1
    X_1       TightDn_8  1
    X_1       TightUp_9  -1
    X_1       TightDn_9  1
    X_1       TightUp_10  -1
    X_1       TightDn_10  1
    X_1       TightUp_11  -1
    X_1       TightDn_11  1
    X_1       TightUp_12  -1
    X_1       TightDn_12  1
    X_1       TightUp_13  -1
    X_1       TightDn_13  1
    X_1       TightUp_14  -1
    X_1       TightDn_14  1
    X_1       TightUp_15  -1
    X_1       TightDn_15  1
    X_1       TightUp_16  -1
    X_1       TightDn_16  1
    X_1       S4_BaseRightCorner  -1
    X_1       C2_a      -1
    X_1       C2_b      -1
    X_1       C2_c      -1
    X_1       C2_d      -1
    X_1       RB_up_2   -1
    X_1       RB_dn_2   1
    X_1       RB_up_3   -1
    X_1       RB_dn_3   1
    X_1       RB_up_4   -1
    X_1       RB_dn_4   1
    X_1       RB_up_5   -1
    X_1       RB_dn_5   1
    X_1       RB_up_6   -1
    X_1       RB_dn_6   1
    X_1       RB_up_7   -1
    X_1       RB_dn_7   1
    X_1       RB_up_8   -1
    X_1       RB_dn_8   1
    X_1       RB_up_9   -1
    X_1       RB_dn_9   1
    X_1       RB_up_10  -1
    X_1       RB_dn_10  1
    X_1       RB_up_11  -1
    X_1       RB_dn_11  1
    X_1       RB_up_12  -1
    X_1       RB_dn_12  1
    X_1       RB_up_13  -1
    X_1       RB_dn_13  1
    X_1       RB_up_14  -1
    X_1       RB_dn_14  1
    X_1       RB_up_15  -1
    X_1       RB_dn_15  1
    X_1       RB_up_16  -1
    X_1       RB_dn_16  1
    X_1       RM_dom_1  1
    X_2       R10       -1
    X_2       R11       -1
    X_2       R36       -1
    X_2       R37       -1
    X_2       R60       -1
    X_2       R61       -1
    X_2       R95       -1
    X_2       R96       -1
    X_2       R141      -1
    X_2       R142      -1
    X_2       R198      -1
    X_2       R199      -1
    X_2       R266      -1
    X_2       R267      -1
    X_2       R345      -1
    X_2       R346      -1
    X_2       R435      -1
    X_2       R436      -1
    X_2       R536      -1
    X_2       R537      -1
    X_2       R648      -1
    X_2       R649      -1
    X_2       R771      -1
    X_2       R772      -1
    X_2       R905      -1
    X_2       R906      -1
    X_2       R1050     -1
    X_2       R1051     -1
    X_2       R1206     -1
    X_2       R1207     -1
    X_2       NonOverlap_1  -1
    X_2       NonOverlap_2  1
    X_2       Global_CoM  1
    X_2       TorqueBal_2  1
    X_2       R1447     -1
    X_2       S2_sign2  1
    X_2       TightUp_2  1
    X_2       TightDn_2  -1
    X_2       RB_up_2   1
    X_2       RB_dn_2   -1
    X_2       C2L_DeltaUB_2  1
    X_2       C2L_b_2   -13
    X_2       C2L_c_2   -13
    X_2       RM_dom_2  1
    X_2       ImpureStep  -1
    X_2       LowerSpine  1
    X_3       R23       -1
    X_3       R24       -1
    X_3       R34       -1
    X_3       R35       -1
    X_3       R71       -1
    X_3       R72       -1
    X_3       R106      -1
    X_3       R107      -1
    X_3       R152      -1
    X_3       R153      -1
    X_3       R209      -1
    X_3       R210      -1
    X_3       R277      -1
    X_3       R278      -1
    X_3       R356      -1
    X_3       R357      -1
    X_3       R446      -1
    X_3       R447      -1
    X_3       R547      -1
    X_3       R548      -1
    X_3       R659      -1
    X_3       R660      -1
    X_3       R782      -1
    X_3       R783      -1
    X_3       R916      -1
    X_3       R917      -1
    X_3       R1061     -1
    X_3       R1062     -1
    X_3       R1217     -1
    X_3       R1218     -1
    X_3       NonOverlap_2  -1
    X_3       NonOverlap_3  1
    X_3       Global_CoM  1
    X_3       TorqueBal_3  1
    X_3       R1448     -1
    X_3       S2_sign3  1
    X_3       TightUp_3  1
    X_3       TightDn_3  -1
    X_3       RB_up_3   1
    X_3       RB_dn_3   -1
    X_3       C2L_DeltaUB_2  -1
    X_3       C2L_a_2   -13
    X_3       C2L_d_2   -13
    X_4       R47       -1
    X_4       R48       -1
    X_4       R58       -1
    X_4       R59       -1
    X_4       R69       -1
    X_4       R70       -1
    X_4       R117      -1
    X_4       R118      -1
    X_4       R163      -1
    X_4       R164      -1
    X_4       R220      -1
    X_4       R221      -1
    X_4       R288      -1
    X_4       R289      -1
    X_4       R367      -1
    X_4       R368      -1
    X_4       R457      -1
    X_4       R458      -1
    X_4       R558      -1
    X_4       R559      -1
    X_4       R670      -1
    X_4       R671      -1
    X_4       R793      -1
    X_4       R794      -1
    X_4       R927      -1
    X_4       R928      -1
    X_4       R1072     -1
    X_4       R1073     -1
    X_4       R1228     -1
    X_4       R1229     -1
    X_4       NonOverlap_3  -1
    X_4       NonOverlap_4  1
    X_4       Global_CoM  1
    X_4       TorqueBal_4  1
    X_4       R1449     -1
    X_4       TightUp_4  1
    X_4       TightDn_4  -1
    X_4       RB_up_4   1
    X_4       RB_dn_4   -1
    X_4       SP_3      1
    X_4       C2L_a_2   1
    X_4       C2L_b_2   1
    X_4       C2L_c_2   1
    X_4       C2L_d_2   1
    X_4       C2L_DeltaUB_3  1
    X_4       C2L_b_3   -11
    X_4       C2L_c_3   -11
    X_4       RM_dom_3  1
    X_4       ImpureStep  1
    X_5       R82       -1
    X_5       R83       -1
    X_5       R93       -1
    X_5       R94       -1
    X_5       R104      -1
    X_5       R105      -1
    X_5       R115      -1
    X_5       R116      -1
    X_5       R174      -1
    X_5       R175      -1
    X_5       R231      -1
    X_5       R232      -1
    X_5       R299      -1
    X_5       R300      -1
    X_5       R378      -1
    X_5       R379      -1
    X_5       R468      -1
    X_5       R469      -1
    X_5       R569      -1
    X_5       R570      -1
    X_5       R681      -1
    X_5       R682      -1
    X_5       R804      -1
    X_5       R805      -1
    X_5       R938      -1
    X_5       R939      -1
    X_5       R1083     -1
    X_5       R1084     -1
    X_5       R1239     -1
    X_5       R1240     -1
    X_5       NonOverlap_4  -1
    X_5       NonOverlap_5  1
    X_5       Global_CoM  1
    X_5       TorqueBal_5  1
    X_5       R1450     -1
    X_5       TightUp_5  1
    X_5       TightDn_5  -1
    X_5       RB_up_5   1
    X_5       RB_dn_5   -1
    X_5       C2L_a_2   1
    X_5       C2L_b_2   1
    X_5       C2L_c_2   1
    X_5       C2L_d_2   1
    X_5       C2L_DeltaUB_3  -1
    X_5       C2L_a_3   -11
    X_5       C2L_d_3   -11
    X_6       R128      -1
    X_6       R129      -1
    X_6       R139      -1
    X_6       R140      -1
    X_6       R150      -1
    X_6       R151      -1
    X_6       R161      -1
    X_6       R162      -1
    X_6       R172      -1
    X_6       R173      -1
    X_6       R242      -1
    X_6       R243      -1
    X_6       R310      -1
    X_6       R311      -1
    X_6       R389      -1
    X_6       R390      -1
    X_6       R479      -1
    X_6       R480      -1
    X_6       R580      -1
    X_6       R581      -1
    X_6       R692      -1
    X_6       R693      -1
    X_6       R815      -1
    X_6       R816      -1
    X_6       R949      -1
    X_6       R950      -1
    X_6       R1094     -1
    X_6       R1095     -1
    X_6       R1250     -1
    X_6       R1251     -1
    X_6       NonOverlap_5  -1
    X_6       NonOverlap_6  1
    X_6       Global_CoM  1
    X_6       TorqueBal_6  1
    X_6       R1451     -1
    X_6       TightUp_6  1
    X_6       TightDn_6  -1
    X_6       RB_up_6   1
    X_6       RB_dn_6   -1
    X_6       SP_4      1
    X_6       C2L_a_2   1
    X_6       C2L_b_2   1
    X_6       C2L_c_2   1
    X_6       C2L_d_2   1
    X_6       C2L_a_3   1
    X_6       C2L_b_3   1
    X_6       C2L_c_3   1
    X_6       C2L_d_3   1
    X_6       C2L_DeltaUB_4  1
    X_6       C2L_b_4   -9
    X_6       C2L_c_4   -9
    X_6       RM_dom_4  1
    X_7       R185      -1
    X_7       R186      -1
    X_7       R196      -1
    X_7       R197      -1
    X_7       R207      -1
    X_7       R208      -1
    X_7       R218      -1
    X_7       R219      -1
    X_7       R229      -1
    X_7       R230      -1
    X_7       R240      -1
    X_7       R241      -1
    X_7       R321      -1
    X_7       R322      -1
    X_7       R400      -1
    X_7       R401      -1
    X_7       R490      -1
    X_7       R491      -1
    X_7       R591      -1
    X_7       R592      -1
    X_7       R703      -1
    X_7       R704      -1
    X_7       R826      -1
    X_7       R827      -1
    X_7       R960      -1
    X_7       R961      -1
    X_7       R1105     -1
    X_7       R1106     -1
    X_7       R1261     -1
    X_7       R1262     -1
    X_7       NonOverlap_6  -1
    X_7       NonOverlap_7  1
    X_7       Global_CoM  1
    X_7       TorqueBal_7  1
    X_7       R1452     -1
    X_7       TightUp_7  1
    X_7       TightDn_7  -1
    X_7       RB_up_7   1
    X_7       RB_dn_7   -1
    X_7       C2L_a_2   1
    X_7       C2L_b_2   1
    X_7       C2L_c_2   1
    X_7       C2L_d_2   1
    X_7       C2L_a_3   1
    X_7       C2L_b_3   1
    X_7       C2L_c_3   1
    X_7       C2L_d_3   1
    X_7       C2L_DeltaUB_4  -1
    X_7       C2L_a_4   -9
    X_7       C2L_d_4   -9
    X_8       R253      -1
    X_8       R254      -1
    X_8       R264      -1
    X_8       R265      -1
    X_8       R275      -1
    X_8       R276      -1
    X_8       R286      -1
    X_8       R287      -1
    X_8       R297      -1
    X_8       R298      -1
    X_8       R308      -1
    X_8       R309      -1
    X_8       R319      -1
    X_8       R320      -1
    X_8       R411      -1
    X_8       R412      -1
    X_8       R501      -1
    X_8       R502      -1
    X_8       R602      -1
    X_8       R603      -1
    X_8       R714      -1
    X_8       R715      -1
    X_8       R837      -1
    X_8       R838      -1
    X_8       R971      -1
    X_8       R972      -1
    X_8       R1116     -1
    X_8       R1117     -1
    X_8       R1272     -1
    X_8       R1273     -1
    X_8       NonOverlap_7  -1
    X_8       NonOverlap_8  1
    X_8       Global_CoM  1
    X_8       TorqueBal_8  1
    X_8       R1453     -1
    X_8       TightUp_8  1
    X_8       TightDn_8  -1
    X_8       RB_up_8   1
    X_8       RB_dn_8   -1
    X_8       SP_5      1
    X_8       C2L_a_2   1
    X_8       C2L_b_2   1
    X_8       C2L_c_2   1
    X_8       C2L_d_2   1
    X_8       C2L_a_3   1
    X_8       C2L_b_3   1
    X_8       C2L_c_3   1
    X_8       C2L_d_3   1
    X_8       C2L_a_4   1
    X_8       C2L_b_4   1
    X_8       C2L_c_4   1
    X_8       C2L_d_4   1
    X_8       C2L_DeltaUB_5  1
    X_8       C2L_b_5   -7
    X_8       C2L_c_5   -7
    X_8       RM_dom_5  1
    X_9       R332      -1
    X_9       R333      -1
    X_9       R343      -1
    X_9       R344      -1
    X_9       R354      -1
    X_9       R355      -1
    X_9       R365      -1
    X_9       R366      -1
    X_9       R376      -1
    X_9       R377      -1
    X_9       R387      -1
    X_9       R388      -1
    X_9       R398      -1
    X_9       R399      -1
    X_9       R409      -1
    X_9       R410      -1
    X_9       R512      -1
    X_9       R513      -1
    X_9       R613      -1
    X_9       R614      -1
    X_9       R725      -1
    X_9       R726      -1
    X_9       R848      -1
    X_9       R849      -1
    X_9       R982      -1
    X_9       R983      -1
    X_9       R1127     -1
    X_9       R1128     -1
    X_9       R1283     -1
    X_9       R1284     -1
    X_9       NonOverlap_8  -1
    X_9       NonOverlap_9  1
    X_9       Global_CoM  1
    X_9       TorqueBal_9  1
    X_9       R1454     -1
    X_9       TightUp_9  1
    X_9       TightDn_9  -1
    X_9       RB_up_9   1
    X_9       RB_dn_9   -1
    X_9       C2L_a_2   1
    X_9       C2L_b_2   1
    X_9       C2L_c_2   1
    X_9       C2L_d_2   1
    X_9       C2L_a_3   1
    X_9       C2L_b_3   1
    X_9       C2L_c_3   1
    X_9       C2L_d_3   1
    X_9       C2L_a_4   1
    X_9       C2L_b_4   1
    X_9       C2L_c_4   1
    X_9       C2L_d_4   1
    X_9       C2L_DeltaUB_5  -1
    X_9       C2L_a_5   -7
    X_9       C2L_d_5   -7
    X_10      R422      -1
    X_10      R423      -1
    X_10      R433      -1
    X_10      R434      -1
    X_10      R444      -1
    X_10      R445      -1
    X_10      R455      -1
    X_10      R456      -1
    X_10      R466      -1
    X_10      R467      -1
    X_10      R477      -1
    X_10      R478      -1
    X_10      R488      -1
    X_10      R489      -1
    X_10      R499      -1
    X_10      R500      -1
    X_10      R510      -1
    X_10      R511      -1
    X_10      R624      -1
    X_10      R625      -1
    X_10      R736      -1
    X_10      R737      -1
    X_10      R859      -1
    X_10      R860      -1
    X_10      R993      -1
    X_10      R994      -1
    X_10      R1138     -1
    X_10      R1139     -1
    X_10      R1294     -1
    X_10      R1295     -1
    X_10      NonOverlap_9  -1
    X_10      NonOverlap_10  1
    X_10      Global_CoM  1
    X_10      TorqueBal_10  1
    X_10      R1455     -1
    X_10      TightUp_10  1
    X_10      TightDn_10  -1
    X_10      RB_up_10  1
    X_10      RB_dn_10  -1
    X_10      SP_6      1
    X_10      C2L_a_2   1
    X_10      C2L_b_2   1
    X_10      C2L_c_2   1
    X_10      C2L_d_2   1
    X_10      C2L_a_3   1
    X_10      C2L_b_3   1
    X_10      C2L_c_3   1
    X_10      C2L_d_3   1
    X_10      C2L_a_4   1
    X_10      C2L_b_4   1
    X_10      C2L_c_4   1
    X_10      C2L_d_4   1
    X_10      C2L_a_5   1
    X_10      C2L_b_5   1
    X_10      C2L_c_5   1
    X_10      C2L_d_5   1
    X_10      RM_dom_6  1
    X_11      R523      -1
    X_11      R524      -1
    X_11      R534      -1
    X_11      R535      -1
    X_11      R545      -1
    X_11      R546      -1
    X_11      R556      -1
    X_11      R557      -1
    X_11      R567      -1
    X_11      R568      -1
    X_11      R578      -1
    X_11      R579      -1
    X_11      R589      -1
    X_11      R590      -1
    X_11      R600      -1
    X_11      R601      -1
    X_11      R611      -1
    X_11      R612      -1
    X_11      R622      -1
    X_11      R623      -1
    X_11      R747      -1
    X_11      R748      -1
    X_11      R870      -1
    X_11      R871      -1
    X_11      R1004     -1
    X_11      R1005     -1
    X_11      R1149     -1
    X_11      R1150     -1
    X_11      R1305     -1
    X_11      R1306     -1
    X_11      NonOverlap_10  -1
    X_11      NonOverlap_11  1
    X_11      Global_CoM  1
    X_11      TorqueBal_11  1
    X_11      R1456     -1
    X_11      TightUp_11  1
    X_11      TightDn_11  -1
    X_11      RB_up_11  1
    X_11      RB_dn_11  -1
    X_11      C2L_a_2   1
    X_11      C2L_b_2   1
    X_11      C2L_c_2   1
    X_11      C2L_d_2   1
    X_11      C2L_a_3   1
    X_11      C2L_b_3   1
    X_11      C2L_c_3   1
    X_11      C2L_d_3   1
    X_11      C2L_a_4   1
    X_11      C2L_b_4   1
    X_11      C2L_c_4   1
    X_11      C2L_d_4   1
    X_11      C2L_a_5   1
    X_11      C2L_b_5   1
    X_11      C2L_c_5   1
    X_11      C2L_d_5   1
    X_12      R635      -1
    X_12      R636      -1
    X_12      R646      -1
    X_12      R647      -1
    X_12      R657      -1
    X_12      R658      -1
    X_12      R668      -1
    X_12      R669      -1
    X_12      R679      -1
    X_12      R680      -1
    X_12      R690      -1
    X_12      R691      -1
    X_12      R701      -1
    X_12      R702      -1
    X_12      R712      -1
    X_12      R713      -1
    X_12      R723      -1
    X_12      R724      -1
    X_12      R734      -1
    X_12      R735      -1
    X_12      R745      -1
    X_12      R746      -1
    X_12      R881      -1
    X_12      R882      -1
    X_12      R1015     -1
    X_12      R1016     -1
    X_12      R1160     -1
    X_12      R1161     -1
    X_12      R1316     -1
    X_12      R1317     -1
    X_12      NonOverlap_11  -1
    X_12      NonOverlap_12  1
    X_12      Global_CoM  1
    X_12      TorqueBal_12  1
    X_12      R1457     -1
    X_12      TightUp_12  1
    X_12      TightDn_12  -1
    X_12      RB_up_12  1
    X_12      RB_dn_12  -1
    X_12      C2L_a_2   1
    X_12      C2L_b_2   1
    X_12      C2L_c_2   1
    X_12      C2L_d_2   1
    X_12      C2L_a_3   1
    X_12      C2L_b_3   1
    X_12      C2L_c_3   1
    X_12      C2L_d_3   1
    X_12      C2L_a_4   1
    X_12      C2L_b_4   1
    X_12      C2L_c_4   1
    X_12      C2L_d_4   1
    X_12      C2L_a_5   1
    X_12      C2L_b_5   1
    X_12      C2L_c_5   1
    X_12      C2L_d_5   1
    X_13      OBJ       1
    X_13      R758      -1
    X_13      R759      -1
    X_13      R769      -1
    X_13      R770      -1
    X_13      R780      -1
    X_13      R781      -1
    X_13      R791      -1
    X_13      R792      -1
    X_13      R802      -1
    X_13      R803      -1
    X_13      R813      -1
    X_13      R814      -1
    X_13      R824      -1
    X_13      R825      -1
    X_13      R835      -1
    X_13      R836      -1
    X_13      R846      -1
    X_13      R847      -1
    X_13      R857      -1
    X_13      R858      -1
    X_13      R868      -1
    X_13      R869      -1
    X_13      R879      -1
    X_13      R880      -1
    X_13      R1026     -1
    X_13      R1027     -1
    X_13      R1171     -1
    X_13      R1172     -1
    X_13      R1327     -1
    X_13      R1328     -1
    X_13      NonOverlap_12  -1
    X_13      NonOverlap_13  1
    X_13      Global_CoM  1
    X_13      TorqueBal_13  1
    X_13      R1458     -1
    X_13      TightUp_13  1
    X_13      TightDn_13  -1
    X_13      RB_up_13  1
    X_13      RB_dn_13  -1
    X_13      SP_7      1
    X_13      C2L_a_2   1
    X_13      C2L_b_2   1
    X_13      C2L_c_2   1
    X_13      C2L_d_2   1
    X_13      C2L_a_3   1
    X_13      C2L_b_3   1
    X_13      C2L_c_3   1
    X_13      C2L_d_3   1
    X_13      C2L_a_4   1
    X_13      C2L_b_4   1
    X_13      C2L_c_4   1
    X_13      C2L_d_4   1
    X_13      C2L_a_5   1
    X_13      C2L_b_5   1
    X_13      C2L_c_5   1
    X_13      C2L_d_5   1
    X_13      RM_dom_2  -1
    X_13      RM_dom_3  -1
    X_13      RM_dom_4  -1
    X_13      RM_dom_5  -1
    X_13      RM_dom_6  -1
    X_13      RM_dom_8  -1
    X_13      RM_dom_1  -1
    X_13      RM_beats_cutoff  1
    X_14      R892      -1
    X_14      R893      -1
    X_14      R903      -1
    X_14      R904      -1
    X_14      R914      -1
    X_14      R915      -1
    X_14      R925      -1
    X_14      R926      -1
    X_14      R936      -1
    X_14      R937      -1
    X_14      R947      -1
    X_14      R948      -1
    X_14      R958      -1
    X_14      R959      -1
    X_14      R969      -1
    X_14      R970      -1
    X_14      R980      -1
    X_14      R981      -1
    X_14      R991      -1
    X_14      R992      -1
    X_14      R1002     -1
    X_14      R1003     -1
    X_14      R1013     -1
    X_14      R1014     -1
    X_14      R1024     -1
    X_14      R1025     -1
    X_14      R1182     -1
    X_14      R1183     -1
    X_14      R1338     -1
    X_14      R1339     -1
    X_14      NonOverlap_13  -1
    X_14      NonOverlap_14  1
    X_14      Global_CoM  1
    X_14      TorqueBal_14  1
    X_14      R1459     -1
    X_14      TightUp_14  1
    X_14      TightDn_14  -1
    X_14      RB_up_14  1
    X_14      RB_dn_14  -1
    X_14      C2L_a_2   1
    X_14      C2L_b_2   1
    X_14      C2L_c_2   1
    X_14      C2L_d_2   1
    X_14      C2L_a_3   1
    X_14      C2L_b_3   1
    X_14      C2L_c_3   1
    X_14      C2L_d_3   1
    X_14      C2L_a_4   1
    X_14      C2L_b_4   1
    X_14      C2L_c_4   1
    X_14      C2L_d_4   1
    X_14      C2L_a_5   1
    X_14      C2L_b_5   1
    X_14      C2L_c_5   1
    X_14      C2L_d_5   1
    X_15      R1037     -1
    X_15      R1038     -1
    X_15      R1048     -1
    X_15      R1049     -1
    X_15      R1059     -1
    X_15      R1060     -1
    X_15      R1070     -1
    X_15      R1071     -1
    X_15      R1081     -1
    X_15      R1082     -1
    X_15      R1092     -1
    X_15      R1093     -1
    X_15      R1103     -1
    X_15      R1104     -1
    X_15      R1114     -1
    X_15      R1115     -1
    X_15      R1125     -1
    X_15      R1126     -1
    X_15      R1136     -1
    X_15      R1137     -1
    X_15      R1147     -1
    X_15      R1148     -1
    X_15      R1158     -1
    X_15      R1159     -1
    X_15      R1169     -1
    X_15      R1170     -1
    X_15      R1180     -1
    X_15      R1181     -1
    X_15      R1349     -1
    X_15      R1350     -1
    X_15      NonOverlap_14  -1
    X_15      NonOverlap_15  1
    X_15      Global_CoM  1
    X_15      TorqueBal_15  1
    X_15      R1460     -1
    X_15      TightUp_15  1
    X_15      TightDn_15  -1
    X_15      RB_up_15  1
    X_15      RB_dn_15  -1
    X_15      C2L_a_2   1
    X_15      C2L_b_2   1
    X_15      C2L_c_2   1
    X_15      C2L_d_2   1
    X_15      C2L_a_3   1
    X_15      C2L_b_3   1
    X_15      C2L_c_3   1
    X_15      C2L_d_3   1
    X_15      C2L_a_4   1
    X_15      C2L_b_4   1
    X_15      C2L_c_4   1
    X_15      C2L_d_4   1
    X_15      C2L_a_5   1
    X_15      C2L_b_5   1
    X_15      C2L_c_5   1
    X_15      C2L_d_5   1
    X_16      R1193     -1
    X_16      R1194     -1
    X_16      R1204     -1
    X_16      R1205     -1
    X_16      R1215     -1
    X_16      R1216     -1
    X_16      R1226     -1
    X_16      R1227     -1
    X_16      R1237     -1
    X_16      R1238     -1
    X_16      R1248     -1
    X_16      R1249     -1
    X_16      R1259     -1
    X_16      R1260     -1
    X_16      R1270     -1
    X_16      R1271     -1
    X_16      R1281     -1
    X_16      R1282     -1
    X_16      R1292     -1
    X_16      R1293     -1
    X_16      R1303     -1
    X_16      R1304     -1
    X_16      R1314     -1
    X_16      R1315     -1
    X_16      R1325     -1
    X_16      R1326     -1
    X_16      R1336     -1
    X_16      R1337     -1
    X_16      R1347     -1
    X_16      R1348     -1
    X_16      NonOverlap_15  -1
    X_16      Global_CoM  1
    X_16      TorqueBal_16  1
    X_16      R1461     -1
    X_16      TightUp_16  1
    X_16      TightDn_16  -1
    X_16      RB_up_16  1
    X_16      RB_dn_16  -1
    X_16      SP_8      1
    X_16      C2L_a_2   1
    X_16      C2L_b_2   1
    X_16      C2L_c_2   1
    X_16      C2L_d_2   1
    X_16      C2L_a_3   1
    X_16      C2L_b_3   1
    X_16      C2L_c_3   1
    X_16      C2L_d_3   1
    X_16      C2L_a_4   1
    X_16      C2L_b_4   1
    X_16      C2L_c_4   1
    X_16      C2L_d_4   1
    X_16      C2L_a_5   1
    X_16      C2L_b_5   1
    X_16      C2L_c_5   1
    X_16      C2L_d_5   1
    X_16      RM_dom_8  1
    MARKER    'MARKER'                 'INTORG'
    L_0       OBJ       0
    L_1       LayerUB_2_1  -1
    L_1       LayerLB_2_1  -1
    L_1       LayerUB_3_1  -1
    L_1       LayerLB_3_1  -1
    L_1       LayerUB_4_1  -1
    L_1       LayerLB_4_1  -1
    L_1       LayerUB_5_1  -1
    L_1       LayerLB_5_1  -1
    L_1       LayerUB_6_1  -1
    L_1       LayerLB_6_1  -1
    L_1       LayerUB_7_1  -1
    L_1       LayerLB_7_1  -1
    L_1       LayerUB_8_1  -1
    L_1       LayerLB_8_1  -1
    L_1       LayerUB_9_1  -1
    L_1       LayerLB_9_1  -1
    L_1       LayerUB_10_1  -1
    L_1       LayerLB_10_1  -1
    L_1       LayerUB_11_1  -1
    L_1       LayerLB_11_1  -1
    L_1       LayerUB_12_1  -1
    L_1       LayerLB_12_1  -1
    L_1       LayerUB_13_1  -1
    L_1       LayerLB_13_1  -1
    L_1       LayerUB_14_1  -1
    L_1       LayerLB_14_1  -1
    L_1       LayerUB_15_1  -1
    L_1       LayerLB_15_1  -1
    L_1       LayerUB_16_1  -1
    L_1       LayerLB_16_1  -1
    L_1       SymLayer_1  1
    L_1       R1354     -1
    L_1       R1355     -1
    L_2       LayerUB_2_1  1
    L_2       LayerLB_2_1  1
    L_2       LayerUB_3_2  -1
    L_2       LayerLB_3_2  -1
    L_2       LayerUB_4_2  -1
    L_2       LayerLB_4_2  -1
    L_2       LayerUB_5_2  -1
    L_2       LayerLB_5_2  -1
    L_2       LayerUB_6_2  -1
    L_2       LayerLB_6_2  -1
    L_2       LayerUB_7_2  -1
    L_2       LayerLB_7_2  -1
    L_2       LayerUB_8_2  -1
    L_2       LayerLB_8_2  -1
    L_2       LayerUB_9_2  -1
    L_2       LayerLB_9_2  -1
    L_2       LayerUB_10_2  -1
    L_2       LayerLB_10_2  -1
    L_2       LayerUB_11_2  -1
    L_2       LayerLB_11_2  -1
    L_2       LayerUB_12_2  -1
    L_2       LayerLB_12_2  -1
    L_2       LayerUB_13_2  -1
    L_2       LayerLB_13_2  -1
    L_2       LayerUB_14_2  -1
    L_2       LayerLB_14_2  -1
    L_2       LayerUB_15_2  -1
    L_2       LayerLB_15_2  -1
    L_2       LayerUB_16_2  -1
    L_2       LayerLB_16_2  -1
    L_2       SymLayer_1  -1
    L_2       R1354     1
    L_2       R1355     1
    L_2       SymLayer_2  1
    L_2       R1358     -1
    L_2       R1359     -1
    L_2       TightUp_2  -1
    L_2       TightDn_2  -1
    L_3       LayerUB_3_1  1
    L_3       LayerLB_3_1  1
    L_3       LayerUB_3_2  1
    L_3       LayerLB_3_2  1
    L_3       LayerUB_4_3  -1
    L_3       LayerLB_4_3  -1
    L_3       LayerUB_5_3  -1
    L_3       LayerLB_5_3  -1
    L_3       LayerUB_6_3  -1
    L_3       LayerLB_6_3  -1
    L_3       LayerUB_7_3  -1
    L_3       LayerLB_7_3  -1
    L_3       LayerUB_8_3  -1
    L_3       LayerLB_8_3  -1
    L_3       LayerUB_9_3  -1
    L_3       LayerLB_9_3  -1
    L_3       LayerUB_10_3  -1
    L_3       LayerLB_10_3  -1
    L_3       LayerUB_11_3  -1
    L_3       LayerLB_11_3  -1
    L_3       LayerUB_12_3  -1
    L_3       LayerLB_12_3  -1
    L_3       LayerUB_13_3  -1
    L_3       LayerLB_13_3  -1
    L_3       LayerUB_14_3  -1
    L_3       LayerLB_14_3  -1
    L_3       LayerUB_15_3  -1
    L_3       LayerLB_15_3  -1
    L_3       LayerUB_16_3  -1
    L_3       LayerLB_16_3  -1
    L_3       SymLayer_2  -1
    L_3       R1358     1
    L_3       R1359     1
    L_3       SymLayer_3  1
    L_3       R1362     -1
    L_3       R1363     -1
    L_3       S2_Lmin_3  1
    L_3       TightUp_3  -1
    L_3       TightDn_3  -1
    L_4       LayerUB_4_1  1
    L_4       LayerLB_4_1  1
    L_4       LayerUB_4_2  1
    L_4       LayerLB_4_2  1
    L_4       LayerUB_4_3  1
    L_4       LayerLB_4_3  1
    L_4       LayerUB_5_4  -1
    L_4       LayerLB_5_4  -1
    L_4       LayerUB_6_4  -1
    L_4       LayerLB_6_4  -1
    L_4       LayerUB_7_4  -1
    L_4       LayerLB_7_4  -1
    L_4       LayerUB_8_4  -1
    L_4       LayerLB_8_4  -1
    L_4       LayerUB_9_4  -1
    L_4       LayerLB_9_4  -1
    L_4       LayerUB_10_4  -1
    L_4       LayerLB_10_4  -1
    L_4       LayerUB_11_4  -1
    L_4       LayerLB_11_4  -1
    L_4       LayerUB_12_4  -1
    L_4       LayerLB_12_4  -1
    L_4       LayerUB_13_4  -1
    L_4       LayerLB_13_4  -1
    L_4       LayerUB_14_4  -1
    L_4       LayerLB_14_4  -1
    L_4       LayerUB_15_4  -1
    L_4       LayerLB_15_4  -1
    L_4       LayerUB_16_4  -1
    L_4       LayerLB_16_4  -1
    L_4       SymLayer_3  -1
    L_4       R1362     1
    L_4       R1363     1
    L_4       SymLayer_4  1
    L_4       R1366     -1
    L_4       R1367     -1
    L_4       TightUp_4  -1
    L_4       TightDn_4  -1
    L_5       LayerUB_5_1  1
    L_5       LayerLB_5_1  1
    L_5       LayerUB_5_2  1
    L_5       LayerLB_5_2  1
    L_5       LayerUB_5_3  1
    L_5       LayerLB_5_3  1
    L_5       LayerUB_5_4  1
    L_5       LayerLB_5_4  1
    L_5       LayerUB_6_5  -1
    L_5       LayerLB_6_5  -1
    L_5       LayerUB_7_5  -1
    L_5       LayerLB_7_5  -1
    L_5       LayerUB_8_5  -1
    L_5       LayerLB_8_5  -1
    L_5       LayerUB_9_5  -1
    L_5       LayerLB_9_5  -1
    L_5       LayerUB_10_5  -1
    L_5       LayerLB_10_5  -1
    L_5       LayerUB_11_5  -1
    L_5       LayerLB_11_5  -1
    L_5       LayerUB_12_5  -1
    L_5       LayerLB_12_5  -1
    L_5       LayerUB_13_5  -1
    L_5       LayerLB_13_5  -1
    L_5       LayerUB_14_5  -1
    L_5       LayerLB_14_5  -1
    L_5       LayerUB_15_5  -1
    L_5       LayerLB_15_5  -1
    L_5       LayerUB_16_5  -1
    L_5       LayerLB_16_5  -1
    L_5       SymLayer_4  -1
    L_5       R1366     1
    L_5       R1367     1
    L_5       SymLayer_5  1
    L_5       R1370     -1
    L_5       R1371     -1
    L_5       S2_Lmin_5  1
    L_5       TightUp_5  -1
    L_5       TightDn_5  -1
    L_6       LayerUB_6_1  1
    L_6       LayerLB_6_1  1
    L_6       LayerUB_6_2  1
    L_6       LayerLB_6_2  1
    L_6       LayerUB_6_3  1
    L_6       LayerLB_6_3  1
    L_6       LayerUB_6_4  1
    L_6       LayerLB_6_4  1
    L_6       LayerUB_6_5  1
    L_6       LayerLB_6_5  1
    L_6       LayerUB_7_6  -1
    L_6       LayerLB_7_6  -1
    L_6       LayerUB_8_6  -1
    L_6       LayerLB_8_6  -1
    L_6       LayerUB_9_6  -1
    L_6       LayerLB_9_6  -1
    L_6       LayerUB_10_6  -1
    L_6       LayerLB_10_6  -1
    L_6       LayerUB_11_6  -1
    L_6       LayerLB_11_6  -1
    L_6       LayerUB_12_6  -1
    L_6       LayerLB_12_6  -1
    L_6       LayerUB_13_6  -1
    L_6       LayerLB_13_6  -1
    L_6       LayerUB_14_6  -1
    L_6       LayerLB_14_6  -1
    L_6       LayerUB_15_6  -1
    L_6       LayerLB_15_6  -1
    L_6       LayerUB_16_6  -1
    L_6       LayerLB_16_6  -1
    L_6       SymLayer_5  -1
    L_6       R1370     1
    L_6       R1371     1
    L_6       SymLayer_6  1
    L_6       R1374     -1
    L_6       R1375     -1
    L_6       S2_Lmin_6  1
    L_6       TightUp_6  -1
    L_6       TightDn_6  -1
    L_7       LayerUB_7_1  1
    L_7       LayerLB_7_1  1
    L_7       LayerUB_7_2  1
    L_7       LayerLB_7_2  1
    L_7       LayerUB_7_3  1
    L_7       LayerLB_7_3  1
    L_7       LayerUB_7_4  1
    L_7       LayerLB_7_4  1
    L_7       LayerUB_7_5  1
    L_7       LayerLB_7_5  1
    L_7       LayerUB_7_6  1
    L_7       LayerLB_7_6  1
    L_7       LayerUB_8_7  -1
    L_7       LayerLB_8_7  -1
    L_7       LayerUB_9_7  -1
    L_7       LayerLB_9_7  -1
    L_7       LayerUB_10_7  -1
    L_7       LayerLB_10_7  -1
    L_7       LayerUB_11_7  -1
    L_7       LayerLB_11_7  -1
    L_7       LayerUB_12_7  -1
    L_7       LayerLB_12_7  -1
    L_7       LayerUB_13_7  -1
    L_7       LayerLB_13_7  -1
    L_7       LayerUB_14_7  -1
    L_7       LayerLB_14_7  -1
    L_7       LayerUB_15_7  -1
    L_7       LayerLB_15_7  -1
    L_7       LayerUB_16_7  -1
    L_7       LayerLB_16_7  -1
    L_7       SymLayer_6  -1
    L_7       R1374     1
    L_7       R1375     1
    L_7       SymLayer_7  1
    L_7       R1378     -1
    L_7       R1379     -1
    L_7       S2_Lmin_7  1
    L_7       TightUp_7  -1
    L_7       TightDn_7  -1
    L_8       LayerUB_8_1  1
    L_8       LayerLB_8_1  1
    L_8       LayerUB_8_2  1
    L_8       LayerLB_8_2  1
    L_8       LayerUB_8_3  1
    L_8       LayerLB_8_3  1
    L_8       LayerUB_8_4  1
    L_8       LayerLB_8_4  1
    L_8       LayerUB_8_5  1
    L_8       LayerLB_8_5  1
    L_8       LayerUB_8_6  1
    L_8       LayerLB_8_6  1
    L_8       LayerUB_8_7  1
    L_8       LayerLB_8_7  1
    L_8       LayerUB_9_8  -1
    L_8       LayerLB_9_8  -1
    L_8       LayerUB_10_8  -1
    L_8       LayerLB_10_8  -1
    L_8       LayerUB_11_8  -1
    L_8       LayerLB_11_8  -1
    L_8       LayerUB_12_8  -1
    L_8       LayerLB_12_8  -1
    L_8       LayerUB_13_8  -1
    L_8       LayerLB_13_8  -1
    L_8       LayerUB_14_8  -1
    L_8       LayerLB_14_8  -1
    L_8       LayerUB_15_8  -1
    L_8       LayerLB_15_8  -1
    L_8       LayerUB_16_8  -1
    L_8       LayerLB_16_8  -1
    L_8       SymLayer_7  -1
    L_8       R1378     1
    L_8       R1379     1
    L_8       SymLayer_8  1
    L_8       R1382     -1
    L_8       R1383     -1
    L_8       TightUp_8  -1
    L_8       TightDn_8  -1
    L_9       LayerUB_9_1  1
    L_9       LayerLB_9_1  1
    L_9       LayerUB_9_2  1
    L_9       LayerLB_9_2  1
    L_9       LayerUB_9_3  1
    L_9       LayerLB_9_3  1
    L_9       LayerUB_9_4  1
    L_9       LayerLB_9_4  1
    L_9       LayerUB_9_5  1
    L_9       LayerLB_9_5  1
    L_9       LayerUB_9_6  1
    L_9       LayerLB_9_6  1
    L_9       LayerUB_9_7  1
    L_9       LayerLB_9_7  1
    L_9       LayerUB_9_8  1
    L_9       LayerLB_9_8  1
    L_9       LayerUB_10_9  -1
    L_9       LayerLB_10_9  -1
    L_9       LayerUB_11_9  -1
    L_9       LayerLB_11_9  -1
    L_9       LayerUB_12_9  -1
    L_9       LayerLB_12_9  -1
    L_9       LayerUB_13_9  -1
    L_9       LayerLB_13_9  -1
    L_9       LayerUB_14_9  -1
    L_9       LayerLB_14_9  -1
    L_9       LayerUB_15_9  -1
    L_9       LayerLB_15_9  -1
    L_9       LayerUB_16_9  -1
    L_9       LayerLB_16_9  -1
    L_9       SymLayer_8  -1
    L_9       R1382     1
    L_9       R1383     1
    L_9       SymLayer_9  1
    L_9       R1386     -1
    L_9       R1387     -1
    L_9       S2_Lmin_9  1
    L_9       TightUp_9  -1
    L_9       TightDn_9  -1
    L_10      LayerUB_10_1  1
    L_10      LayerLB_10_1  1
    L_10      LayerUB_10_2  1
    L_10      LayerLB_10_2  1
    L_10      LayerUB_10_3  1
    L_10      LayerLB_10_3  1
    L_10      LayerUB_10_4  1
    L_10      LayerLB_10_4  1
    L_10      LayerUB_10_5  1
    L_10      LayerLB_10_5  1
    L_10      LayerUB_10_6  1
    L_10      LayerLB_10_6  1
    L_10      LayerUB_10_7  1
    L_10      LayerLB_10_7  1
    L_10      LayerUB_10_8  1
    L_10      LayerLB_10_8  1
    L_10      LayerUB_10_9  1
    L_10      LayerLB_10_9  1
    L_10      LayerUB_11_10  -1
    L_10      LayerLB_11_10  -1
    L_10      LayerUB_12_10  -1
    L_10      LayerLB_12_10  -1
    L_10      LayerUB_13_10  -1
    L_10      LayerLB_13_10  -1
    L_10      LayerUB_14_10  -1
    L_10      LayerLB_14_10  -1
    L_10      LayerUB_15_10  -1
    L_10      LayerLB_15_10  -1
    L_10      LayerUB_16_10  -1
    L_10      LayerLB_16_10  -1
    L_10      SymLayer_9  -1
    L_10      R1386     1
    L_10      R1387     1
    L_10      SymLayer_10  1
    L_10      R1390     -1
    L_10      R1391     -1
    L_10      S2_Lmin_10  1
    L_10      TightUp_10  -1
    L_10      TightDn_10  -1
    L_11      LayerUB_11_1  1
    L_11      LayerLB_11_1  1
    L_11      LayerUB_11_2  1
    L_11      LayerLB_11_2  1
    L_11      LayerUB_11_3  1
    L_11      LayerLB_11_3  1
    L_11      LayerUB_11_4  1
    L_11      LayerLB_11_4  1
    L_11      LayerUB_11_5  1
    L_11      LayerLB_11_5  1
    L_11      LayerUB_11_6  1
    L_11      LayerLB_11_6  1
    L_11      LayerUB_11_7  1
    L_11      LayerLB_11_7  1
    L_11      LayerUB_11_8  1
    L_11      LayerLB_11_8  1
    L_11      LayerUB_11_9  1
    L_11      LayerLB_11_9  1
    L_11      LayerUB_11_10  1
    L_11      LayerLB_11_10  1
    L_11      LayerUB_12_11  -1
    L_11      LayerLB_12_11  -1
    L_11      LayerUB_13_11  -1
    L_11      LayerLB_13_11  -1
    L_11      LayerUB_14_11  -1
    L_11      LayerLB_14_11  -1
    L_11      LayerUB_15_11  -1
    L_11      LayerLB_15_11  -1
    L_11      LayerUB_16_11  -1
    L_11      LayerLB_16_11  -1
    L_11      SymLayer_10  -1
    L_11      R1390     1
    L_11      R1391     1
    L_11      SymLayer_11  1
    L_11      R1394     -1
    L_11      R1395     -1
    L_11      S2_Lmin_11  1
    L_11      TightUp_11  -1
    L_11      TightDn_11  -1
    L_12      LayerUB_12_1  1
    L_12      LayerLB_12_1  1
    L_12      LayerUB_12_2  1
    L_12      LayerLB_12_2  1
    L_12      LayerUB_12_3  1
    L_12      LayerLB_12_3  1
    L_12      LayerUB_12_4  1
    L_12      LayerLB_12_4  1
    L_12      LayerUB_12_5  1
    L_12      LayerLB_12_5  1
    L_12      LayerUB_12_6  1
    L_12      LayerLB_12_6  1
    L_12      LayerUB_12_7  1
    L_12      LayerLB_12_7  1
    L_12      LayerUB_12_8  1
    L_12      LayerLB_12_8  1
    L_12      LayerUB_12_9  1
    L_12      LayerLB_12_9  1
    L_12      LayerUB_12_10  1
    L_12      LayerLB_12_10  1
    L_12      LayerUB_12_11  1
    L_12      LayerLB_12_11  1
    L_12      LayerUB_13_12  -1
    L_12      LayerLB_13_12  -1
    L_12      LayerUB_14_12  -1
    L_12      LayerLB_14_12  -1
    L_12      LayerUB_15_12  -1
    L_12      LayerLB_15_12  -1
    L_12      LayerUB_16_12  -1
    L_12      LayerLB_16_12  -1
    L_12      SymLayer_11  -1
    L_12      R1394     1
    L_12      R1395     1
    L_12      SymLayer_12  1
    L_12      R1398     -1
    L_12      R1399     -1
    L_12      S2_Lmin_12  1
    L_12      TightUp_12  -1
    L_12      TightDn_12  -1
    L_13      LayerUB_13_1  1
    L_13      LayerLB_13_1  1
    L_13      LayerUB_13_2  1
    L_13      LayerLB_13_2  1
    L_13      LayerUB_13_3  1
    L_13      LayerLB_13_3  1
    L_13      LayerUB_13_4  1
    L_13      LayerLB_13_4  1
    L_13      LayerUB_13_5  1
    L_13      LayerLB_13_5  1
    L_13      LayerUB_13_6  1
    L_13      LayerLB_13_6  1
    L_13      LayerUB_13_7  1
    L_13      LayerLB_13_7  1
    L_13      LayerUB_13_8  1
    L_13      LayerLB_13_8  1
    L_13      LayerUB_13_9  1
    L_13      LayerLB_13_9  1
    L_13      LayerUB_13_10  1
    L_13      LayerLB_13_10  1
    L_13      LayerUB_13_11  1
    L_13      LayerLB_13_11  1
    L_13      LayerUB_13_12  1
    L_13      LayerLB_13_12  1
    L_13      LayerUB_14_13  -1
    L_13      LayerLB_14_13  -1
    L_13      LayerUB_15_13  -1
    L_13      LayerLB_15_13  -1
    L_13      LayerUB_16_13  -1
    L_13      LayerLB_16_13  -1
    L_13      SymLayer_12  -1
    L_13      R1398     1
    L_13      R1399     1
    L_13      SymLayer_13  1
    L_13      R1402     -1
    L_13      R1403     -1
    L_13      S2_Lmin_13  1
    L_13      TightUp_13  -1
    L_13      TightDn_13  -1
    L_14      LayerUB_14_1  1
    L_14      LayerLB_14_1  1
    L_14      LayerUB_14_2  1
    L_14      LayerLB_14_2  1
    L_14      LayerUB_14_3  1
    L_14      LayerLB_14_3  1
    L_14      LayerUB_14_4  1
    L_14      LayerLB_14_4  1
    L_14      LayerUB_14_5  1
    L_14      LayerLB_14_5  1
    L_14      LayerUB_14_6  1
    L_14      LayerLB_14_6  1
    L_14      LayerUB_14_7  1
    L_14      LayerLB_14_7  1
    L_14      LayerUB_14_8  1
    L_14      LayerLB_14_8  1
    L_14      LayerUB_14_9  1
    L_14      LayerLB_14_9  1
    L_14      LayerUB_14_10  1
    L_14      LayerLB_14_10  1
    L_14      LayerUB_14_11  1
    L_14      LayerLB_14_11  1
    L_14      LayerUB_14_12  1
    L_14      LayerLB_14_12  1
    L_14      LayerUB_14_13  1
    L_14      LayerLB_14_13  1
    L_14      LayerUB_15_14  -1
    L_14      LayerLB_15_14  -1
    L_14      LayerUB_16_14  -1
    L_14      LayerLB_16_14  -1
    L_14      SymLayer_13  -1
    L_14      R1402     1
    L_14      R1403     1
    L_14      SymLayer_14  1
    L_14      R1406     -1
    L_14      R1407     -1
    L_14      TightUp_14  -1
    L_14      TightDn_14  -1
    L_15      LayerUB_15_1  1
    L_15      LayerLB_15_1  1
    L_15      LayerUB_15_2  1
    L_15      LayerLB_15_2  1
    L_15      LayerUB_15_3  1
    L_15      LayerLB_15_3  1
    L_15      LayerUB_15_4  1
    L_15      LayerLB_15_4  1
    L_15      LayerUB_15_5  1
    L_15      LayerLB_15_5  1
    L_15      LayerUB_15_6  1
    L_15      LayerLB_15_6  1
    L_15      LayerUB_15_7  1
    L_15      LayerLB_15_7  1
    L_15      LayerUB_15_8  1
    L_15      LayerLB_15_8  1
    L_15      LayerUB_15_9  1
    L_15      LayerLB_15_9  1
    L_15      LayerUB_15_10  1
    L_15      LayerLB_15_10  1
    L_15      LayerUB_15_11  1
    L_15      LayerLB_15_11  1
    L_15      LayerUB_15_12  1
    L_15      LayerLB_15_12  1
    L_15      LayerUB_15_13  1
    L_15      LayerLB_15_13  1
    L_15      LayerUB_15_14  1
    L_15      LayerLB_15_14  1
    L_15      LayerUB_16_15  -1
    L_15      LayerLB_16_15  -1
    L_15      SymLayer_14  -1
    L_15      R1406     1
    L_15      R1407     1
    L_15      SymLayer_15  1
    L_15      R1410     -1
    L_15      R1411     -1
    L_15      S2_Lmin_15  1
    L_15      TightUp_15  -1
    L_15      TightDn_15  -1
    L_16      LayerUB_16_1  1
    L_16      LayerLB_16_1  1
    L_16      LayerUB_16_2  1
    L_16      LayerLB_16_2  1
    L_16      LayerUB_16_3  1
    L_16      LayerLB_16_3  1
    L_16      LayerUB_16_4  1
    L_16      LayerLB_16_4  1
    L_16      LayerUB_16_5  1
    L_16      LayerLB_16_5  1
    L_16      LayerUB_16_6  1
    L_16      LayerLB_16_6  1
    L_16      LayerUB_16_7  1
    L_16      LayerLB_16_7  1
    L_16      LayerUB_16_8  1
    L_16      LayerLB_16_8  1
    L_16      LayerUB_16_9  1
    L_16      LayerLB_16_9  1
    L_16      LayerUB_16_10  1
    L_16      LayerLB_16_10  1
    L_16      LayerUB_16_11  1
    L_16      LayerLB_16_11  1
    L_16      LayerUB_16_12  1
    L_16      LayerLB_16_12  1
    L_16      LayerUB_16_13  1
    L_16      LayerLB_16_13  1
    L_16      LayerUB_16_14  1
    L_16      LayerLB_16_14  1
    L_16      LayerUB_16_15  1
    L_16      LayerLB_16_15  1
    L_16      SymLayer_15  -1
    L_16      R1410     1
    L_16      R1411     1
    L_16      S2_Lmin_16  1
    L_16      TightUp_16  -1
    L_16      TightDn_16  -1
    T_1_0     OBJ       0
    MARKER    'MARKER'                 'INTEND'
    F_1_0     ForceBal_1  -1
    P_1_0     BaseContact_LB  1
    P_1_0     BaseContact_UB  1
    P_1_0     BaseTorque_Linear  -16
    Torque_1_0  BaseTorque_Linear  1
    Torque_1_0  TorqueBal_1  -1
    Torque_1_0  C2_a      1
    Torque_1_0  C2_b      1
    Torque_1_0  C2_c      1
    Torque_1_0  C2_d      1
    MARKER    'MARKER'                 'INTORG'
    T_2_1     DAGSupMin_2  1
    T_2_1     DAGSupMax_2  1
    T_2_1     ForceCap_2_1  -15
    T_2_1     PCapLB_2_1  16
    T_2_1     PCapUB_2_1  -16
    T_2_1     TCapLB_2_1  240
    T_2_1     TCapUB_2_1  -240
    T_2_1     R10       -33
    T_2_1     R11       33
    T_2_1     R12       -33
    T_2_1     R13       33
    T_2_1     LayerUB_2_1  1
    T_2_1     LayerLB_2_1  -1
    T_2_1     S2_T21    1
    MARKER    'MARKER'                 'INTEND'
    F_2_1     ForceCap_2_1  1
    F_2_1     ForceBal_1  1
    F_2_1     ForceBal_2  -1
    F_2_1     S2_F21lo  1
    F_2_1     S2_F21hi  1
    F_2_1     C2_b      -1
    F_2_1     C2_d      -1
    P_2_1     PCapLB_2_1  1
    P_2_1     PCapUB_2_1  1
    P_2_1     R10       1
    P_2_1     R11       1
    P_2_1     R12       1
    P_2_1     R13       1
    P_2_1     S4_BaseRightCorner  1
    P_2_1     C2_a      -1
    P_2_1     C2_b      -14
    P_2_1     C2_c      -14
    P_2_1     C2_d      -1
    Torque_2_1  TCapLB_2_1  1
    Torque_2_1  TCapUB_2_1  1
    Torque_2_1  TorqueBal_1  1
    Torque_2_1  TorqueBal_2  -1
    Torque_2_1  Bilinear_2_1  1
    MARKER    'MARKER'                 'INTORG'
    T_3_1     DAGSupMin_3  1
    T_3_1     DAGSupMax_3  1
    T_3_1     ForceCap_3_1  -14
    T_3_1     PCapLB_3_1  16
    T_3_1     PCapUB_3_1  -16
    T_3_1     TCapLB_3_1  224
    T_3_1     TCapUB_3_1  -224
    T_3_1     R23       -33
    T_3_1     R24       33
    T_3_1     R25       -33
    T_3_1     R26       33
    T_3_1     LayerUB_3_1  2
    T_3_1     LayerLB_3_1  -1
    T_3_1     S2_T31    1
    MARKER    'MARKER'                 'INTEND'
    F_3_1     ForceCap_3_1  1
    F_3_1     ForceBal_1  1
    F_3_1     ForceBal_3  -1
    F_3_1     S2_F31lo  1
    F_3_1     S2_F31hi  1
    P_3_1     PCapLB_3_1  1
    P_3_1     PCapUB_3_1  1
    P_3_1     R23       1
    P_3_1     R24       1
    P_3_1     R25       1
    P_3_1     R26       1
    P_3_1     C2_a      -14
    P_3_1     C2_b      -1
    P_3_1     C2_c      -1
    P_3_1     C2_d      -14
    Torque_3_1  TCapLB_3_1  1
    Torque_3_1  TCapUB_3_1  1
    Torque_3_1  TorqueBal_1  1
    Torque_3_1  TorqueBal_3  -1
    Torque_3_1  Bilinear_3_1  1
    MARKER    'MARKER'                 'INTORG'
    T_3_2     DAGSupMin_3  1
    T_3_2     DAGSupMax_3  1
    T_3_2     ForceCap_3_2  -14
    T_3_2     PCapLB_3_2  16
    T_3_2     PCapUB_3_2  -16
    T_3_2     TCapLB_3_2  224
    T_3_2     TCapUB_3_2  -224
    T_3_2     R34       -33
    T_3_2     R35       33
    T_3_2     R36       -33
    T_3_2     R37       33
    T_3_2     LayerUB_3_2  2
    T_3_2     LayerLB_3_2  -2
    T_3_2     S2_T32    1
    MARKER    'MARKER'                 'INTEND'
    F_3_2     ForceCap_3_2  1
    F_3_2     ForceBal_2  1
    F_3_2     ForceBal_3  -1
    P_3_2     PCapLB_3_2  1
    P_3_2     PCapUB_3_2  1
    P_3_2     R34       1
    P_3_2     R35       1
    P_3_2     R36       1
    P_3_2     R37       1
    Torque_3_2  TCapLB_3_2  1
    Torque_3_2  TCapUB_3_2  1
    Torque_3_2  TorqueBal_2  1
    Torque_3_2  TorqueBal_3  -1
    Torque_3_2  Bilinear_3_2  1
    MARKER    'MARKER'                 'INTORG'
    T_4_1     DAGSupMin_4  1
    T_4_1     DAGSupMax_4  1
    T_4_1     ForceCap_4_1  -13
    T_4_1     PCapLB_4_1  16
    T_4_1     PCapUB_4_1  -16
    T_4_1     TCapLB_4_1  208
    T_4_1     TCapUB_4_1  -208
    T_4_1     R47       -33
    T_4_1     R48       33
    T_4_1     R49       -33
    T_4_1     R50       33
    T_4_1     LayerUB_4_1  3
    T_4_1     LayerLB_4_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_4_1     ForceCap_4_1  1
    F_4_1     ForceBal_1  1
    F_4_1     ForceBal_4  -1
    P_4_1     PCapLB_4_1  1
    P_4_1     PCapUB_4_1  1
    P_4_1     R47       1
    P_4_1     R48       1
    P_4_1     R49       1
    P_4_1     R50       1
    Torque_4_1  TCapLB_4_1  1
    Torque_4_1  TCapUB_4_1  1
    Torque_4_1  TorqueBal_1  1
    Torque_4_1  TorqueBal_4  -1
    Torque_4_1  Bilinear_4_1  1
    MARKER    'MARKER'                 'INTORG'
    T_4_2     DAGSupMin_4  1
    T_4_2     DAGSupMax_4  1
    T_4_2     ForceCap_4_2  -13
    T_4_2     PCapLB_4_2  16
    T_4_2     PCapUB_4_2  -16
    T_4_2     TCapLB_4_2  208
    T_4_2     TCapUB_4_2  -208
    T_4_2     R58       -33
    T_4_2     R59       33
    T_4_2     R60       -33
    T_4_2     R61       33
    T_4_2     LayerUB_4_2  3
    T_4_2     LayerLB_4_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_4_2     ForceCap_4_2  1
    F_4_2     ForceBal_2  1
    F_4_2     ForceBal_4  -1
    F_4_2     C2L_a_2   -1
    F_4_2     C2L_b_2   -2
    F_4_2     C2L_c_2   -1
    F_4_2     C2L_d_2   -2
    P_4_2     PCapLB_4_2  1
    P_4_2     PCapUB_4_2  1
    P_4_2     R58       1
    P_4_2     R59       1
    P_4_2     R60       1
    P_4_2     R61       1
    Torque_4_2  TCapLB_4_2  1
    Torque_4_2  TCapUB_4_2  1
    Torque_4_2  TorqueBal_2  1
    Torque_4_2  TorqueBal_4  -1
    Torque_4_2  Bilinear_4_2  1
    MARKER    'MARKER'                 'INTORG'
    T_4_3     DAGSupMin_4  1
    T_4_3     DAGSupMax_4  1
    T_4_3     ForceCap_4_3  -13
    T_4_3     PCapLB_4_3  16
    T_4_3     PCapUB_4_3  -16
    T_4_3     TCapLB_4_3  208
    T_4_3     TCapUB_4_3  -208
    T_4_3     R69       -33
    T_4_3     R70       33
    T_4_3     R71       -33
    T_4_3     R72       33
    T_4_3     LayerUB_4_3  3
    T_4_3     LayerLB_4_3  -3
    T_4_3     SP_3      -9.7317617238599374e-01
    T_4_3     SP_4      -1.8302215874504570e+00
    T_4_3     SP_5      -2.7742910535344629e+00
    T_4_3     SP_6      -3.7624072023695261e+00
    T_4_3     SP_7      -4.7732071613454137e+00
    T_4_3     SP_8      -5.7956453692796064e+00
    T_4_3     NonSpinal_t0  1
    MARKER    'MARKER'                 'INTEND'
    F_4_3     ForceCap_4_3  1
    F_4_3     ForceBal_3  1
    F_4_3     ForceBal_4  -1
    P_4_3     PCapLB_4_3  1
    P_4_3     PCapUB_4_3  1
    P_4_3     R69       1
    P_4_3     R70       1
    P_4_3     R71       1
    P_4_3     R72       1
    Torque_4_3  TCapLB_4_3  1
    Torque_4_3  TCapUB_4_3  1
    Torque_4_3  TorqueBal_3  1
    Torque_4_3  TorqueBal_4  -1
    Torque_4_3  Bilinear_4_3  1
    MARKER    'MARKER'                 'INTORG'
    T_5_1     DAGSupMin_5  1
    T_5_1     DAGSupMax_5  1
    T_5_1     ForceCap_5_1  -12
    T_5_1     PCapLB_5_1  16
    T_5_1     PCapUB_5_1  -16
    T_5_1     TCapLB_5_1  192
    T_5_1     TCapUB_5_1  -192
    T_5_1     R82       -33
    T_5_1     R83       33
    T_5_1     R84       -33
    T_5_1     R85       33
    T_5_1     LayerUB_5_1  4
    T_5_1     LayerLB_5_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_5_1     ForceCap_5_1  1
    F_5_1     ForceBal_1  1
    F_5_1     ForceBal_5  -1
    P_5_1     PCapLB_5_1  1
    P_5_1     PCapUB_5_1  1
    P_5_1     R82       1
    P_5_1     R83       1
    P_5_1     R84       1
    P_5_1     R85       1
    Torque_5_1  TCapLB_5_1  1
    Torque_5_1  TCapUB_5_1  1
    Torque_5_1  TorqueBal_1  1
    Torque_5_1  TorqueBal_5  -1
    Torque_5_1  Bilinear_5_1  1
    MARKER    'MARKER'                 'INTORG'
    T_5_2     DAGSupMin_5  1
    T_5_2     DAGSupMax_5  1
    T_5_2     ForceCap_5_2  -12
    T_5_2     PCapLB_5_2  16
    T_5_2     PCapUB_5_2  -16
    T_5_2     TCapLB_5_2  192
    T_5_2     TCapUB_5_2  -192
    T_5_2     R93       -33
    T_5_2     R94       33
    T_5_2     R95       -33
    T_5_2     R96       33
    T_5_2     LayerUB_5_2  4
    T_5_2     LayerLB_5_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_5_2     ForceCap_5_2  1
    F_5_2     ForceBal_2  1
    F_5_2     ForceBal_5  -1
    F_5_2     C2L_a_2   -1
    F_5_2     C2L_b_2   -2
    F_5_2     C2L_c_2   -1
    F_5_2     C2L_d_2   -2
    P_5_2     PCapLB_5_2  1
    P_5_2     PCapUB_5_2  1
    P_5_2     R93       1
    P_5_2     R94       1
    P_5_2     R95       1
    P_5_2     R96       1
    Torque_5_2  TCapLB_5_2  1
    Torque_5_2  TCapUB_5_2  1
    Torque_5_2  TorqueBal_2  1
    Torque_5_2  TorqueBal_5  -1
    Torque_5_2  Bilinear_5_2  1
    MARKER    'MARKER'                 'INTORG'
    T_5_3     DAGSupMin_5  1
    T_5_3     DAGSupMax_5  1
    T_5_3     ForceCap_5_3  -12
    T_5_3     PCapLB_5_3  16
    T_5_3     PCapUB_5_3  -16
    T_5_3     TCapLB_5_3  192
    T_5_3     TCapUB_5_3  -192
    T_5_3     R104      -33
    T_5_3     R105      33
    T_5_3     R106      -33
    T_5_3     R107      33
    T_5_3     LayerUB_5_3  4
    T_5_3     LayerLB_5_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_5_3     ForceCap_5_3  1
    F_5_3     ForceBal_3  1
    F_5_3     ForceBal_5  -1
    P_5_3     PCapLB_5_3  1
    P_5_3     PCapUB_5_3  1
    P_5_3     R104      1
    P_5_3     R105      1
    P_5_3     R106      1
    P_5_3     R107      1
    Torque_5_3  TCapLB_5_3  1
    Torque_5_3  TCapUB_5_3  1
    Torque_5_3  TorqueBal_3  1
    Torque_5_3  TorqueBal_5  -1
    Torque_5_3  Bilinear_5_3  1
    MARKER    'MARKER'                 'INTORG'
    T_5_4     DAGSupMin_5  1
    T_5_4     DAGSupMax_5  1
    T_5_4     ForceCap_5_4  -12
    T_5_4     PCapLB_5_4  16
    T_5_4     PCapUB_5_4  -16
    T_5_4     TCapLB_5_4  192
    T_5_4     TCapUB_5_4  -192
    T_5_4     R115      -33
    T_5_4     R116      33
    T_5_4     R117      -33
    T_5_4     R118      33
    T_5_4     LayerUB_5_4  4
    T_5_4     LayerLB_5_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_5_4     ForceCap_5_4  1
    F_5_4     ForceBal_4  1
    F_5_4     ForceBal_5  -1
    P_5_4     PCapLB_5_4  1
    P_5_4     PCapUB_5_4  1
    P_5_4     R115      1
    P_5_4     R116      1
    P_5_4     R117      1
    P_5_4     R118      1
    Torque_5_4  TCapLB_5_4  1
    Torque_5_4  TCapUB_5_4  1
    Torque_5_4  TorqueBal_4  1
    Torque_5_4  TorqueBal_5  -1
    Torque_5_4  Bilinear_5_4  1
    MARKER    'MARKER'                 'INTORG'
    T_6_1     DAGSupMin_6  1
    T_6_1     DAGSupMax_6  1
    T_6_1     ForceCap_6_1  -11
    T_6_1     PCapLB_6_1  16
    T_6_1     PCapUB_6_1  -16
    T_6_1     TCapLB_6_1  176
    T_6_1     TCapUB_6_1  -176
    T_6_1     R128      -33
    T_6_1     R129      33
    T_6_1     R130      -33
    T_6_1     R131      33
    T_6_1     LayerUB_6_1  5
    T_6_1     LayerLB_6_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_6_1     ForceCap_6_1  1
    F_6_1     ForceBal_1  1
    F_6_1     ForceBal_6  -1
    P_6_1     PCapLB_6_1  1
    P_6_1     PCapUB_6_1  1
    P_6_1     R128      1
    P_6_1     R129      1
    P_6_1     R130      1
    P_6_1     R131      1
    Torque_6_1  TCapLB_6_1  1
    Torque_6_1  TCapUB_6_1  1
    Torque_6_1  TorqueBal_1  1
    Torque_6_1  TorqueBal_6  -1
    Torque_6_1  Bilinear_6_1  1
    MARKER    'MARKER'                 'INTORG'
    T_6_2     DAGSupMin_6  1
    T_6_2     DAGSupMax_6  1
    T_6_2     ForceCap_6_2  -11
    T_6_2     PCapLB_6_2  16
    T_6_2     PCapUB_6_2  -16
    T_6_2     TCapLB_6_2  176
    T_6_2     TCapUB_6_2  -176
    T_6_2     R139      -33
    T_6_2     R140      33
    T_6_2     R141      -33
    T_6_2     R142      33
    T_6_2     LayerUB_6_2  5
    T_6_2     LayerLB_6_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_6_2     ForceCap_6_2  1
    F_6_2     ForceBal_2  1
    F_6_2     ForceBal_6  -1
    P_6_2     PCapLB_6_2  1
    P_6_2     PCapUB_6_2  1
    P_6_2     R139      1
    P_6_2     R140      1
    P_6_2     R141      1
    P_6_2     R142      1
    Torque_6_2  TCapLB_6_2  1
    Torque_6_2  TCapUB_6_2  1
    Torque_6_2  TorqueBal_2  1
    Torque_6_2  TorqueBal_6  -1
    Torque_6_2  Bilinear_6_2  1
    MARKER    'MARKER'                 'INTORG'
    T_6_3     DAGSupMin_6  1
    T_6_3     DAGSupMax_6  1
    T_6_3     ForceCap_6_3  -11
    T_6_3     PCapLB_6_3  16
    T_6_3     PCapUB_6_3  -16
    T_6_3     TCapLB_6_3  176
    T_6_3     TCapUB_6_3  -176
    T_6_3     R150      -33
    T_6_3     R151      33
    T_6_3     R152      -33
    T_6_3     R153      33
    T_6_3     LayerUB_6_3  5
    T_6_3     LayerLB_6_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_6_3     ForceCap_6_3  1
    F_6_3     ForceBal_3  1
    F_6_3     ForceBal_6  -1
    P_6_3     PCapLB_6_3  1
    P_6_3     PCapUB_6_3  1
    P_6_3     R150      1
    P_6_3     R151      1
    P_6_3     R152      1
    P_6_3     R153      1
    Torque_6_3  TCapLB_6_3  1
    Torque_6_3  TCapUB_6_3  1
    Torque_6_3  TorqueBal_3  1
    Torque_6_3  TorqueBal_6  -1
    Torque_6_3  Bilinear_6_3  1
    MARKER    'MARKER'                 'INTORG'
    T_6_4     DAGSupMin_6  1
    T_6_4     DAGSupMax_6  1
    T_6_4     ForceCap_6_4  -11
    T_6_4     PCapLB_6_4  16
    T_6_4     PCapUB_6_4  -16
    T_6_4     TCapLB_6_4  176
    T_6_4     TCapUB_6_4  -176
    T_6_4     R161      -33
    T_6_4     R162      33
    T_6_4     R163      -33
    T_6_4     R164      33
    T_6_4     LayerUB_6_4  5
    T_6_4     LayerLB_6_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_6_4     ForceCap_6_4  1
    F_6_4     ForceBal_4  1
    F_6_4     ForceBal_6  -1
    F_6_4     C2L_a_3   -1
    F_6_4     C2L_b_3   -4
    F_6_4     C2L_c_3   -1
    F_6_4     C2L_d_3   -4
    P_6_4     PCapLB_6_4  1
    P_6_4     PCapUB_6_4  1
    P_6_4     R161      1
    P_6_4     R162      1
    P_6_4     R163      1
    P_6_4     R164      1
    Torque_6_4  TCapLB_6_4  1
    Torque_6_4  TCapUB_6_4  1
    Torque_6_4  TorqueBal_4  1
    Torque_6_4  TorqueBal_6  -1
    Torque_6_4  Bilinear_6_4  1
    MARKER    'MARKER'                 'INTORG'
    T_6_5     DAGSupMin_6  1
    T_6_5     DAGSupMax_6  1
    T_6_5     ForceCap_6_5  -11
    T_6_5     PCapLB_6_5  16
    T_6_5     PCapUB_6_5  -16
    T_6_5     TCapLB_6_5  176
    T_6_5     TCapUB_6_5  -176
    T_6_5     R172      -33
    T_6_5     R173      33
    T_6_5     R174      -33
    T_6_5     R175      33
    T_6_5     LayerUB_6_5  5
    T_6_5     LayerLB_6_5  -5
    T_6_5     SP_4      -1.8302215874504570e+00
    T_6_5     SP_5      -2.7742910535344629e+00
    T_6_5     SP_6      -3.7624072023695261e+00
    T_6_5     SP_7      -4.7732071613454137e+00
    T_6_5     SP_8      -5.7956453692796064e+00
    MARKER    'MARKER'                 'INTEND'
    F_6_5     ForceCap_6_5  1
    F_6_5     ForceBal_5  1
    F_6_5     ForceBal_6  -1
    P_6_5     PCapLB_6_5  1
    P_6_5     PCapUB_6_5  1
    P_6_5     R172      1
    P_6_5     R173      1
    P_6_5     R174      1
    P_6_5     R175      1
    Torque_6_5  TCapLB_6_5  1
    Torque_6_5  TCapUB_6_5  1
    Torque_6_5  TorqueBal_5  1
    Torque_6_5  TorqueBal_6  -1
    Torque_6_5  Bilinear_6_5  1
    MARKER    'MARKER'                 'INTORG'
    T_7_1     DAGSupMin_7  1
    T_7_1     DAGSupMax_7  1
    T_7_1     ForceCap_7_1  -10
    T_7_1     PCapLB_7_1  16
    T_7_1     PCapUB_7_1  -16
    T_7_1     TCapLB_7_1  160
    T_7_1     TCapUB_7_1  -160
    T_7_1     R185      -33
    T_7_1     R186      33
    T_7_1     R187      -33
    T_7_1     R188      33
    T_7_1     LayerUB_7_1  6
    T_7_1     LayerLB_7_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_7_1     ForceCap_7_1  1
    F_7_1     ForceBal_1  1
    F_7_1     ForceBal_7  -1
    P_7_1     PCapLB_7_1  1
    P_7_1     PCapUB_7_1  1
    P_7_1     R185      1
    P_7_1     R186      1
    P_7_1     R187      1
    P_7_1     R188      1
    Torque_7_1  TCapLB_7_1  1
    Torque_7_1  TCapUB_7_1  1
    Torque_7_1  TorqueBal_1  1
    Torque_7_1  TorqueBal_7  -1
    Torque_7_1  Bilinear_7_1  1
    MARKER    'MARKER'                 'INTORG'
    T_7_2     DAGSupMin_7  1
    T_7_2     DAGSupMax_7  1
    T_7_2     ForceCap_7_2  -10
    T_7_2     PCapLB_7_2  16
    T_7_2     PCapUB_7_2  -16
    T_7_2     TCapLB_7_2  160
    T_7_2     TCapUB_7_2  -160
    T_7_2     R196      -33
    T_7_2     R197      33
    T_7_2     R198      -33
    T_7_2     R199      33
    T_7_2     LayerUB_7_2  6
    T_7_2     LayerLB_7_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_7_2     ForceCap_7_2  1
    F_7_2     ForceBal_2  1
    F_7_2     ForceBal_7  -1
    P_7_2     PCapLB_7_2  1
    P_7_2     PCapUB_7_2  1
    P_7_2     R196      1
    P_7_2     R197      1
    P_7_2     R198      1
    P_7_2     R199      1
    Torque_7_2  TCapLB_7_2  1
    Torque_7_2  TCapUB_7_2  1
    Torque_7_2  TorqueBal_2  1
    Torque_7_2  TorqueBal_7  -1
    Torque_7_2  Bilinear_7_2  1
    MARKER    'MARKER'                 'INTORG'
    T_7_3     DAGSupMin_7  1
    T_7_3     DAGSupMax_7  1
    T_7_3     ForceCap_7_3  -10
    T_7_3     PCapLB_7_3  16
    T_7_3     PCapUB_7_3  -16
    T_7_3     TCapLB_7_3  160
    T_7_3     TCapUB_7_3  -160
    T_7_3     R207      -33
    T_7_3     R208      33
    T_7_3     R209      -33
    T_7_3     R210      33
    T_7_3     LayerUB_7_3  6
    T_7_3     LayerLB_7_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_7_3     ForceCap_7_3  1
    F_7_3     ForceBal_3  1
    F_7_3     ForceBal_7  -1
    P_7_3     PCapLB_7_3  1
    P_7_3     PCapUB_7_3  1
    P_7_3     R207      1
    P_7_3     R208      1
    P_7_3     R209      1
    P_7_3     R210      1
    Torque_7_3  TCapLB_7_3  1
    Torque_7_3  TCapUB_7_3  1
    Torque_7_3  TorqueBal_3  1
    Torque_7_3  TorqueBal_7  -1
    Torque_7_3  Bilinear_7_3  1
    MARKER    'MARKER'                 'INTORG'
    T_7_4     DAGSupMin_7  1
    T_7_4     DAGSupMax_7  1
    T_7_4     ForceCap_7_4  -10
    T_7_4     PCapLB_7_4  16
    T_7_4     PCapUB_7_4  -16
    T_7_4     TCapLB_7_4  160
    T_7_4     TCapUB_7_4  -160
    T_7_4     R218      -33
    T_7_4     R219      33
    T_7_4     R220      -33
    T_7_4     R221      33
    T_7_4     LayerUB_7_4  6
    T_7_4     LayerLB_7_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_7_4     ForceCap_7_4  1
    F_7_4     ForceBal_4  1
    F_7_4     ForceBal_7  -1
    F_7_4     C2L_a_3   -1
    F_7_4     C2L_b_3   -4
    F_7_4     C2L_c_3   -1
    F_7_4     C2L_d_3   -4
    P_7_4     PCapLB_7_4  1
    P_7_4     PCapUB_7_4  1
    P_7_4     R218      1
    P_7_4     R219      1
    P_7_4     R220      1
    P_7_4     R221      1
    Torque_7_4  TCapLB_7_4  1
    Torque_7_4  TCapUB_7_4  1
    Torque_7_4  TorqueBal_4  1
    Torque_7_4  TorqueBal_7  -1
    Torque_7_4  Bilinear_7_4  1
    MARKER    'MARKER'                 'INTORG'
    T_7_5     DAGSupMin_7  1
    T_7_5     DAGSupMax_7  1
    T_7_5     ForceCap_7_5  -10
    T_7_5     PCapLB_7_5  16
    T_7_5     PCapUB_7_5  -16
    T_7_5     TCapLB_7_5  160
    T_7_5     TCapUB_7_5  -160
    T_7_5     R229      -33
    T_7_5     R230      33
    T_7_5     R231      -33
    T_7_5     R232      33
    T_7_5     LayerUB_7_5  6
    T_7_5     LayerLB_7_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_7_5     ForceCap_7_5  1
    F_7_5     ForceBal_5  1
    F_7_5     ForceBal_7  -1
    P_7_5     PCapLB_7_5  1
    P_7_5     PCapUB_7_5  1
    P_7_5     R229      1
    P_7_5     R230      1
    P_7_5     R231      1
    P_7_5     R232      1
    Torque_7_5  TCapLB_7_5  1
    Torque_7_5  TCapUB_7_5  1
    Torque_7_5  TorqueBal_5  1
    Torque_7_5  TorqueBal_7  -1
    Torque_7_5  Bilinear_7_5  1
    MARKER    'MARKER'                 'INTORG'
    T_7_6     DAGSupMin_7  1
    T_7_6     DAGSupMax_7  1
    T_7_6     ForceCap_7_6  -10
    T_7_6     PCapLB_7_6  16
    T_7_6     PCapUB_7_6  -16
    T_7_6     TCapLB_7_6  160
    T_7_6     TCapUB_7_6  -160
    T_7_6     R240      -33
    T_7_6     R241      33
    T_7_6     R242      -33
    T_7_6     R243      33
    T_7_6     LayerUB_7_6  6
    T_7_6     LayerLB_7_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_7_6     ForceCap_7_6  1
    F_7_6     ForceBal_6  1
    F_7_6     ForceBal_7  -1
    P_7_6     PCapLB_7_6  1
    P_7_6     PCapUB_7_6  1
    P_7_6     R240      1
    P_7_6     R241      1
    P_7_6     R242      1
    P_7_6     R243      1
    Torque_7_6  TCapLB_7_6  1
    Torque_7_6  TCapUB_7_6  1
    Torque_7_6  TorqueBal_6  1
    Torque_7_6  TorqueBal_7  -1
    Torque_7_6  Bilinear_7_6  1
    MARKER    'MARKER'                 'INTORG'
    T_8_1     DAGSupMin_8  1
    T_8_1     DAGSupMax_8  1
    T_8_1     ForceCap_8_1  -9
    T_8_1     PCapLB_8_1  16
    T_8_1     PCapUB_8_1  -16
    T_8_1     TCapLB_8_1  144
    T_8_1     TCapUB_8_1  -144
    T_8_1     R253      -33
    T_8_1     R254      33
    T_8_1     R255      -33
    T_8_1     R256      33
    T_8_1     LayerUB_8_1  7
    T_8_1     LayerLB_8_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_8_1     ForceCap_8_1  1
    F_8_1     ForceBal_1  1
    F_8_1     ForceBal_8  -1
    P_8_1     PCapLB_8_1  1
    P_8_1     PCapUB_8_1  1
    P_8_1     R253      1
    P_8_1     R254      1
    P_8_1     R255      1
    P_8_1     R256      1
    Torque_8_1  TCapLB_8_1  1
    Torque_8_1  TCapUB_8_1  1
    Torque_8_1  TorqueBal_1  1
    Torque_8_1  TorqueBal_8  -1
    Torque_8_1  Bilinear_8_1  1
    MARKER    'MARKER'                 'INTORG'
    T_8_2     DAGSupMin_8  1
    T_8_2     DAGSupMax_8  1
    T_8_2     ForceCap_8_2  -9
    T_8_2     PCapLB_8_2  16
    T_8_2     PCapUB_8_2  -16
    T_8_2     TCapLB_8_2  144
    T_8_2     TCapUB_8_2  -144
    T_8_2     R264      -33
    T_8_2     R265      33
    T_8_2     R266      -33
    T_8_2     R267      33
    T_8_2     LayerUB_8_2  7
    T_8_2     LayerLB_8_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_8_2     ForceCap_8_2  1
    F_8_2     ForceBal_2  1
    F_8_2     ForceBal_8  -1
    P_8_2     PCapLB_8_2  1
    P_8_2     PCapUB_8_2  1
    P_8_2     R264      1
    P_8_2     R265      1
    P_8_2     R266      1
    P_8_2     R267      1
    Torque_8_2  TCapLB_8_2  1
    Torque_8_2  TCapUB_8_2  1
    Torque_8_2  TorqueBal_2  1
    Torque_8_2  TorqueBal_8  -1
    Torque_8_2  Bilinear_8_2  1
    MARKER    'MARKER'                 'INTORG'
    T_8_3     DAGSupMin_8  1
    T_8_3     DAGSupMax_8  1
    T_8_3     ForceCap_8_3  -9
    T_8_3     PCapLB_8_3  16
    T_8_3     PCapUB_8_3  -16
    T_8_3     TCapLB_8_3  144
    T_8_3     TCapUB_8_3  -144
    T_8_3     R275      -33
    T_8_3     R276      33
    T_8_3     R277      -33
    T_8_3     R278      33
    T_8_3     LayerUB_8_3  7
    T_8_3     LayerLB_8_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_8_3     ForceCap_8_3  1
    F_8_3     ForceBal_3  1
    F_8_3     ForceBal_8  -1
    P_8_3     PCapLB_8_3  1
    P_8_3     PCapUB_8_3  1
    P_8_3     R275      1
    P_8_3     R276      1
    P_8_3     R277      1
    P_8_3     R278      1
    Torque_8_3  TCapLB_8_3  1
    Torque_8_3  TCapUB_8_3  1
    Torque_8_3  TorqueBal_3  1
    Torque_8_3  TorqueBal_8  -1
    Torque_8_3  Bilinear_8_3  1
    MARKER    'MARKER'                 'INTORG'
    T_8_4     DAGSupMin_8  1
    T_8_4     DAGSupMax_8  1
    T_8_4     ForceCap_8_4  -9
    T_8_4     PCapLB_8_4  16
    T_8_4     PCapUB_8_4  -16
    T_8_4     TCapLB_8_4  144
    T_8_4     TCapUB_8_4  -144
    T_8_4     R286      -33
    T_8_4     R287      33
    T_8_4     R288      -33
    T_8_4     R289      33
    T_8_4     LayerUB_8_4  7
    T_8_4     LayerLB_8_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_8_4     ForceCap_8_4  1
    F_8_4     ForceBal_4  1
    F_8_4     ForceBal_8  -1
    P_8_4     PCapLB_8_4  1
    P_8_4     PCapUB_8_4  1
    P_8_4     R286      1
    P_8_4     R287      1
    P_8_4     R288      1
    P_8_4     R289      1
    Torque_8_4  TCapLB_8_4  1
    Torque_8_4  TCapUB_8_4  1
    Torque_8_4  TorqueBal_4  1
    Torque_8_4  TorqueBal_8  -1
    Torque_8_4  Bilinear_8_4  1
    MARKER    'MARKER'                 'INTORG'
    T_8_5     DAGSupMin_8  1
    T_8_5     DAGSupMax_8  1
    T_8_5     ForceCap_8_5  -9
    T_8_5     PCapLB_8_5  16
    T_8_5     PCapUB_8_5  -16
    T_8_5     TCapLB_8_5  144
    T_8_5     TCapUB_8_5  -144
    T_8_5     R297      -33
    T_8_5     R298      33
    T_8_5     R299      -33
    T_8_5     R300      33
    T_8_5     LayerUB_8_5  7
    T_8_5     LayerLB_8_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_8_5     ForceCap_8_5  1
    F_8_5     ForceBal_5  1
    F_8_5     ForceBal_8  -1
    P_8_5     PCapLB_8_5  1
    P_8_5     PCapUB_8_5  1
    P_8_5     R297      1
    P_8_5     R298      1
    P_8_5     R299      1
    P_8_5     R300      1
    Torque_8_5  TCapLB_8_5  1
    Torque_8_5  TCapUB_8_5  1
    Torque_8_5  TorqueBal_5  1
    Torque_8_5  TorqueBal_8  -1
    Torque_8_5  Bilinear_8_5  1
    MARKER    'MARKER'                 'INTORG'
    T_8_6     DAGSupMin_8  1
    T_8_6     DAGSupMax_8  1
    T_8_6     ForceCap_8_6  -9
    T_8_6     PCapLB_8_6  16
    T_8_6     PCapUB_8_6  -16
    T_8_6     TCapLB_8_6  144
    T_8_6     TCapUB_8_6  -144
    T_8_6     R308      -33
    T_8_6     R309      33
    T_8_6     R310      -33
    T_8_6     R311      33
    T_8_6     LayerUB_8_6  7
    T_8_6     LayerLB_8_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_8_6     ForceCap_8_6  1
    F_8_6     ForceBal_6  1
    F_8_6     ForceBal_8  -1
    F_8_6     C2L_a_4   -1
    F_8_6     C2L_b_4   -6
    F_8_6     C2L_c_4   -1
    F_8_6     C2L_d_4   -6
    P_8_6     PCapLB_8_6  1
    P_8_6     PCapUB_8_6  1
    P_8_6     R308      1
    P_8_6     R309      1
    P_8_6     R310      1
    P_8_6     R311      1
    Torque_8_6  TCapLB_8_6  1
    Torque_8_6  TCapUB_8_6  1
    Torque_8_6  TorqueBal_6  1
    Torque_8_6  TorqueBal_8  -1
    Torque_8_6  Bilinear_8_6  1
    MARKER    'MARKER'                 'INTORG'
    T_8_7     DAGSupMin_8  1
    T_8_7     DAGSupMax_8  1
    T_8_7     ForceCap_8_7  -9
    T_8_7     PCapLB_8_7  16
    T_8_7     PCapUB_8_7  -16
    T_8_7     TCapLB_8_7  144
    T_8_7     TCapUB_8_7  -144
    T_8_7     R319      -33
    T_8_7     R320      33
    T_8_7     R321      -33
    T_8_7     R322      33
    T_8_7     LayerUB_8_7  7
    T_8_7     LayerLB_8_7  -7
    T_8_7     SP_5      -2.7742910535344629e+00
    T_8_7     SP_6      -3.7624072023695261e+00
    T_8_7     SP_7      -4.7732071613454137e+00
    T_8_7     SP_8      -5.7956453692796064e+00
    MARKER    'MARKER'                 'INTEND'
    F_8_7     ForceCap_8_7  1
    F_8_7     ForceBal_7  1
    F_8_7     ForceBal_8  -1
    P_8_7     PCapLB_8_7  1
    P_8_7     PCapUB_8_7  1
    P_8_7     R319      1
    P_8_7     R320      1
    P_8_7     R321      1
    P_8_7     R322      1
    Torque_8_7  TCapLB_8_7  1
    Torque_8_7  TCapUB_8_7  1
    Torque_8_7  TorqueBal_7  1
    Torque_8_7  TorqueBal_8  -1
    Torque_8_7  Bilinear_8_7  1
    MARKER    'MARKER'                 'INTORG'
    T_9_1     DAGSupMin_9  1
    T_9_1     DAGSupMax_9  1
    T_9_1     ForceCap_9_1  -8
    T_9_1     PCapLB_9_1  16
    T_9_1     PCapUB_9_1  -16
    T_9_1     TCapLB_9_1  128
    T_9_1     TCapUB_9_1  -128
    T_9_1     R332      -33
    T_9_1     R333      33
    T_9_1     R334      -33
    T_9_1     R335      33
    T_9_1     LayerUB_9_1  8
    T_9_1     LayerLB_9_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_9_1     ForceCap_9_1  1
    F_9_1     ForceBal_1  1
    F_9_1     ForceBal_9  -1
    P_9_1     PCapLB_9_1  1
    P_9_1     PCapUB_9_1  1
    P_9_1     R332      1
    P_9_1     R333      1
    P_9_1     R334      1
    P_9_1     R335      1
    Torque_9_1  TCapLB_9_1  1
    Torque_9_1  TCapUB_9_1  1
    Torque_9_1  TorqueBal_1  1
    Torque_9_1  TorqueBal_9  -1
    Torque_9_1  Bilinear_9_1  1
    MARKER    'MARKER'                 'INTORG'
    T_9_2     DAGSupMin_9  1
    T_9_2     DAGSupMax_9  1
    T_9_2     ForceCap_9_2  -8
    T_9_2     PCapLB_9_2  16
    T_9_2     PCapUB_9_2  -16
    T_9_2     TCapLB_9_2  128
    T_9_2     TCapUB_9_2  -128
    T_9_2     R343      -33
    T_9_2     R344      33
    T_9_2     R345      -33
    T_9_2     R346      33
    T_9_2     LayerUB_9_2  8
    T_9_2     LayerLB_9_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_9_2     ForceCap_9_2  1
    F_9_2     ForceBal_2  1
    F_9_2     ForceBal_9  -1
    P_9_2     PCapLB_9_2  1
    P_9_2     PCapUB_9_2  1
    P_9_2     R343      1
    P_9_2     R344      1
    P_9_2     R345      1
    P_9_2     R346      1
    Torque_9_2  TCapLB_9_2  1
    Torque_9_2  TCapUB_9_2  1
    Torque_9_2  TorqueBal_2  1
    Torque_9_2  TorqueBal_9  -1
    Torque_9_2  Bilinear_9_2  1
    MARKER    'MARKER'                 'INTORG'
    T_9_3     DAGSupMin_9  1
    T_9_3     DAGSupMax_9  1
    T_9_3     ForceCap_9_3  -8
    T_9_3     PCapLB_9_3  16
    T_9_3     PCapUB_9_3  -16
    T_9_3     TCapLB_9_3  128
    T_9_3     TCapUB_9_3  -128
    T_9_3     R354      -33
    T_9_3     R355      33
    T_9_3     R356      -33
    T_9_3     R357      33
    T_9_3     LayerUB_9_3  8
    T_9_3     LayerLB_9_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_9_3     ForceCap_9_3  1
    F_9_3     ForceBal_3  1
    F_9_3     ForceBal_9  -1
    P_9_3     PCapLB_9_3  1
    P_9_3     PCapUB_9_3  1
    P_9_3     R354      1
    P_9_3     R355      1
    P_9_3     R356      1
    P_9_3     R357      1
    Torque_9_3  TCapLB_9_3  1
    Torque_9_3  TCapUB_9_3  1
    Torque_9_3  TorqueBal_3  1
    Torque_9_3  TorqueBal_9  -1
    Torque_9_3  Bilinear_9_3  1
    MARKER    'MARKER'                 'INTORG'
    T_9_4     DAGSupMin_9  1
    T_9_4     DAGSupMax_9  1
    T_9_4     ForceCap_9_4  -8
    T_9_4     PCapLB_9_4  16
    T_9_4     PCapUB_9_4  -16
    T_9_4     TCapLB_9_4  128
    T_9_4     TCapUB_9_4  -128
    T_9_4     R365      -33
    T_9_4     R366      33
    T_9_4     R367      -33
    T_9_4     R368      33
    T_9_4     LayerUB_9_4  8
    T_9_4     LayerLB_9_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_9_4     ForceCap_9_4  1
    F_9_4     ForceBal_4  1
    F_9_4     ForceBal_9  -1
    P_9_4     PCapLB_9_4  1
    P_9_4     PCapUB_9_4  1
    P_9_4     R365      1
    P_9_4     R366      1
    P_9_4     R367      1
    P_9_4     R368      1
    Torque_9_4  TCapLB_9_4  1
    Torque_9_4  TCapUB_9_4  1
    Torque_9_4  TorqueBal_4  1
    Torque_9_4  TorqueBal_9  -1
    Torque_9_4  Bilinear_9_4  1
    MARKER    'MARKER'                 'INTORG'
    T_9_5     DAGSupMin_9  1
    T_9_5     DAGSupMax_9  1
    T_9_5     ForceCap_9_5  -8
    T_9_5     PCapLB_9_5  16
    T_9_5     PCapUB_9_5  -16
    T_9_5     TCapLB_9_5  128
    T_9_5     TCapUB_9_5  -128
    T_9_5     R376      -33
    T_9_5     R377      33
    T_9_5     R378      -33
    T_9_5     R379      33
    T_9_5     LayerUB_9_5  8
    T_9_5     LayerLB_9_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_9_5     ForceCap_9_5  1
    F_9_5     ForceBal_5  1
    F_9_5     ForceBal_9  -1
    P_9_5     PCapLB_9_5  1
    P_9_5     PCapUB_9_5  1
    P_9_5     R376      1
    P_9_5     R377      1
    P_9_5     R378      1
    P_9_5     R379      1
    Torque_9_5  TCapLB_9_5  1
    Torque_9_5  TCapUB_9_5  1
    Torque_9_5  TorqueBal_5  1
    Torque_9_5  TorqueBal_9  -1
    Torque_9_5  Bilinear_9_5  1
    MARKER    'MARKER'                 'INTORG'
    T_9_6     DAGSupMin_9  1
    T_9_6     DAGSupMax_9  1
    T_9_6     ForceCap_9_6  -8
    T_9_6     PCapLB_9_6  16
    T_9_6     PCapUB_9_6  -16
    T_9_6     TCapLB_9_6  128
    T_9_6     TCapUB_9_6  -128
    T_9_6     R387      -33
    T_9_6     R388      33
    T_9_6     R389      -33
    T_9_6     R390      33
    T_9_6     LayerUB_9_6  8
    T_9_6     LayerLB_9_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_9_6     ForceCap_9_6  1
    F_9_6     ForceBal_6  1
    F_9_6     ForceBal_9  -1
    F_9_6     C2L_a_4   -1
    F_9_6     C2L_b_4   -6
    F_9_6     C2L_c_4   -1
    F_9_6     C2L_d_4   -6
    P_9_6     PCapLB_9_6  1
    P_9_6     PCapUB_9_6  1
    P_9_6     R387      1
    P_9_6     R388      1
    P_9_6     R389      1
    P_9_6     R390      1
    Torque_9_6  TCapLB_9_6  1
    Torque_9_6  TCapUB_9_6  1
    Torque_9_6  TorqueBal_6  1
    Torque_9_6  TorqueBal_9  -1
    Torque_9_6  Bilinear_9_6  1
    MARKER    'MARKER'                 'INTORG'
    T_9_7     DAGSupMin_9  1
    T_9_7     DAGSupMax_9  1
    T_9_7     ForceCap_9_7  -8
    T_9_7     PCapLB_9_7  16
    T_9_7     PCapUB_9_7  -16
    T_9_7     TCapLB_9_7  128
    T_9_7     TCapUB_9_7  -128
    T_9_7     R398      -33
    T_9_7     R399      33
    T_9_7     R400      -33
    T_9_7     R401      33
    T_9_7     LayerUB_9_7  8
    T_9_7     LayerLB_9_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_9_7     ForceCap_9_7  1
    F_9_7     ForceBal_7  1
    F_9_7     ForceBal_9  -1
    P_9_7     PCapLB_9_7  1
    P_9_7     PCapUB_9_7  1
    P_9_7     R398      1
    P_9_7     R399      1
    P_9_7     R400      1
    P_9_7     R401      1
    Torque_9_7  TCapLB_9_7  1
    Torque_9_7  TCapUB_9_7  1
    Torque_9_7  TorqueBal_7  1
    Torque_9_7  TorqueBal_9  -1
    Torque_9_7  Bilinear_9_7  1
    MARKER    'MARKER'                 'INTORG'
    T_9_8     DAGSupMin_9  1
    T_9_8     DAGSupMax_9  1
    T_9_8     ForceCap_9_8  -8
    T_9_8     PCapLB_9_8  16
    T_9_8     PCapUB_9_8  -16
    T_9_8     TCapLB_9_8  128
    T_9_8     TCapUB_9_8  -128
    T_9_8     R409      -33
    T_9_8     R410      33
    T_9_8     R411      -33
    T_9_8     R412      33
    T_9_8     LayerUB_9_8  8
    T_9_8     LayerLB_9_8  -8
    MARKER    'MARKER'                 'INTEND'
    F_9_8     ForceCap_9_8  1
    F_9_8     ForceBal_8  1
    F_9_8     ForceBal_9  -1
    P_9_8     PCapLB_9_8  1
    P_9_8     PCapUB_9_8  1
    P_9_8     R409      1
    P_9_8     R410      1
    P_9_8     R411      1
    P_9_8     R412      1
    Torque_9_8  TCapLB_9_8  1
    Torque_9_8  TCapUB_9_8  1
    Torque_9_8  TorqueBal_8  1
    Torque_9_8  TorqueBal_9  -1
    Torque_9_8  Bilinear_9_8  1
    MARKER    'MARKER'                 'INTORG'
    T_10_1    DAGSupMin_10  1
    T_10_1    DAGSupMax_10  1
    T_10_1    ForceCap_10_1  -7
    T_10_1    PCapLB_10_1  16
    T_10_1    PCapUB_10_1  -16
    T_10_1    TCapLB_10_1  112
    T_10_1    TCapUB_10_1  -112
    T_10_1    R422      -33
    T_10_1    R423      33
    T_10_1    R424      -33
    T_10_1    R425      33
    T_10_1    LayerUB_10_1  9
    T_10_1    LayerLB_10_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_10_1    ForceCap_10_1  1
    F_10_1    ForceBal_1  1
    F_10_1    ForceBal_10  -1
    P_10_1    PCapLB_10_1  1
    P_10_1    PCapUB_10_1  1
    P_10_1    R422      1
    P_10_1    R423      1
    P_10_1    R424      1
    P_10_1    R425      1
    Torque_10_1  TCapLB_10_1  1
    Torque_10_1  TCapUB_10_1  1
    Torque_10_1  TorqueBal_1  1
    Torque_10_1  TorqueBal_10  -1
    Torque_10_1  Bilinear_10_1  1
    MARKER    'MARKER'                 'INTORG'
    T_10_2    DAGSupMin_10  1
    T_10_2    DAGSupMax_10  1
    T_10_2    ForceCap_10_2  -7
    T_10_2    PCapLB_10_2  16
    T_10_2    PCapUB_10_2  -16
    T_10_2    TCapLB_10_2  112
    T_10_2    TCapUB_10_2  -112
    T_10_2    R433      -33
    T_10_2    R434      33
    T_10_2    R435      -33
    T_10_2    R436      33
    T_10_2    LayerUB_10_2  9
    T_10_2    LayerLB_10_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_10_2    ForceCap_10_2  1
    F_10_2    ForceBal_2  1
    F_10_2    ForceBal_10  -1
    P_10_2    PCapLB_10_2  1
    P_10_2    PCapUB_10_2  1
    P_10_2    R433      1
    P_10_2    R434      1
    P_10_2    R435      1
    P_10_2    R436      1
    Torque_10_2  TCapLB_10_2  1
    Torque_10_2  TCapUB_10_2  1
    Torque_10_2  TorqueBal_2  1
    Torque_10_2  TorqueBal_10  -1
    Torque_10_2  Bilinear_10_2  1
    MARKER    'MARKER'                 'INTORG'
    T_10_3    DAGSupMin_10  1
    T_10_3    DAGSupMax_10  1
    T_10_3    ForceCap_10_3  -7
    T_10_3    PCapLB_10_3  16
    T_10_3    PCapUB_10_3  -16
    T_10_3    TCapLB_10_3  112
    T_10_3    TCapUB_10_3  -112
    T_10_3    R444      -33
    T_10_3    R445      33
    T_10_3    R446      -33
    T_10_3    R447      33
    T_10_3    LayerUB_10_3  9
    T_10_3    LayerLB_10_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_10_3    ForceCap_10_3  1
    F_10_3    ForceBal_3  1
    F_10_3    ForceBal_10  -1
    P_10_3    PCapLB_10_3  1
    P_10_3    PCapUB_10_3  1
    P_10_3    R444      1
    P_10_3    R445      1
    P_10_3    R446      1
    P_10_3    R447      1
    Torque_10_3  TCapLB_10_3  1
    Torque_10_3  TCapUB_10_3  1
    Torque_10_3  TorqueBal_3  1
    Torque_10_3  TorqueBal_10  -1
    Torque_10_3  Bilinear_10_3  1
    MARKER    'MARKER'                 'INTORG'
    T_10_4    DAGSupMin_10  1
    T_10_4    DAGSupMax_10  1
    T_10_4    ForceCap_10_4  -7
    T_10_4    PCapLB_10_4  16
    T_10_4    PCapUB_10_4  -16
    T_10_4    TCapLB_10_4  112
    T_10_4    TCapUB_10_4  -112
    T_10_4    R455      -33
    T_10_4    R456      33
    T_10_4    R457      -33
    T_10_4    R458      33
    T_10_4    LayerUB_10_4  9
    T_10_4    LayerLB_10_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_10_4    ForceCap_10_4  1
    F_10_4    ForceBal_4  1
    F_10_4    ForceBal_10  -1
    P_10_4    PCapLB_10_4  1
    P_10_4    PCapUB_10_4  1
    P_10_4    R455      1
    P_10_4    R456      1
    P_10_4    R457      1
    P_10_4    R458      1
    Torque_10_4  TCapLB_10_4  1
    Torque_10_4  TCapUB_10_4  1
    Torque_10_4  TorqueBal_4  1
    Torque_10_4  TorqueBal_10  -1
    Torque_10_4  Bilinear_10_4  1
    MARKER    'MARKER'                 'INTORG'
    T_10_5    DAGSupMin_10  1
    T_10_5    DAGSupMax_10  1
    T_10_5    ForceCap_10_5  -7
    T_10_5    PCapLB_10_5  16
    T_10_5    PCapUB_10_5  -16
    T_10_5    TCapLB_10_5  112
    T_10_5    TCapUB_10_5  -112
    T_10_5    R466      -33
    T_10_5    R467      33
    T_10_5    R468      -33
    T_10_5    R469      33
    T_10_5    LayerUB_10_5  9
    T_10_5    LayerLB_10_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_10_5    ForceCap_10_5  1
    F_10_5    ForceBal_5  1
    F_10_5    ForceBal_10  -1
    P_10_5    PCapLB_10_5  1
    P_10_5    PCapUB_10_5  1
    P_10_5    R466      1
    P_10_5    R467      1
    P_10_5    R468      1
    P_10_5    R469      1
    Torque_10_5  TCapLB_10_5  1
    Torque_10_5  TCapUB_10_5  1
    Torque_10_5  TorqueBal_5  1
    Torque_10_5  TorqueBal_10  -1
    Torque_10_5  Bilinear_10_5  1
    MARKER    'MARKER'                 'INTORG'
    T_10_6    DAGSupMin_10  1
    T_10_6    DAGSupMax_10  1
    T_10_6    ForceCap_10_6  -7
    T_10_6    PCapLB_10_6  16
    T_10_6    PCapUB_10_6  -16
    T_10_6    TCapLB_10_6  112
    T_10_6    TCapUB_10_6  -112
    T_10_6    R477      -33
    T_10_6    R478      33
    T_10_6    R479      -33
    T_10_6    R480      33
    T_10_6    LayerUB_10_6  9
    T_10_6    LayerLB_10_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_10_6    ForceCap_10_6  1
    F_10_6    ForceBal_6  1
    F_10_6    ForceBal_10  -1
    P_10_6    PCapLB_10_6  1
    P_10_6    PCapUB_10_6  1
    P_10_6    R477      1
    P_10_6    R478      1
    P_10_6    R479      1
    P_10_6    R480      1
    Torque_10_6  TCapLB_10_6  1
    Torque_10_6  TCapUB_10_6  1
    Torque_10_6  TorqueBal_6  1
    Torque_10_6  TorqueBal_10  -1
    Torque_10_6  Bilinear_10_6  1
    MARKER    'MARKER'                 'INTORG'
    T_10_7    DAGSupMin_10  1
    T_10_7    DAGSupMax_10  1
    T_10_7    ForceCap_10_7  -7
    T_10_7    PCapLB_10_7  16
    T_10_7    PCapUB_10_7  -16
    T_10_7    TCapLB_10_7  112
    T_10_7    TCapUB_10_7  -112
    T_10_7    R488      -33
    T_10_7    R489      33
    T_10_7    R490      -33
    T_10_7    R491      33
    T_10_7    LayerUB_10_7  9
    T_10_7    LayerLB_10_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_10_7    ForceCap_10_7  1
    F_10_7    ForceBal_7  1
    F_10_7    ForceBal_10  -1
    P_10_7    PCapLB_10_7  1
    P_10_7    PCapUB_10_7  1
    P_10_7    R488      1
    P_10_7    R489      1
    P_10_7    R490      1
    P_10_7    R491      1
    Torque_10_7  TCapLB_10_7  1
    Torque_10_7  TCapUB_10_7  1
    Torque_10_7  TorqueBal_7  1
    Torque_10_7  TorqueBal_10  -1
    Torque_10_7  Bilinear_10_7  1
    MARKER    'MARKER'                 'INTORG'
    T_10_8    DAGSupMin_10  1
    T_10_8    DAGSupMax_10  1
    T_10_8    ForceCap_10_8  -7
    T_10_8    PCapLB_10_8  16
    T_10_8    PCapUB_10_8  -16
    T_10_8    TCapLB_10_8  112
    T_10_8    TCapUB_10_8  -112
    T_10_8    R499      -33
    T_10_8    R500      33
    T_10_8    R501      -33
    T_10_8    R502      33
    T_10_8    LayerUB_10_8  9
    T_10_8    LayerLB_10_8  -8
    MARKER    'MARKER'                 'INTEND'
    F_10_8    ForceCap_10_8  1
    F_10_8    ForceBal_8  1
    F_10_8    ForceBal_10  -1
    F_10_8    C2L_a_5   -1
    F_10_8    C2L_b_5   -8
    F_10_8    C2L_c_5   -1
    F_10_8    C2L_d_5   -8
    P_10_8    PCapLB_10_8  1
    P_10_8    PCapUB_10_8  1
    P_10_8    R499      1
    P_10_8    R500      1
    P_10_8    R501      1
    P_10_8    R502      1
    Torque_10_8  TCapLB_10_8  1
    Torque_10_8  TCapUB_10_8  1
    Torque_10_8  TorqueBal_8  1
    Torque_10_8  TorqueBal_10  -1
    Torque_10_8  Bilinear_10_8  1
    MARKER    'MARKER'                 'INTORG'
    T_10_9    DAGSupMin_10  1
    T_10_9    DAGSupMax_10  1
    T_10_9    ForceCap_10_9  -7
    T_10_9    PCapLB_10_9  16
    T_10_9    PCapUB_10_9  -16
    T_10_9    TCapLB_10_9  112
    T_10_9    TCapUB_10_9  -112
    T_10_9    R510      -33
    T_10_9    R511      33
    T_10_9    R512      -33
    T_10_9    R513      33
    T_10_9    LayerUB_10_9  9
    T_10_9    LayerLB_10_9  -9
    T_10_9    SP_6      -3.7624072023695261e+00
    T_10_9    SP_7      -4.7732071613454137e+00
    T_10_9    SP_8      -5.7956453692796064e+00
    T_10_9    NC_10_12_8_9  1
    MARKER    'MARKER'                 'INTEND'
    F_10_9    ForceCap_10_9  1
    F_10_9    ForceBal_9  1
    F_10_9    ForceBal_10  -1
    P_10_9    PCapLB_10_9  1
    P_10_9    PCapUB_10_9  1
    P_10_9    R510      1
    P_10_9    R511      1
    P_10_9    R512      1
    P_10_9    R513      1
    Torque_10_9  TCapLB_10_9  1
    Torque_10_9  TCapUB_10_9  1
    Torque_10_9  TorqueBal_9  1
    Torque_10_9  TorqueBal_10  -1
    Torque_10_9  Bilinear_10_9  1
    MARKER    'MARKER'                 'INTORG'
    T_11_1    DAGSupMin_11  1
    T_11_1    DAGSupMax_11  1
    T_11_1    ForceCap_11_1  -6
    T_11_1    PCapLB_11_1  16
    T_11_1    PCapUB_11_1  -16
    T_11_1    TCapLB_11_1  96
    T_11_1    TCapUB_11_1  -96
    T_11_1    R523      -33
    T_11_1    R524      33
    T_11_1    R525      -33
    T_11_1    R526      33
    T_11_1    LayerUB_11_1  10
    T_11_1    LayerLB_11_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_11_1    ForceCap_11_1  1
    F_11_1    ForceBal_1  1
    F_11_1    ForceBal_11  -1
    P_11_1    PCapLB_11_1  1
    P_11_1    PCapUB_11_1  1
    P_11_1    R523      1
    P_11_1    R524      1
    P_11_1    R525      1
    P_11_1    R526      1
    Torque_11_1  TCapLB_11_1  1
    Torque_11_1  TCapUB_11_1  1
    Torque_11_1  TorqueBal_1  1
    Torque_11_1  TorqueBal_11  -1
    Torque_11_1  Bilinear_11_1  1
    MARKER    'MARKER'                 'INTORG'
    T_11_2    DAGSupMin_11  1
    T_11_2    DAGSupMax_11  1
    T_11_2    ForceCap_11_2  -6
    T_11_2    PCapLB_11_2  16
    T_11_2    PCapUB_11_2  -16
    T_11_2    TCapLB_11_2  96
    T_11_2    TCapUB_11_2  -96
    T_11_2    R534      -33
    T_11_2    R535      33
    T_11_2    R536      -33
    T_11_2    R537      33
    T_11_2    LayerUB_11_2  10
    T_11_2    LayerLB_11_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_11_2    ForceCap_11_2  1
    F_11_2    ForceBal_2  1
    F_11_2    ForceBal_11  -1
    P_11_2    PCapLB_11_2  1
    P_11_2    PCapUB_11_2  1
    P_11_2    R534      1
    P_11_2    R535      1
    P_11_2    R536      1
    P_11_2    R537      1
    Torque_11_2  TCapLB_11_2  1
    Torque_11_2  TCapUB_11_2  1
    Torque_11_2  TorqueBal_2  1
    Torque_11_2  TorqueBal_11  -1
    Torque_11_2  Bilinear_11_2  1
    MARKER    'MARKER'                 'INTORG'
    T_11_3    DAGSupMin_11  1
    T_11_3    DAGSupMax_11  1
    T_11_3    ForceCap_11_3  -6
    T_11_3    PCapLB_11_3  16
    T_11_3    PCapUB_11_3  -16
    T_11_3    TCapLB_11_3  96
    T_11_3    TCapUB_11_3  -96
    T_11_3    R545      -33
    T_11_3    R546      33
    T_11_3    R547      -33
    T_11_3    R548      33
    T_11_3    LayerUB_11_3  10
    T_11_3    LayerLB_11_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_11_3    ForceCap_11_3  1
    F_11_3    ForceBal_3  1
    F_11_3    ForceBal_11  -1
    P_11_3    PCapLB_11_3  1
    P_11_3    PCapUB_11_3  1
    P_11_3    R545      1
    P_11_3    R546      1
    P_11_3    R547      1
    P_11_3    R548      1
    Torque_11_3  TCapLB_11_3  1
    Torque_11_3  TCapUB_11_3  1
    Torque_11_3  TorqueBal_3  1
    Torque_11_3  TorqueBal_11  -1
    Torque_11_3  Bilinear_11_3  1
    MARKER    'MARKER'                 'INTORG'
    T_11_4    DAGSupMin_11  1
    T_11_4    DAGSupMax_11  1
    T_11_4    ForceCap_11_4  -6
    T_11_4    PCapLB_11_4  16
    T_11_4    PCapUB_11_4  -16
    T_11_4    TCapLB_11_4  96
    T_11_4    TCapUB_11_4  -96
    T_11_4    R556      -33
    T_11_4    R557      33
    T_11_4    R558      -33
    T_11_4    R559      33
    T_11_4    LayerUB_11_4  10
    T_11_4    LayerLB_11_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_11_4    ForceCap_11_4  1
    F_11_4    ForceBal_4  1
    F_11_4    ForceBal_11  -1
    P_11_4    PCapLB_11_4  1
    P_11_4    PCapUB_11_4  1
    P_11_4    R556      1
    P_11_4    R557      1
    P_11_4    R558      1
    P_11_4    R559      1
    Torque_11_4  TCapLB_11_4  1
    Torque_11_4  TCapUB_11_4  1
    Torque_11_4  TorqueBal_4  1
    Torque_11_4  TorqueBal_11  -1
    Torque_11_4  Bilinear_11_4  1
    MARKER    'MARKER'                 'INTORG'
    T_11_5    DAGSupMin_11  1
    T_11_5    DAGSupMax_11  1
    T_11_5    ForceCap_11_5  -6
    T_11_5    PCapLB_11_5  16
    T_11_5    PCapUB_11_5  -16
    T_11_5    TCapLB_11_5  96
    T_11_5    TCapUB_11_5  -96
    T_11_5    R567      -33
    T_11_5    R568      33
    T_11_5    R569      -33
    T_11_5    R570      33
    T_11_5    LayerUB_11_5  10
    T_11_5    LayerLB_11_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_11_5    ForceCap_11_5  1
    F_11_5    ForceBal_5  1
    F_11_5    ForceBal_11  -1
    P_11_5    PCapLB_11_5  1
    P_11_5    PCapUB_11_5  1
    P_11_5    R567      1
    P_11_5    R568      1
    P_11_5    R569      1
    P_11_5    R570      1
    Torque_11_5  TCapLB_11_5  1
    Torque_11_5  TCapUB_11_5  1
    Torque_11_5  TorqueBal_5  1
    Torque_11_5  TorqueBal_11  -1
    Torque_11_5  Bilinear_11_5  1
    MARKER    'MARKER'                 'INTORG'
    T_11_6    DAGSupMin_11  1
    T_11_6    DAGSupMax_11  1
    T_11_6    ForceCap_11_6  -6
    T_11_6    PCapLB_11_6  16
    T_11_6    PCapUB_11_6  -16
    T_11_6    TCapLB_11_6  96
    T_11_6    TCapUB_11_6  -96
    T_11_6    R578      -33
    T_11_6    R579      33
    T_11_6    R580      -33
    T_11_6    R581      33
    T_11_6    LayerUB_11_6  10
    T_11_6    LayerLB_11_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_11_6    ForceCap_11_6  1
    F_11_6    ForceBal_6  1
    F_11_6    ForceBal_11  -1
    P_11_6    PCapLB_11_6  1
    P_11_6    PCapUB_11_6  1
    P_11_6    R578      1
    P_11_6    R579      1
    P_11_6    R580      1
    P_11_6    R581      1
    Torque_11_6  TCapLB_11_6  1
    Torque_11_6  TCapUB_11_6  1
    Torque_11_6  TorqueBal_6  1
    Torque_11_6  TorqueBal_11  -1
    Torque_11_6  Bilinear_11_6  1
    MARKER    'MARKER'                 'INTORG'
    T_11_7    DAGSupMin_11  1
    T_11_7    DAGSupMax_11  1
    T_11_7    ForceCap_11_7  -6
    T_11_7    PCapLB_11_7  16
    T_11_7    PCapUB_11_7  -16
    T_11_7    TCapLB_11_7  96
    T_11_7    TCapUB_11_7  -96
    T_11_7    R589      -33
    T_11_7    R590      33
    T_11_7    R591      -33
    T_11_7    R592      33
    T_11_7    LayerUB_11_7  10
    T_11_7    LayerLB_11_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_11_7    ForceCap_11_7  1
    F_11_7    ForceBal_7  1
    F_11_7    ForceBal_11  -1
    P_11_7    PCapLB_11_7  1
    P_11_7    PCapUB_11_7  1
    P_11_7    R589      1
    P_11_7    R590      1
    P_11_7    R591      1
    P_11_7    R592      1
    Torque_11_7  TCapLB_11_7  1
    Torque_11_7  TCapUB_11_7  1
    Torque_11_7  TorqueBal_7  1
    Torque_11_7  TorqueBal_11  -1
    Torque_11_7  Bilinear_11_7  1
    MARKER    'MARKER'                 'INTORG'
    T_11_8    DAGSupMin_11  1
    T_11_8    DAGSupMax_11  1
    T_11_8    ForceCap_11_8  -6
    T_11_8    PCapLB_11_8  16
    T_11_8    PCapUB_11_8  -16
    T_11_8    TCapLB_11_8  96
    T_11_8    TCapUB_11_8  -96
    T_11_8    R600      -33
    T_11_8    R601      33
    T_11_8    R602      -33
    T_11_8    R603      33
    T_11_8    LayerUB_11_8  10
    T_11_8    LayerLB_11_8  -8
    MARKER    'MARKER'                 'INTEND'
    F_11_8    ForceCap_11_8  1
    F_11_8    ForceBal_8  1
    F_11_8    ForceBal_11  -1
    F_11_8    C2L_a_5   -1
    F_11_8    C2L_b_5   -8
    F_11_8    C2L_c_5   -1
    F_11_8    C2L_d_5   -8
    P_11_8    PCapLB_11_8  1
    P_11_8    PCapUB_11_8  1
    P_11_8    R600      1
    P_11_8    R601      1
    P_11_8    R602      1
    P_11_8    R603      1
    Torque_11_8  TCapLB_11_8  1
    Torque_11_8  TCapUB_11_8  1
    Torque_11_8  TorqueBal_8  1
    Torque_11_8  TorqueBal_11  -1
    Torque_11_8  Bilinear_11_8  1
    MARKER    'MARKER'                 'INTORG'
    T_11_9    DAGSupMin_11  1
    T_11_9    DAGSupMax_11  1
    T_11_9    ForceCap_11_9  -6
    T_11_9    PCapLB_11_9  16
    T_11_9    PCapUB_11_9  -16
    T_11_9    TCapLB_11_9  96
    T_11_9    TCapUB_11_9  -96
    T_11_9    R611      -33
    T_11_9    R612      33
    T_11_9    R613      -33
    T_11_9    R614      33
    T_11_9    LayerUB_11_9  10
    T_11_9    LayerLB_11_9  -9
    MARKER    'MARKER'                 'INTEND'
    F_11_9    ForceCap_11_9  1
    F_11_9    ForceBal_9  1
    F_11_9    ForceBal_11  -1
    P_11_9    PCapLB_11_9  1
    P_11_9    PCapUB_11_9  1
    P_11_9    R611      1
    P_11_9    R612      1
    P_11_9    R613      1
    P_11_9    R614      1
    Torque_11_9  TCapLB_11_9  1
    Torque_11_9  TCapUB_11_9  1
    Torque_11_9  TorqueBal_9  1
    Torque_11_9  TorqueBal_11  -1
    Torque_11_9  Bilinear_11_9  1
    MARKER    'MARKER'                 'INTORG'
    T_11_10   DAGSupMin_11  1
    T_11_10   DAGSupMax_11  1
    T_11_10   ForceCap_11_10  -6
    T_11_10   PCapLB_11_10  16
    T_11_10   PCapUB_11_10  -16
    T_11_10   TCapLB_11_10  96
    T_11_10   TCapUB_11_10  -96
    T_11_10   R622      -33
    T_11_10   R623      33
    T_11_10   R624      -33
    T_11_10   R625      33
    T_11_10   LayerUB_11_10  10
    T_11_10   LayerLB_11_10  -10
    MARKER    'MARKER'                 'INTEND'
    F_11_10   ForceCap_11_10  1
    F_11_10   ForceBal_10  1
    F_11_10   ForceBal_11  -1
    P_11_10   PCapLB_11_10  1
    P_11_10   PCapUB_11_10  1
    P_11_10   R622      1
    P_11_10   R623      1
    P_11_10   R624      1
    P_11_10   R625      1
    Torque_11_10  TCapLB_11_10  1
    Torque_11_10  TCapUB_11_10  1
    Torque_11_10  TorqueBal_10  1
    Torque_11_10  TorqueBal_11  -1
    Torque_11_10  Bilinear_11_10  1
    MARKER    'MARKER'                 'INTORG'
    T_12_1    DAGSupMin_12  1
    T_12_1    DAGSupMax_12  1
    T_12_1    ForceCap_12_1  -5
    T_12_1    PCapLB_12_1  16
    T_12_1    PCapUB_12_1  -16
    T_12_1    TCapLB_12_1  80
    T_12_1    TCapUB_12_1  -80
    T_12_1    R635      -33
    T_12_1    R636      33
    T_12_1    R637      -33
    T_12_1    R638      33
    T_12_1    LayerUB_12_1  11
    T_12_1    LayerLB_12_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_12_1    ForceCap_12_1  1
    F_12_1    ForceBal_1  1
    F_12_1    ForceBal_12  -1
    P_12_1    PCapLB_12_1  1
    P_12_1    PCapUB_12_1  1
    P_12_1    R635      1
    P_12_1    R636      1
    P_12_1    R637      1
    P_12_1    R638      1
    Torque_12_1  TCapLB_12_1  1
    Torque_12_1  TCapUB_12_1  1
    Torque_12_1  TorqueBal_1  1
    Torque_12_1  TorqueBal_12  -1
    Torque_12_1  Bilinear_12_1  1
    MARKER    'MARKER'                 'INTORG'
    T_12_2    DAGSupMin_12  1
    T_12_2    DAGSupMax_12  1
    T_12_2    ForceCap_12_2  -5
    T_12_2    PCapLB_12_2  16
    T_12_2    PCapUB_12_2  -16
    T_12_2    TCapLB_12_2  80
    T_12_2    TCapUB_12_2  -80
    T_12_2    R646      -33
    T_12_2    R647      33
    T_12_2    R648      -33
    T_12_2    R649      33
    T_12_2    LayerUB_12_2  11
    T_12_2    LayerLB_12_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_12_2    ForceCap_12_2  1
    F_12_2    ForceBal_2  1
    F_12_2    ForceBal_12  -1
    P_12_2    PCapLB_12_2  1
    P_12_2    PCapUB_12_2  1
    P_12_2    R646      1
    P_12_2    R647      1
    P_12_2    R648      1
    P_12_2    R649      1
    Torque_12_2  TCapLB_12_2  1
    Torque_12_2  TCapUB_12_2  1
    Torque_12_2  TorqueBal_2  1
    Torque_12_2  TorqueBal_12  -1
    Torque_12_2  Bilinear_12_2  1
    MARKER    'MARKER'                 'INTORG'
    T_12_3    DAGSupMin_12  1
    T_12_3    DAGSupMax_12  1
    T_12_3    ForceCap_12_3  -5
    T_12_3    PCapLB_12_3  16
    T_12_3    PCapUB_12_3  -16
    T_12_3    TCapLB_12_3  80
    T_12_3    TCapUB_12_3  -80
    T_12_3    R657      -33
    T_12_3    R658      33
    T_12_3    R659      -33
    T_12_3    R660      33
    T_12_3    LayerUB_12_3  11
    T_12_3    LayerLB_12_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_12_3    ForceCap_12_3  1
    F_12_3    ForceBal_3  1
    F_12_3    ForceBal_12  -1
    P_12_3    PCapLB_12_3  1
    P_12_3    PCapUB_12_3  1
    P_12_3    R657      1
    P_12_3    R658      1
    P_12_3    R659      1
    P_12_3    R660      1
    Torque_12_3  TCapLB_12_3  1
    Torque_12_3  TCapUB_12_3  1
    Torque_12_3  TorqueBal_3  1
    Torque_12_3  TorqueBal_12  -1
    Torque_12_3  Bilinear_12_3  1
    MARKER    'MARKER'                 'INTORG'
    T_12_4    DAGSupMin_12  1
    T_12_4    DAGSupMax_12  1
    T_12_4    ForceCap_12_4  -5
    T_12_4    PCapLB_12_4  16
    T_12_4    PCapUB_12_4  -16
    T_12_4    TCapLB_12_4  80
    T_12_4    TCapUB_12_4  -80
    T_12_4    R668      -33
    T_12_4    R669      33
    T_12_4    R670      -33
    T_12_4    R671      33
    T_12_4    LayerUB_12_4  11
    T_12_4    LayerLB_12_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_12_4    ForceCap_12_4  1
    F_12_4    ForceBal_4  1
    F_12_4    ForceBal_12  -1
    P_12_4    PCapLB_12_4  1
    P_12_4    PCapUB_12_4  1
    P_12_4    R668      1
    P_12_4    R669      1
    P_12_4    R670      1
    P_12_4    R671      1
    Torque_12_4  TCapLB_12_4  1
    Torque_12_4  TCapUB_12_4  1
    Torque_12_4  TorqueBal_4  1
    Torque_12_4  TorqueBal_12  -1
    Torque_12_4  Bilinear_12_4  1
    MARKER    'MARKER'                 'INTORG'
    T_12_5    DAGSupMin_12  1
    T_12_5    DAGSupMax_12  1
    T_12_5    ForceCap_12_5  -5
    T_12_5    PCapLB_12_5  16
    T_12_5    PCapUB_12_5  -16
    T_12_5    TCapLB_12_5  80
    T_12_5    TCapUB_12_5  -80
    T_12_5    R679      -33
    T_12_5    R680      33
    T_12_5    R681      -33
    T_12_5    R682      33
    T_12_5    LayerUB_12_5  11
    T_12_5    LayerLB_12_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_12_5    ForceCap_12_5  1
    F_12_5    ForceBal_5  1
    F_12_5    ForceBal_12  -1
    P_12_5    PCapLB_12_5  1
    P_12_5    PCapUB_12_5  1
    P_12_5    R679      1
    P_12_5    R680      1
    P_12_5    R681      1
    P_12_5    R682      1
    Torque_12_5  TCapLB_12_5  1
    Torque_12_5  TCapUB_12_5  1
    Torque_12_5  TorqueBal_5  1
    Torque_12_5  TorqueBal_12  -1
    Torque_12_5  Bilinear_12_5  1
    MARKER    'MARKER'                 'INTORG'
    T_12_6    DAGSupMin_12  1
    T_12_6    DAGSupMax_12  1
    T_12_6    ForceCap_12_6  -5
    T_12_6    PCapLB_12_6  16
    T_12_6    PCapUB_12_6  -16
    T_12_6    TCapLB_12_6  80
    T_12_6    TCapUB_12_6  -80
    T_12_6    R690      -33
    T_12_6    R691      33
    T_12_6    R692      -33
    T_12_6    R693      33
    T_12_6    LayerUB_12_6  11
    T_12_6    LayerLB_12_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_12_6    ForceCap_12_6  1
    F_12_6    ForceBal_6  1
    F_12_6    ForceBal_12  -1
    P_12_6    PCapLB_12_6  1
    P_12_6    PCapUB_12_6  1
    P_12_6    R690      1
    P_12_6    R691      1
    P_12_6    R692      1
    P_12_6    R693      1
    Torque_12_6  TCapLB_12_6  1
    Torque_12_6  TCapUB_12_6  1
    Torque_12_6  TorqueBal_6  1
    Torque_12_6  TorqueBal_12  -1
    Torque_12_6  Bilinear_12_6  1
    MARKER    'MARKER'                 'INTORG'
    T_12_7    DAGSupMin_12  1
    T_12_7    DAGSupMax_12  1
    T_12_7    ForceCap_12_7  -5
    T_12_7    PCapLB_12_7  16
    T_12_7    PCapUB_12_7  -16
    T_12_7    TCapLB_12_7  80
    T_12_7    TCapUB_12_7  -80
    T_12_7    R701      -33
    T_12_7    R702      33
    T_12_7    R703      -33
    T_12_7    R704      33
    T_12_7    LayerUB_12_7  11
    T_12_7    LayerLB_12_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_12_7    ForceCap_12_7  1
    F_12_7    ForceBal_7  1
    F_12_7    ForceBal_12  -1
    P_12_7    PCapLB_12_7  1
    P_12_7    PCapUB_12_7  1
    P_12_7    R701      1
    P_12_7    R702      1
    P_12_7    R703      1
    P_12_7    R704      1
    Torque_12_7  TCapLB_12_7  1
    Torque_12_7  TCapUB_12_7  1
    Torque_12_7  TorqueBal_7  1
    Torque_12_7  TorqueBal_12  -1
    Torque_12_7  Bilinear_12_7  1
    MARKER    'MARKER'                 'INTORG'
    T_12_8    DAGSupMin_12  1
    T_12_8    DAGSupMax_12  1
    T_12_8    ForceCap_12_8  -5
    T_12_8    PCapLB_12_8  16
    T_12_8    PCapUB_12_8  -16
    T_12_8    TCapLB_12_8  80
    T_12_8    TCapUB_12_8  -80
    T_12_8    R712      -33
    T_12_8    R713      33
    T_12_8    R714      -33
    T_12_8    R715      33
    T_12_8    LayerUB_12_8  11
    T_12_8    LayerLB_12_8  -8
    T_12_8    NC_10_12_8_9  1
    MARKER    'MARKER'                 'INTEND'
    F_12_8    ForceCap_12_8  1
    F_12_8    ForceBal_8  1
    F_12_8    ForceBal_12  -1
    F_12_8    C2L_a_5   -1
    F_12_8    C2L_b_5   -8
    F_12_8    C2L_c_5   -1
    F_12_8    C2L_d_5   -8
    P_12_8    PCapLB_12_8  1
    P_12_8    PCapUB_12_8  1
    P_12_8    R712      1
    P_12_8    R713      1
    P_12_8    R714      1
    P_12_8    R715      1
    Torque_12_8  TCapLB_12_8  1
    Torque_12_8  TCapUB_12_8  1
    Torque_12_8  TorqueBal_8  1
    Torque_12_8  TorqueBal_12  -1
    Torque_12_8  Bilinear_12_8  1
    MARKER    'MARKER'                 'INTORG'
    T_12_9    DAGSupMin_12  1
    T_12_9    DAGSupMax_12  1
    T_12_9    ForceCap_12_9  -5
    T_12_9    PCapLB_12_9  16
    T_12_9    PCapUB_12_9  -16
    T_12_9    TCapLB_12_9  80
    T_12_9    TCapUB_12_9  -80
    T_12_9    R723      -33
    T_12_9    R724      33
    T_12_9    R725      -33
    T_12_9    R726      33
    T_12_9    LayerUB_12_9  11
    T_12_9    LayerLB_12_9  -9
    MARKER    'MARKER'                 'INTEND'
    F_12_9    ForceCap_12_9  1
    F_12_9    ForceBal_9  1
    F_12_9    ForceBal_12  -1
    P_12_9    PCapLB_12_9  1
    P_12_9    PCapUB_12_9  1
    P_12_9    R723      1
    P_12_9    R724      1
    P_12_9    R725      1
    P_12_9    R726      1
    Torque_12_9  TCapLB_12_9  1
    Torque_12_9  TCapUB_12_9  1
    Torque_12_9  TorqueBal_9  1
    Torque_12_9  TorqueBal_12  -1
    Torque_12_9  Bilinear_12_9  1
    MARKER    'MARKER'                 'INTORG'
    T_12_10   DAGSupMin_12  1
    T_12_10   DAGSupMax_12  1
    T_12_10   ForceCap_12_10  -5
    T_12_10   PCapLB_12_10  16
    T_12_10   PCapUB_12_10  -16
    T_12_10   TCapLB_12_10  80
    T_12_10   TCapUB_12_10  -80
    T_12_10   R734      -33
    T_12_10   R735      33
    T_12_10   R736      -33
    T_12_10   R737      33
    T_12_10   LayerUB_12_10  11
    T_12_10   LayerLB_12_10  -10
    MARKER    'MARKER'                 'INTEND'
    F_12_10   ForceCap_12_10  1
    F_12_10   ForceBal_10  1
    F_12_10   ForceBal_12  -1
    P_12_10   PCapLB_12_10  1
    P_12_10   PCapUB_12_10  1
    P_12_10   R734      1
    P_12_10   R735      1
    P_12_10   R736      1
    P_12_10   R737      1
    Torque_12_10  TCapLB_12_10  1
    Torque_12_10  TCapUB_12_10  1
    Torque_12_10  TorqueBal_10  1
    Torque_12_10  TorqueBal_12  -1
    Torque_12_10  Bilinear_12_10  1
    MARKER    'MARKER'                 'INTORG'
    T_12_11   DAGSupMin_12  1
    T_12_11   DAGSupMax_12  1
    T_12_11   ForceCap_12_11  -5
    T_12_11   PCapLB_12_11  16
    T_12_11   PCapUB_12_11  -16
    T_12_11   TCapLB_12_11  80
    T_12_11   TCapUB_12_11  -80
    T_12_11   R745      -33
    T_12_11   R746      33
    T_12_11   R747      -33
    T_12_11   R748      33
    T_12_11   LayerUB_12_11  11
    T_12_11   LayerLB_12_11  -11
    MARKER    'MARKER'                 'INTEND'
    F_12_11   ForceCap_12_11  1
    F_12_11   ForceBal_11  1
    F_12_11   ForceBal_12  -1
    P_12_11   PCapLB_12_11  1
    P_12_11   PCapUB_12_11  1
    P_12_11   R745      1
    P_12_11   R746      1
    P_12_11   R747      1
    P_12_11   R748      1
    Torque_12_11  TCapLB_12_11  1
    Torque_12_11  TCapUB_12_11  1
    Torque_12_11  TorqueBal_11  1
    Torque_12_11  TorqueBal_12  -1
    Torque_12_11  Bilinear_12_11  1
    MARKER    'MARKER'                 'INTORG'
    T_13_1    DAGSupMin_13  1
    T_13_1    DAGSupMax_13  1
    T_13_1    ForceCap_13_1  -4
    T_13_1    PCapLB_13_1  16
    T_13_1    PCapUB_13_1  -16
    T_13_1    TCapLB_13_1  64
    T_13_1    TCapUB_13_1  -64
    T_13_1    R758      -33
    T_13_1    R759      33
    T_13_1    R760      -33
    T_13_1    R761      33
    T_13_1    LayerUB_13_1  12
    T_13_1    LayerLB_13_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_13_1    ForceCap_13_1  1
    F_13_1    ForceBal_1  1
    F_13_1    ForceBal_13  -1
    P_13_1    PCapLB_13_1  1
    P_13_1    PCapUB_13_1  1
    P_13_1    R758      1
    P_13_1    R759      1
    P_13_1    R760      1
    P_13_1    R761      1
    Torque_13_1  TCapLB_13_1  1
    Torque_13_1  TCapUB_13_1  1
    Torque_13_1  TorqueBal_1  1
    Torque_13_1  TorqueBal_13  -1
    Torque_13_1  Bilinear_13_1  1
    MARKER    'MARKER'                 'INTORG'
    T_13_2    DAGSupMin_13  1
    T_13_2    DAGSupMax_13  1
    T_13_2    ForceCap_13_2  -4
    T_13_2    PCapLB_13_2  16
    T_13_2    PCapUB_13_2  -16
    T_13_2    TCapLB_13_2  64
    T_13_2    TCapUB_13_2  -64
    T_13_2    R769      -33
    T_13_2    R770      33
    T_13_2    R771      -33
    T_13_2    R772      33
    T_13_2    LayerUB_13_2  12
    T_13_2    LayerLB_13_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_13_2    ForceCap_13_2  1
    F_13_2    ForceBal_2  1
    F_13_2    ForceBal_13  -1
    P_13_2    PCapLB_13_2  1
    P_13_2    PCapUB_13_2  1
    P_13_2    R769      1
    P_13_2    R770      1
    P_13_2    R771      1
    P_13_2    R772      1
    Torque_13_2  TCapLB_13_2  1
    Torque_13_2  TCapUB_13_2  1
    Torque_13_2  TorqueBal_2  1
    Torque_13_2  TorqueBal_13  -1
    Torque_13_2  Bilinear_13_2  1
    MARKER    'MARKER'                 'INTORG'
    T_13_3    DAGSupMin_13  1
    T_13_3    DAGSupMax_13  1
    T_13_3    ForceCap_13_3  -4
    T_13_3    PCapLB_13_3  16
    T_13_3    PCapUB_13_3  -16
    T_13_3    TCapLB_13_3  64
    T_13_3    TCapUB_13_3  -64
    T_13_3    R780      -33
    T_13_3    R781      33
    T_13_3    R782      -33
    T_13_3    R783      33
    T_13_3    LayerUB_13_3  12
    T_13_3    LayerLB_13_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_13_3    ForceCap_13_3  1
    F_13_3    ForceBal_3  1
    F_13_3    ForceBal_13  -1
    P_13_3    PCapLB_13_3  1
    P_13_3    PCapUB_13_3  1
    P_13_3    R780      1
    P_13_3    R781      1
    P_13_3    R782      1
    P_13_3    R783      1
    Torque_13_3  TCapLB_13_3  1
    Torque_13_3  TCapUB_13_3  1
    Torque_13_3  TorqueBal_3  1
    Torque_13_3  TorqueBal_13  -1
    Torque_13_3  Bilinear_13_3  1
    MARKER    'MARKER'                 'INTORG'
    T_13_4    DAGSupMin_13  1
    T_13_4    DAGSupMax_13  1
    T_13_4    ForceCap_13_4  -4
    T_13_4    PCapLB_13_4  16
    T_13_4    PCapUB_13_4  -16
    T_13_4    TCapLB_13_4  64
    T_13_4    TCapUB_13_4  -64
    T_13_4    R791      -33
    T_13_4    R792      33
    T_13_4    R793      -33
    T_13_4    R794      33
    T_13_4    LayerUB_13_4  12
    T_13_4    LayerLB_13_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_13_4    ForceCap_13_4  1
    F_13_4    ForceBal_4  1
    F_13_4    ForceBal_13  -1
    P_13_4    PCapLB_13_4  1
    P_13_4    PCapUB_13_4  1
    P_13_4    R791      1
    P_13_4    R792      1
    P_13_4    R793      1
    P_13_4    R794      1
    Torque_13_4  TCapLB_13_4  1
    Torque_13_4  TCapUB_13_4  1
    Torque_13_4  TorqueBal_4  1
    Torque_13_4  TorqueBal_13  -1
    Torque_13_4  Bilinear_13_4  1
    MARKER    'MARKER'                 'INTORG'
    T_13_5    DAGSupMin_13  1
    T_13_5    DAGSupMax_13  1
    T_13_5    ForceCap_13_5  -4
    T_13_5    PCapLB_13_5  16
    T_13_5    PCapUB_13_5  -16
    T_13_5    TCapLB_13_5  64
    T_13_5    TCapUB_13_5  -64
    T_13_5    R802      -33
    T_13_5    R803      33
    T_13_5    R804      -33
    T_13_5    R805      33
    T_13_5    LayerUB_13_5  12
    T_13_5    LayerLB_13_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_13_5    ForceCap_13_5  1
    F_13_5    ForceBal_5  1
    F_13_5    ForceBal_13  -1
    P_13_5    PCapLB_13_5  1
    P_13_5    PCapUB_13_5  1
    P_13_5    R802      1
    P_13_5    R803      1
    P_13_5    R804      1
    P_13_5    R805      1
    Torque_13_5  TCapLB_13_5  1
    Torque_13_5  TCapUB_13_5  1
    Torque_13_5  TorqueBal_5  1
    Torque_13_5  TorqueBal_13  -1
    Torque_13_5  Bilinear_13_5  1
    MARKER    'MARKER'                 'INTORG'
    T_13_6    DAGSupMin_13  1
    T_13_6    DAGSupMax_13  1
    T_13_6    ForceCap_13_6  -4
    T_13_6    PCapLB_13_6  16
    T_13_6    PCapUB_13_6  -16
    T_13_6    TCapLB_13_6  64
    T_13_6    TCapUB_13_6  -64
    T_13_6    R813      -33
    T_13_6    R814      33
    T_13_6    R815      -33
    T_13_6    R816      33
    T_13_6    LayerUB_13_6  12
    T_13_6    LayerLB_13_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_13_6    ForceCap_13_6  1
    F_13_6    ForceBal_6  1
    F_13_6    ForceBal_13  -1
    P_13_6    PCapLB_13_6  1
    P_13_6    PCapUB_13_6  1
    P_13_6    R813      1
    P_13_6    R814      1
    P_13_6    R815      1
    P_13_6    R816      1
    Torque_13_6  TCapLB_13_6  1
    Torque_13_6  TCapUB_13_6  1
    Torque_13_6  TorqueBal_6  1
    Torque_13_6  TorqueBal_13  -1
    Torque_13_6  Bilinear_13_6  1
    MARKER    'MARKER'                 'INTORG'
    T_13_7    DAGSupMin_13  1
    T_13_7    DAGSupMax_13  1
    T_13_7    ForceCap_13_7  -4
    T_13_7    PCapLB_13_7  16
    T_13_7    PCapUB_13_7  -16
    T_13_7    TCapLB_13_7  64
    T_13_7    TCapUB_13_7  -64
    T_13_7    R824      -33
    T_13_7    R825      33
    T_13_7    R826      -33
    T_13_7    R827      33
    T_13_7    LayerUB_13_7  12
    T_13_7    LayerLB_13_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_13_7    ForceCap_13_7  1
    F_13_7    ForceBal_7  1
    F_13_7    ForceBal_13  -1
    P_13_7    PCapLB_13_7  1
    P_13_7    PCapUB_13_7  1
    P_13_7    R824      1
    P_13_7    R825      1
    P_13_7    R826      1
    P_13_7    R827      1
    Torque_13_7  TCapLB_13_7  1
    Torque_13_7  TCapUB_13_7  1
    Torque_13_7  TorqueBal_7  1
    Torque_13_7  TorqueBal_13  -1
    Torque_13_7  Bilinear_13_7  1
    MARKER    'MARKER'                 'INTORG'
    T_13_8    DAGSupMin_13  1
    T_13_8    DAGSupMax_13  1
    T_13_8    ForceCap_13_8  -4
    T_13_8    PCapLB_13_8  16
    T_13_8    PCapUB_13_8  -16
    T_13_8    TCapLB_13_8  64
    T_13_8    TCapUB_13_8  -64
    T_13_8    R835      -33
    T_13_8    R836      33
    T_13_8    R837      -33
    T_13_8    R838      33
    T_13_8    LayerUB_13_8  12
    T_13_8    LayerLB_13_8  -8
    MARKER    'MARKER'                 'INTEND'
    F_13_8    ForceCap_13_8  1
    F_13_8    ForceBal_8  1
    F_13_8    ForceBal_13  -1
    P_13_8    PCapLB_13_8  1
    P_13_8    PCapUB_13_8  1
    P_13_8    R835      1
    P_13_8    R836      1
    P_13_8    R837      1
    P_13_8    R838      1
    Torque_13_8  TCapLB_13_8  1
    Torque_13_8  TCapUB_13_8  1
    Torque_13_8  TorqueBal_8  1
    Torque_13_8  TorqueBal_13  -1
    Torque_13_8  Bilinear_13_8  1
    MARKER    'MARKER'                 'INTORG'
    T_13_9    DAGSupMin_13  1
    T_13_9    DAGSupMax_13  1
    T_13_9    ForceCap_13_9  -4
    T_13_9    PCapLB_13_9  16
    T_13_9    PCapUB_13_9  -16
    T_13_9    TCapLB_13_9  64
    T_13_9    TCapUB_13_9  -64
    T_13_9    R846      -33
    T_13_9    R847      33
    T_13_9    R848      -33
    T_13_9    R849      33
    T_13_9    LayerUB_13_9  12
    T_13_9    LayerLB_13_9  -9
    MARKER    'MARKER'                 'INTEND'
    F_13_9    ForceCap_13_9  1
    F_13_9    ForceBal_9  1
    F_13_9    ForceBal_13  -1
    P_13_9    PCapLB_13_9  1
    P_13_9    PCapUB_13_9  1
    P_13_9    R846      1
    P_13_9    R847      1
    P_13_9    R848      1
    P_13_9    R849      1
    Torque_13_9  TCapLB_13_9  1
    Torque_13_9  TCapUB_13_9  1
    Torque_13_9  TorqueBal_9  1
    Torque_13_9  TorqueBal_13  -1
    Torque_13_9  Bilinear_13_9  1
    MARKER    'MARKER'                 'INTORG'
    T_13_10   DAGSupMin_13  1
    T_13_10   DAGSupMax_13  1
    T_13_10   ForceCap_13_10  -4
    T_13_10   PCapLB_13_10  16
    T_13_10   PCapUB_13_10  -16
    T_13_10   TCapLB_13_10  64
    T_13_10   TCapUB_13_10  -64
    T_13_10   R857      -33
    T_13_10   R858      33
    T_13_10   R859      -33
    T_13_10   R860      33
    T_13_10   LayerUB_13_10  12
    T_13_10   LayerLB_13_10  -10
    MARKER    'MARKER'                 'INTEND'
    F_13_10   ForceCap_13_10  1
    F_13_10   ForceBal_10  1
    F_13_10   ForceBal_13  -1
    P_13_10   PCapLB_13_10  1
    P_13_10   PCapUB_13_10  1
    P_13_10   R857      1
    P_13_10   R858      1
    P_13_10   R859      1
    P_13_10   R860      1
    Torque_13_10  TCapLB_13_10  1
    Torque_13_10  TCapUB_13_10  1
    Torque_13_10  TorqueBal_10  1
    Torque_13_10  TorqueBal_13  -1
    Torque_13_10  Bilinear_13_10  1
    MARKER    'MARKER'                 'INTORG'
    T_13_11   DAGSupMin_13  1
    T_13_11   DAGSupMax_13  1
    T_13_11   ForceCap_13_11  -4
    T_13_11   PCapLB_13_11  16
    T_13_11   PCapUB_13_11  -16
    T_13_11   TCapLB_13_11  64
    T_13_11   TCapUB_13_11  -64
    T_13_11   R868      -33
    T_13_11   R869      33
    T_13_11   R870      -33
    T_13_11   R871      33
    T_13_11   LayerUB_13_11  12
    T_13_11   LayerLB_13_11  -11
    T_13_11   SP_7      -4.7732071613454137e+00
    T_13_11   SP_8      -5.7956453692796064e+00
    T_13_11   NC_13_15_10_11  1
    MARKER    'MARKER'                 'INTEND'
    F_13_11   ForceCap_13_11  1
    F_13_11   ForceBal_11  1
    F_13_11   ForceBal_13  -1
    P_13_11   PCapLB_13_11  1
    P_13_11   PCapUB_13_11  1
    P_13_11   R868      1
    P_13_11   R869      1
    P_13_11   R870      1
    P_13_11   R871      1
    Torque_13_11  TCapLB_13_11  1
    Torque_13_11  TCapUB_13_11  1
    Torque_13_11  TorqueBal_11  1
    Torque_13_11  TorqueBal_13  -1
    Torque_13_11  Bilinear_13_11  1
    MARKER    'MARKER'                 'INTORG'
    T_13_12   DAGSupMin_13  1
    T_13_12   DAGSupMax_13  1
    T_13_12   ForceCap_13_12  -4
    T_13_12   PCapLB_13_12  16
    T_13_12   PCapUB_13_12  -16
    T_13_12   TCapLB_13_12  64
    T_13_12   TCapUB_13_12  -64
    T_13_12   R879      -33
    T_13_12   R880      33
    T_13_12   R881      -33
    T_13_12   R882      33
    T_13_12   LayerUB_13_12  12
    T_13_12   LayerLB_13_12  -12
    T_13_12   SP_7      -4.7732071613454137e+00
    T_13_12   SP_8      -5.7956453692796064e+00
    T_13_12   NC_13_14_10_12  1
    T_13_12   NC_13_15_10_12  1
    T_13_12   NC_13_15_11_12  1
    MARKER    'MARKER'                 'INTEND'
    F_13_12   ForceCap_13_12  1
    F_13_12   ForceBal_12  1
    F_13_12   ForceBal_13  -1
    P_13_12   PCapLB_13_12  1
    P_13_12   PCapUB_13_12  1
    P_13_12   R879      1
    P_13_12   R880      1
    P_13_12   R881      1
    P_13_12   R882      1
    Torque_13_12  TCapLB_13_12  1
    Torque_13_12  TCapUB_13_12  1
    Torque_13_12  TorqueBal_12  1
    Torque_13_12  TorqueBal_13  -1
    Torque_13_12  Bilinear_13_12  1
    MARKER    'MARKER'                 'INTORG'
    T_14_1    DAGSupMin_14  1
    T_14_1    DAGSupMax_14  1
    T_14_1    ForceCap_14_1  -3
    T_14_1    PCapLB_14_1  16
    T_14_1    PCapUB_14_1  -16
    T_14_1    TCapLB_14_1  48
    T_14_1    TCapUB_14_1  -48
    T_14_1    R892      -33
    T_14_1    R893      33
    T_14_1    R894      -33
    T_14_1    R895      33
    T_14_1    LayerUB_14_1  13
    T_14_1    LayerLB_14_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_14_1    ForceCap_14_1  1
    F_14_1    ForceBal_1  1
    F_14_1    ForceBal_14  -1
    P_14_1    PCapLB_14_1  1
    P_14_1    PCapUB_14_1  1
    P_14_1    R892      1
    P_14_1    R893      1
    P_14_1    R894      1
    P_14_1    R895      1
    Torque_14_1  TCapLB_14_1  1
    Torque_14_1  TCapUB_14_1  1
    Torque_14_1  TorqueBal_1  1
    Torque_14_1  TorqueBal_14  -1
    Torque_14_1  Bilinear_14_1  1
    MARKER    'MARKER'                 'INTORG'
    T_14_2    DAGSupMin_14  1
    T_14_2    DAGSupMax_14  1
    T_14_2    ForceCap_14_2  -3
    T_14_2    PCapLB_14_2  16
    T_14_2    PCapUB_14_2  -16
    T_14_2    TCapLB_14_2  48
    T_14_2    TCapUB_14_2  -48
    T_14_2    R903      -33
    T_14_2    R904      33
    T_14_2    R905      -33
    T_14_2    R906      33
    T_14_2    LayerUB_14_2  13
    T_14_2    LayerLB_14_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_14_2    ForceCap_14_2  1
    F_14_2    ForceBal_2  1
    F_14_2    ForceBal_14  -1
    P_14_2    PCapLB_14_2  1
    P_14_2    PCapUB_14_2  1
    P_14_2    R903      1
    P_14_2    R904      1
    P_14_2    R905      1
    P_14_2    R906      1
    Torque_14_2  TCapLB_14_2  1
    Torque_14_2  TCapUB_14_2  1
    Torque_14_2  TorqueBal_2  1
    Torque_14_2  TorqueBal_14  -1
    Torque_14_2  Bilinear_14_2  1
    MARKER    'MARKER'                 'INTORG'
    T_14_3    DAGSupMin_14  1
    T_14_3    DAGSupMax_14  1
    T_14_3    ForceCap_14_3  -3
    T_14_3    PCapLB_14_3  16
    T_14_3    PCapUB_14_3  -16
    T_14_3    TCapLB_14_3  48
    T_14_3    TCapUB_14_3  -48
    T_14_3    R914      -33
    T_14_3    R915      33
    T_14_3    R916      -33
    T_14_3    R917      33
    T_14_3    LayerUB_14_3  13
    T_14_3    LayerLB_14_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_14_3    ForceCap_14_3  1
    F_14_3    ForceBal_3  1
    F_14_3    ForceBal_14  -1
    P_14_3    PCapLB_14_3  1
    P_14_3    PCapUB_14_3  1
    P_14_3    R914      1
    P_14_3    R915      1
    P_14_3    R916      1
    P_14_3    R917      1
    Torque_14_3  TCapLB_14_3  1
    Torque_14_3  TCapUB_14_3  1
    Torque_14_3  TorqueBal_3  1
    Torque_14_3  TorqueBal_14  -1
    Torque_14_3  Bilinear_14_3  1
    MARKER    'MARKER'                 'INTORG'
    T_14_4    DAGSupMin_14  1
    T_14_4    DAGSupMax_14  1
    T_14_4    ForceCap_14_4  -3
    T_14_4    PCapLB_14_4  16
    T_14_4    PCapUB_14_4  -16
    T_14_4    TCapLB_14_4  48
    T_14_4    TCapUB_14_4  -48
    T_14_4    R925      -33
    T_14_4    R926      33
    T_14_4    R927      -33
    T_14_4    R928      33
    T_14_4    LayerUB_14_4  13
    T_14_4    LayerLB_14_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_14_4    ForceCap_14_4  1
    F_14_4    ForceBal_4  1
    F_14_4    ForceBal_14  -1
    P_14_4    PCapLB_14_4  1
    P_14_4    PCapUB_14_4  1
    P_14_4    R925      1
    P_14_4    R926      1
    P_14_4    R927      1
    P_14_4    R928      1
    Torque_14_4  TCapLB_14_4  1
    Torque_14_4  TCapUB_14_4  1
    Torque_14_4  TorqueBal_4  1
    Torque_14_4  TorqueBal_14  -1
    Torque_14_4  Bilinear_14_4  1
    MARKER    'MARKER'                 'INTORG'
    T_14_5    DAGSupMin_14  1
    T_14_5    DAGSupMax_14  1
    T_14_5    ForceCap_14_5  -3
    T_14_5    PCapLB_14_5  16
    T_14_5    PCapUB_14_5  -16
    T_14_5    TCapLB_14_5  48
    T_14_5    TCapUB_14_5  -48
    T_14_5    R936      -33
    T_14_5    R937      33
    T_14_5    R938      -33
    T_14_5    R939      33
    T_14_5    LayerUB_14_5  13
    T_14_5    LayerLB_14_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_14_5    ForceCap_14_5  1
    F_14_5    ForceBal_5  1
    F_14_5    ForceBal_14  -1
    P_14_5    PCapLB_14_5  1
    P_14_5    PCapUB_14_5  1
    P_14_5    R936      1
    P_14_5    R937      1
    P_14_5    R938      1
    P_14_5    R939      1
    Torque_14_5  TCapLB_14_5  1
    Torque_14_5  TCapUB_14_5  1
    Torque_14_5  TorqueBal_5  1
    Torque_14_5  TorqueBal_14  -1
    Torque_14_5  Bilinear_14_5  1
    MARKER    'MARKER'                 'INTORG'
    T_14_6    DAGSupMin_14  1
    T_14_6    DAGSupMax_14  1
    T_14_6    ForceCap_14_6  -3
    T_14_6    PCapLB_14_6  16
    T_14_6    PCapUB_14_6  -16
    T_14_6    TCapLB_14_6  48
    T_14_6    TCapUB_14_6  -48
    T_14_6    R947      -33
    T_14_6    R948      33
    T_14_6    R949      -33
    T_14_6    R950      33
    T_14_6    LayerUB_14_6  13
    T_14_6    LayerLB_14_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_14_6    ForceCap_14_6  1
    F_14_6    ForceBal_6  1
    F_14_6    ForceBal_14  -1
    P_14_6    PCapLB_14_6  1
    P_14_6    PCapUB_14_6  1
    P_14_6    R947      1
    P_14_6    R948      1
    P_14_6    R949      1
    P_14_6    R950      1
    Torque_14_6  TCapLB_14_6  1
    Torque_14_6  TCapUB_14_6  1
    Torque_14_6  TorqueBal_6  1
    Torque_14_6  TorqueBal_14  -1
    Torque_14_6  Bilinear_14_6  1
    MARKER    'MARKER'                 'INTORG'
    T_14_7    DAGSupMin_14  1
    T_14_7    DAGSupMax_14  1
    T_14_7    ForceCap_14_7  -3
    T_14_7    PCapLB_14_7  16
    T_14_7    PCapUB_14_7  -16
    T_14_7    TCapLB_14_7  48
    T_14_7    TCapUB_14_7  -48
    T_14_7    R958      -33
    T_14_7    R959      33
    T_14_7    R960      -33
    T_14_7    R961      33
    T_14_7    LayerUB_14_7  13
    T_14_7    LayerLB_14_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_14_7    ForceCap_14_7  1
    F_14_7    ForceBal_7  1
    F_14_7    ForceBal_14  -1
    P_14_7    PCapLB_14_7  1
    P_14_7    PCapUB_14_7  1
    P_14_7    R958      1
    P_14_7    R959      1
    P_14_7    R960      1
    P_14_7    R961      1
    Torque_14_7  TCapLB_14_7  1
    Torque_14_7  TCapUB_14_7  1
    Torque_14_7  TorqueBal_7  1
    Torque_14_7  TorqueBal_14  -1
    Torque_14_7  Bilinear_14_7  1
    MARKER    'MARKER'                 'INTORG'
    T_14_8    DAGSupMin_14  1
    T_14_8    DAGSupMax_14  1
    T_14_8    ForceCap_14_8  -3
    T_14_8    PCapLB_14_8  16
    T_14_8    PCapUB_14_8  -16
    T_14_8    TCapLB_14_8  48
    T_14_8    TCapUB_14_8  -48
    T_14_8    R969      -33
    T_14_8    R970      33
    T_14_8    R971      -33
    T_14_8    R972      33
    T_14_8    LayerUB_14_8  13
    T_14_8    LayerLB_14_8  -8
    MARKER    'MARKER'                 'INTEND'
    F_14_8    ForceCap_14_8  1
    F_14_8    ForceBal_8  1
    F_14_8    ForceBal_14  -1
    P_14_8    PCapLB_14_8  1
    P_14_8    PCapUB_14_8  1
    P_14_8    R969      1
    P_14_8    R970      1
    P_14_8    R971      1
    P_14_8    R972      1
    Torque_14_8  TCapLB_14_8  1
    Torque_14_8  TCapUB_14_8  1
    Torque_14_8  TorqueBal_8  1
    Torque_14_8  TorqueBal_14  -1
    Torque_14_8  Bilinear_14_8  1
    MARKER    'MARKER'                 'INTORG'
    T_14_9    DAGSupMin_14  1
    T_14_9    DAGSupMax_14  1
    T_14_9    ForceCap_14_9  -3
    T_14_9    PCapLB_14_9  16
    T_14_9    PCapUB_14_9  -16
    T_14_9    TCapLB_14_9  48
    T_14_9    TCapUB_14_9  -48
    T_14_9    R980      -33
    T_14_9    R981      33
    T_14_9    R982      -33
    T_14_9    R983      33
    T_14_9    LayerUB_14_9  13
    T_14_9    LayerLB_14_9  -9
    MARKER    'MARKER'                 'INTEND'
    F_14_9    ForceCap_14_9  1
    F_14_9    ForceBal_9  1
    F_14_9    ForceBal_14  -1
    P_14_9    PCapLB_14_9  1
    P_14_9    PCapUB_14_9  1
    P_14_9    R980      1
    P_14_9    R981      1
    P_14_9    R982      1
    P_14_9    R983      1
    Torque_14_9  TCapLB_14_9  1
    Torque_14_9  TCapUB_14_9  1
    Torque_14_9  TorqueBal_9  1
    Torque_14_9  TorqueBal_14  -1
    Torque_14_9  Bilinear_14_9  1
    MARKER    'MARKER'                 'INTORG'
    T_14_10   DAGSupMin_14  1
    T_14_10   DAGSupMax_14  1
    T_14_10   ForceCap_14_10  -3
    T_14_10   PCapLB_14_10  16
    T_14_10   PCapUB_14_10  -16
    T_14_10   TCapLB_14_10  48
    T_14_10   TCapUB_14_10  -48
    T_14_10   R991      -33
    T_14_10   R992      33
    T_14_10   R993      -33
    T_14_10   R994      33
    T_14_10   LayerUB_14_10  13
    T_14_10   LayerLB_14_10  -10
    T_14_10   NC_13_14_10_12  1
    MARKER    'MARKER'                 'INTEND'
    F_14_10   ForceCap_14_10  1
    F_14_10   ForceBal_10  1
    F_14_10   ForceBal_14  -1
    P_14_10   PCapLB_14_10  1
    P_14_10   PCapUB_14_10  1
    P_14_10   R991      1
    P_14_10   R992      1
    P_14_10   R993      1
    P_14_10   R994      1
    Torque_14_10  TCapLB_14_10  1
    Torque_14_10  TCapUB_14_10  1
    Torque_14_10  TorqueBal_10  1
    Torque_14_10  TorqueBal_14  -1
    Torque_14_10  Bilinear_14_10  1
    MARKER    'MARKER'                 'INTORG'
    T_14_11   DAGSupMin_14  1
    T_14_11   DAGSupMax_14  1
    T_14_11   ForceCap_14_11  -3
    T_14_11   PCapLB_14_11  16
    T_14_11   PCapUB_14_11  -16
    T_14_11   TCapLB_14_11  48
    T_14_11   TCapUB_14_11  -48
    T_14_11   R1002     -33
    T_14_11   R1003     33
    T_14_11   R1004     -33
    T_14_11   R1005     33
    T_14_11   LayerUB_14_11  13
    T_14_11   LayerLB_14_11  -11
    MARKER    'MARKER'                 'INTEND'
    F_14_11   ForceCap_14_11  1
    F_14_11   ForceBal_11  1
    F_14_11   ForceBal_14  -1
    P_14_11   PCapLB_14_11  1
    P_14_11   PCapUB_14_11  1
    P_14_11   R1002     1
    P_14_11   R1003     1
    P_14_11   R1004     1
    P_14_11   R1005     1
    Torque_14_11  TCapLB_14_11  1
    Torque_14_11  TCapUB_14_11  1
    Torque_14_11  TorqueBal_11  1
    Torque_14_11  TorqueBal_14  -1
    Torque_14_11  Bilinear_14_11  1
    MARKER    'MARKER'                 'INTORG'
    T_14_12   DAGSupMin_14  1
    T_14_12   DAGSupMax_14  1
    T_14_12   ForceCap_14_12  -3
    T_14_12   PCapLB_14_12  16
    T_14_12   PCapUB_14_12  -16
    T_14_12   TCapLB_14_12  48
    T_14_12   TCapUB_14_12  -48
    T_14_12   R1013     -33
    T_14_12   R1014     33
    T_14_12   R1015     -33
    T_14_12   R1016     33
    T_14_12   LayerUB_14_12  13
    T_14_12   LayerLB_14_12  -12
    T_14_12   NC_14_15_10_12  1
    MARKER    'MARKER'                 'INTEND'
    F_14_12   ForceCap_14_12  1
    F_14_12   ForceBal_12  1
    F_14_12   ForceBal_14  -1
    P_14_12   PCapLB_14_12  1
    P_14_12   PCapUB_14_12  1
    P_14_12   R1013     1
    P_14_12   R1014     1
    P_14_12   R1015     1
    P_14_12   R1016     1
    Torque_14_12  TCapLB_14_12  1
    Torque_14_12  TCapUB_14_12  1
    Torque_14_12  TorqueBal_12  1
    Torque_14_12  TorqueBal_14  -1
    Torque_14_12  Bilinear_14_12  1
    MARKER    'MARKER'                 'INTORG'
    T_14_13   DAGSupMin_14  1
    T_14_13   DAGSupMax_14  1
    T_14_13   ForceCap_14_13  -3
    T_14_13   PCapLB_14_13  16
    T_14_13   PCapUB_14_13  -16
    T_14_13   TCapLB_14_13  48
    T_14_13   TCapUB_14_13  -48
    T_14_13   R1024     -33
    T_14_13   R1025     33
    T_14_13   R1026     -33
    T_14_13   R1027     33
    T_14_13   LayerUB_14_13  13
    T_14_13   LayerLB_14_13  -13
    MARKER    'MARKER'                 'INTEND'
    F_14_13   ForceCap_14_13  1
    F_14_13   ForceBal_13  1
    F_14_13   ForceBal_14  -1
    P_14_13   PCapLB_14_13  1
    P_14_13   PCapUB_14_13  1
    P_14_13   R1024     1
    P_14_13   R1025     1
    P_14_13   R1026     1
    P_14_13   R1027     1
    Torque_14_13  TCapLB_14_13  1
    Torque_14_13  TCapUB_14_13  1
    Torque_14_13  TorqueBal_13  1
    Torque_14_13  TorqueBal_14  -1
    Torque_14_13  Bilinear_14_13  1
    MARKER    'MARKER'                 'INTORG'
    T_15_1    DAGSupMin_15  1
    T_15_1    DAGSupMax_15  1
    T_15_1    ForceCap_15_1  -2
    T_15_1    PCapLB_15_1  16
    T_15_1    PCapUB_15_1  -16
    T_15_1    TCapLB_15_1  32
    T_15_1    TCapUB_15_1  -32
    T_15_1    R1037     -33
    T_15_1    R1038     33
    T_15_1    R1039     -33
    T_15_1    R1040     33
    T_15_1    LayerUB_15_1  14
    T_15_1    LayerLB_15_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_15_1    ForceCap_15_1  1
    F_15_1    ForceBal_1  1
    F_15_1    ForceBal_15  -1
    P_15_1    PCapLB_15_1  1
    P_15_1    PCapUB_15_1  1
    P_15_1    R1037     1
    P_15_1    R1038     1
    P_15_1    R1039     1
    P_15_1    R1040     1
    Torque_15_1  TCapLB_15_1  1
    Torque_15_1  TCapUB_15_1  1
    Torque_15_1  TorqueBal_1  1
    Torque_15_1  TorqueBal_15  -1
    Torque_15_1  Bilinear_15_1  1
    MARKER    'MARKER'                 'INTORG'
    T_15_2    DAGSupMin_15  1
    T_15_2    DAGSupMax_15  1
    T_15_2    ForceCap_15_2  -2
    T_15_2    PCapLB_15_2  16
    T_15_2    PCapUB_15_2  -16
    T_15_2    TCapLB_15_2  32
    T_15_2    TCapUB_15_2  -32
    T_15_2    R1048     -33
    T_15_2    R1049     33
    T_15_2    R1050     -33
    T_15_2    R1051     33
    T_15_2    LayerUB_15_2  14
    T_15_2    LayerLB_15_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_15_2    ForceCap_15_2  1
    F_15_2    ForceBal_2  1
    F_15_2    ForceBal_15  -1
    P_15_2    PCapLB_15_2  1
    P_15_2    PCapUB_15_2  1
    P_15_2    R1048     1
    P_15_2    R1049     1
    P_15_2    R1050     1
    P_15_2    R1051     1
    Torque_15_2  TCapLB_15_2  1
    Torque_15_2  TCapUB_15_2  1
    Torque_15_2  TorqueBal_2  1
    Torque_15_2  TorqueBal_15  -1
    Torque_15_2  Bilinear_15_2  1
    MARKER    'MARKER'                 'INTORG'
    T_15_3    DAGSupMin_15  1
    T_15_3    DAGSupMax_15  1
    T_15_3    ForceCap_15_3  -2
    T_15_3    PCapLB_15_3  16
    T_15_3    PCapUB_15_3  -16
    T_15_3    TCapLB_15_3  32
    T_15_3    TCapUB_15_3  -32
    T_15_3    R1059     -33
    T_15_3    R1060     33
    T_15_3    R1061     -33
    T_15_3    R1062     33
    T_15_3    LayerUB_15_3  14
    T_15_3    LayerLB_15_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_15_3    ForceCap_15_3  1
    F_15_3    ForceBal_3  1
    F_15_3    ForceBal_15  -1
    P_15_3    PCapLB_15_3  1
    P_15_3    PCapUB_15_3  1
    P_15_3    R1059     1
    P_15_3    R1060     1
    P_15_3    R1061     1
    P_15_3    R1062     1
    Torque_15_3  TCapLB_15_3  1
    Torque_15_3  TCapUB_15_3  1
    Torque_15_3  TorqueBal_3  1
    Torque_15_3  TorqueBal_15  -1
    Torque_15_3  Bilinear_15_3  1
    MARKER    'MARKER'                 'INTORG'
    T_15_4    DAGSupMin_15  1
    T_15_4    DAGSupMax_15  1
    T_15_4    ForceCap_15_4  -2
    T_15_4    PCapLB_15_4  16
    T_15_4    PCapUB_15_4  -16
    T_15_4    TCapLB_15_4  32
    T_15_4    TCapUB_15_4  -32
    T_15_4    R1070     -33
    T_15_4    R1071     33
    T_15_4    R1072     -33
    T_15_4    R1073     33
    T_15_4    LayerUB_15_4  14
    T_15_4    LayerLB_15_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_15_4    ForceCap_15_4  1
    F_15_4    ForceBal_4  1
    F_15_4    ForceBal_15  -1
    P_15_4    PCapLB_15_4  1
    P_15_4    PCapUB_15_4  1
    P_15_4    R1070     1
    P_15_4    R1071     1
    P_15_4    R1072     1
    P_15_4    R1073     1
    Torque_15_4  TCapLB_15_4  1
    Torque_15_4  TCapUB_15_4  1
    Torque_15_4  TorqueBal_4  1
    Torque_15_4  TorqueBal_15  -1
    Torque_15_4  Bilinear_15_4  1
    MARKER    'MARKER'                 'INTORG'
    T_15_5    DAGSupMin_15  1
    T_15_5    DAGSupMax_15  1
    T_15_5    ForceCap_15_5  -2
    T_15_5    PCapLB_15_5  16
    T_15_5    PCapUB_15_5  -16
    T_15_5    TCapLB_15_5  32
    T_15_5    TCapUB_15_5  -32
    T_15_5    R1081     -33
    T_15_5    R1082     33
    T_15_5    R1083     -33
    T_15_5    R1084     33
    T_15_5    LayerUB_15_5  14
    T_15_5    LayerLB_15_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_15_5    ForceCap_15_5  1
    F_15_5    ForceBal_5  1
    F_15_5    ForceBal_15  -1
    P_15_5    PCapLB_15_5  1
    P_15_5    PCapUB_15_5  1
    P_15_5    R1081     1
    P_15_5    R1082     1
    P_15_5    R1083     1
    P_15_5    R1084     1
    Torque_15_5  TCapLB_15_5  1
    Torque_15_5  TCapUB_15_5  1
    Torque_15_5  TorqueBal_5  1
    Torque_15_5  TorqueBal_15  -1
    Torque_15_5  Bilinear_15_5  1
    MARKER    'MARKER'                 'INTORG'
    T_15_6    DAGSupMin_15  1
    T_15_6    DAGSupMax_15  1
    T_15_6    ForceCap_15_6  -2
    T_15_6    PCapLB_15_6  16
    T_15_6    PCapUB_15_6  -16
    T_15_6    TCapLB_15_6  32
    T_15_6    TCapUB_15_6  -32
    T_15_6    R1092     -33
    T_15_6    R1093     33
    T_15_6    R1094     -33
    T_15_6    R1095     33
    T_15_6    LayerUB_15_6  14
    T_15_6    LayerLB_15_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_15_6    ForceCap_15_6  1
    F_15_6    ForceBal_6  1
    F_15_6    ForceBal_15  -1
    P_15_6    PCapLB_15_6  1
    P_15_6    PCapUB_15_6  1
    P_15_6    R1092     1
    P_15_6    R1093     1
    P_15_6    R1094     1
    P_15_6    R1095     1
    Torque_15_6  TCapLB_15_6  1
    Torque_15_6  TCapUB_15_6  1
    Torque_15_6  TorqueBal_6  1
    Torque_15_6  TorqueBal_15  -1
    Torque_15_6  Bilinear_15_6  1
    MARKER    'MARKER'                 'INTORG'
    T_15_7    DAGSupMin_15  1
    T_15_7    DAGSupMax_15  1
    T_15_7    ForceCap_15_7  -2
    T_15_7    PCapLB_15_7  16
    T_15_7    PCapUB_15_7  -16
    T_15_7    TCapLB_15_7  32
    T_15_7    TCapUB_15_7  -32
    T_15_7    R1103     -33
    T_15_7    R1104     33
    T_15_7    R1105     -33
    T_15_7    R1106     33
    T_15_7    LayerUB_15_7  14
    T_15_7    LayerLB_15_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_15_7    ForceCap_15_7  1
    F_15_7    ForceBal_7  1
    F_15_7    ForceBal_15  -1
    P_15_7    PCapLB_15_7  1
    P_15_7    PCapUB_15_7  1
    P_15_7    R1103     1
    P_15_7    R1104     1
    P_15_7    R1105     1
    P_15_7    R1106     1
    Torque_15_7  TCapLB_15_7  1
    Torque_15_7  TCapUB_15_7  1
    Torque_15_7  TorqueBal_7  1
    Torque_15_7  TorqueBal_15  -1
    Torque_15_7  Bilinear_15_7  1
    MARKER    'MARKER'                 'INTORG'
    T_15_8    DAGSupMin_15  1
    T_15_8    DAGSupMax_15  1
    T_15_8    ForceCap_15_8  -2
    T_15_8    PCapLB_15_8  16
    T_15_8    PCapUB_15_8  -16
    T_15_8    TCapLB_15_8  32
    T_15_8    TCapUB_15_8  -32
    T_15_8    R1114     -33
    T_15_8    R1115     33
    T_15_8    R1116     -33
    T_15_8    R1117     33
    T_15_8    LayerUB_15_8  14
    T_15_8    LayerLB_15_8  -8
    MARKER    'MARKER'                 'INTEND'
    F_15_8    ForceCap_15_8  1
    F_15_8    ForceBal_8  1
    F_15_8    ForceBal_15  -1
    P_15_8    PCapLB_15_8  1
    P_15_8    PCapUB_15_8  1
    P_15_8    R1114     1
    P_15_8    R1115     1
    P_15_8    R1116     1
    P_15_8    R1117     1
    Torque_15_8  TCapLB_15_8  1
    Torque_15_8  TCapUB_15_8  1
    Torque_15_8  TorqueBal_8  1
    Torque_15_8  TorqueBal_15  -1
    Torque_15_8  Bilinear_15_8  1
    MARKER    'MARKER'                 'INTORG'
    T_15_9    DAGSupMin_15  1
    T_15_9    DAGSupMax_15  1
    T_15_9    ForceCap_15_9  -2
    T_15_9    PCapLB_15_9  16
    T_15_9    PCapUB_15_9  -16
    T_15_9    TCapLB_15_9  32
    T_15_9    TCapUB_15_9  -32
    T_15_9    R1125     -33
    T_15_9    R1126     33
    T_15_9    R1127     -33
    T_15_9    R1128     33
    T_15_9    LayerUB_15_9  14
    T_15_9    LayerLB_15_9  -9
    MARKER    'MARKER'                 'INTEND'
    F_15_9    ForceCap_15_9  1
    F_15_9    ForceBal_9  1
    F_15_9    ForceBal_15  -1
    P_15_9    PCapLB_15_9  1
    P_15_9    PCapUB_15_9  1
    P_15_9    R1125     1
    P_15_9    R1126     1
    P_15_9    R1127     1
    P_15_9    R1128     1
    Torque_15_9  TCapLB_15_9  1
    Torque_15_9  TCapUB_15_9  1
    Torque_15_9  TorqueBal_9  1
    Torque_15_9  TorqueBal_15  -1
    Torque_15_9  Bilinear_15_9  1
    MARKER    'MARKER'                 'INTORG'
    T_15_10   DAGSupMin_15  1
    T_15_10   DAGSupMax_15  1
    T_15_10   ForceCap_15_10  -2
    T_15_10   PCapLB_15_10  16
    T_15_10   PCapUB_15_10  -16
    T_15_10   TCapLB_15_10  32
    T_15_10   TCapUB_15_10  -32
    T_15_10   R1136     -33
    T_15_10   R1137     33
    T_15_10   R1138     -33
    T_15_10   R1139     33
    T_15_10   LayerUB_15_10  14
    T_15_10   LayerLB_15_10  -10
    T_15_10   NC_13_15_10_11  1
    T_15_10   NC_13_15_10_12  1
    T_15_10   NC_14_15_10_12  1
    MARKER    'MARKER'                 'INTEND'
    F_15_10   ForceCap_15_10  1
    F_15_10   ForceBal_10  1
    F_15_10   ForceBal_15  -1
    P_15_10   PCapLB_15_10  1
    P_15_10   PCapUB_15_10  1
    P_15_10   R1136     1
    P_15_10   R1137     1
    P_15_10   R1138     1
    P_15_10   R1139     1
    Torque_15_10  TCapLB_15_10  1
    Torque_15_10  TCapUB_15_10  1
    Torque_15_10  TorqueBal_10  1
    Torque_15_10  TorqueBal_15  -1
    Torque_15_10  Bilinear_15_10  1
    MARKER    'MARKER'                 'INTORG'
    T_15_11   DAGSupMin_15  1
    T_15_11   DAGSupMax_15  1
    T_15_11   ForceCap_15_11  -2
    T_15_11   PCapLB_15_11  16
    T_15_11   PCapUB_15_11  -16
    T_15_11   TCapLB_15_11  32
    T_15_11   TCapUB_15_11  -32
    T_15_11   R1147     -33
    T_15_11   R1148     33
    T_15_11   R1149     -33
    T_15_11   R1150     33
    T_15_11   LayerUB_15_11  14
    T_15_11   LayerLB_15_11  -11
    T_15_11   NC_13_15_11_12  1
    MARKER    'MARKER'                 'INTEND'
    F_15_11   ForceCap_15_11  1
    F_15_11   ForceBal_11  1
    F_15_11   ForceBal_15  -1
    P_15_11   PCapLB_15_11  1
    P_15_11   PCapUB_15_11  1
    P_15_11   R1147     1
    P_15_11   R1148     1
    P_15_11   R1149     1
    P_15_11   R1150     1
    Torque_15_11  TCapLB_15_11  1
    Torque_15_11  TCapUB_15_11  1
    Torque_15_11  TorqueBal_11  1
    Torque_15_11  TorqueBal_15  -1
    Torque_15_11  Bilinear_15_11  1
    MARKER    'MARKER'                 'INTORG'
    T_15_12   DAGSupMin_15  1
    T_15_12   DAGSupMax_15  1
    T_15_12   ForceCap_15_12  -2
    T_15_12   PCapLB_15_12  16
    T_15_12   PCapUB_15_12  -16
    T_15_12   TCapLB_15_12  32
    T_15_12   TCapUB_15_12  -32
    T_15_12   R1158     -33
    T_15_12   R1159     33
    T_15_12   R1160     -33
    T_15_12   R1161     33
    T_15_12   LayerUB_15_12  14
    T_15_12   LayerLB_15_12  -12
    MARKER    'MARKER'                 'INTEND'
    F_15_12   ForceCap_15_12  1
    F_15_12   ForceBal_12  1
    F_15_12   ForceBal_15  -1
    P_15_12   PCapLB_15_12  1
    P_15_12   PCapUB_15_12  1
    P_15_12   R1158     1
    P_15_12   R1159     1
    P_15_12   R1160     1
    P_15_12   R1161     1
    Torque_15_12  TCapLB_15_12  1
    Torque_15_12  TCapUB_15_12  1
    Torque_15_12  TorqueBal_12  1
    Torque_15_12  TorqueBal_15  -1
    Torque_15_12  Bilinear_15_12  1
    MARKER    'MARKER'                 'INTORG'
    T_15_13   DAGSupMin_15  1
    T_15_13   DAGSupMax_15  1
    T_15_13   ForceCap_15_13  -2
    T_15_13   PCapLB_15_13  16
    T_15_13   PCapUB_15_13  -16
    T_15_13   TCapLB_15_13  32
    T_15_13   TCapUB_15_13  -32
    T_15_13   R1169     -33
    T_15_13   R1170     33
    T_15_13   R1171     -33
    T_15_13   R1172     33
    T_15_13   LayerUB_15_13  14
    T_15_13   LayerLB_15_13  -13
    MARKER    'MARKER'                 'INTEND'
    F_15_13   ForceCap_15_13  1
    F_15_13   ForceBal_13  1
    F_15_13   ForceBal_15  -1
    P_15_13   PCapLB_15_13  1
    P_15_13   PCapUB_15_13  1
    P_15_13   R1169     1
    P_15_13   R1170     1
    P_15_13   R1171     1
    P_15_13   R1172     1
    Torque_15_13  TCapLB_15_13  1
    Torque_15_13  TCapUB_15_13  1
    Torque_15_13  TorqueBal_13  1
    Torque_15_13  TorqueBal_15  -1
    Torque_15_13  Bilinear_15_13  1
    MARKER    'MARKER'                 'INTORG'
    T_15_14   DAGSupMin_15  1
    T_15_14   DAGSupMax_15  1
    T_15_14   ForceCap_15_14  -2
    T_15_14   PCapLB_15_14  16
    T_15_14   PCapUB_15_14  -16
    T_15_14   TCapLB_15_14  32
    T_15_14   TCapUB_15_14  -32
    T_15_14   R1180     -33
    T_15_14   R1181     33
    T_15_14   R1182     -33
    T_15_14   R1183     33
    T_15_14   LayerUB_15_14  14
    T_15_14   LayerLB_15_14  -14
    MARKER    'MARKER'                 'INTEND'
    F_15_14   ForceCap_15_14  1
    F_15_14   ForceBal_14  1
    F_15_14   ForceBal_15  -1
    P_15_14   PCapLB_15_14  1
    P_15_14   PCapUB_15_14  1
    P_15_14   R1180     1
    P_15_14   R1181     1
    P_15_14   R1182     1
    P_15_14   R1183     1
    Torque_15_14  TCapLB_15_14  1
    Torque_15_14  TCapUB_15_14  1
    Torque_15_14  TorqueBal_14  1
    Torque_15_14  TorqueBal_15  -1
    Torque_15_14  Bilinear_15_14  1
    MARKER    'MARKER'                 'INTORG'
    T_16_1    DAGSupMin_16  1
    T_16_1    DAGSupMax_16  1
    T_16_1    ForceCap_16_1  -1
    T_16_1    PCapLB_16_1  16
    T_16_1    PCapUB_16_1  -16
    T_16_1    TCapLB_16_1  16
    T_16_1    TCapUB_16_1  -16
    T_16_1    R1193     -33
    T_16_1    R1194     33
    T_16_1    R1195     -33
    T_16_1    R1196     33
    T_16_1    LayerUB_16_1  15
    T_16_1    LayerLB_16_1  -1
    MARKER    'MARKER'                 'INTEND'
    F_16_1    ForceCap_16_1  1
    F_16_1    ForceBal_1  1
    F_16_1    ForceBal_16  -1
    P_16_1    PCapLB_16_1  1
    P_16_1    PCapUB_16_1  1
    P_16_1    R1193     1
    P_16_1    R1194     1
    P_16_1    R1195     1
    P_16_1    R1196     1
    Torque_16_1  TCapLB_16_1  1
    Torque_16_1  TCapUB_16_1  1
    Torque_16_1  TorqueBal_1  1
    Torque_16_1  TorqueBal_16  -1
    Torque_16_1  Bilinear_16_1  1
    MARKER    'MARKER'                 'INTORG'
    T_16_2    DAGSupMin_16  1
    T_16_2    DAGSupMax_16  1
    T_16_2    ForceCap_16_2  -1
    T_16_2    PCapLB_16_2  16
    T_16_2    PCapUB_16_2  -16
    T_16_2    TCapLB_16_2  16
    T_16_2    TCapUB_16_2  -16
    T_16_2    R1204     -33
    T_16_2    R1205     33
    T_16_2    R1206     -33
    T_16_2    R1207     33
    T_16_2    LayerUB_16_2  15
    T_16_2    LayerLB_16_2  -2
    MARKER    'MARKER'                 'INTEND'
    F_16_2    ForceCap_16_2  1
    F_16_2    ForceBal_2  1
    F_16_2    ForceBal_16  -1
    P_16_2    PCapLB_16_2  1
    P_16_2    PCapUB_16_2  1
    P_16_2    R1204     1
    P_16_2    R1205     1
    P_16_2    R1206     1
    P_16_2    R1207     1
    Torque_16_2  TCapLB_16_2  1
    Torque_16_2  TCapUB_16_2  1
    Torque_16_2  TorqueBal_2  1
    Torque_16_2  TorqueBal_16  -1
    Torque_16_2  Bilinear_16_2  1
    MARKER    'MARKER'                 'INTORG'
    T_16_3    DAGSupMin_16  1
    T_16_3    DAGSupMax_16  1
    T_16_3    ForceCap_16_3  -1
    T_16_3    PCapLB_16_3  16
    T_16_3    PCapUB_16_3  -16
    T_16_3    TCapLB_16_3  16
    T_16_3    TCapUB_16_3  -16
    T_16_3    R1215     -33
    T_16_3    R1216     33
    T_16_3    R1217     -33
    T_16_3    R1218     33
    T_16_3    LayerUB_16_3  15
    T_16_3    LayerLB_16_3  -3
    MARKER    'MARKER'                 'INTEND'
    F_16_3    ForceCap_16_3  1
    F_16_3    ForceBal_3  1
    F_16_3    ForceBal_16  -1
    P_16_3    PCapLB_16_3  1
    P_16_3    PCapUB_16_3  1
    P_16_3    R1215     1
    P_16_3    R1216     1
    P_16_3    R1217     1
    P_16_3    R1218     1
    Torque_16_3  TCapLB_16_3  1
    Torque_16_3  TCapUB_16_3  1
    Torque_16_3  TorqueBal_3  1
    Torque_16_3  TorqueBal_16  -1
    Torque_16_3  Bilinear_16_3  1
    MARKER    'MARKER'                 'INTORG'
    T_16_4    DAGSupMin_16  1
    T_16_4    DAGSupMax_16  1
    T_16_4    ForceCap_16_4  -1
    T_16_4    PCapLB_16_4  16
    T_16_4    PCapUB_16_4  -16
    T_16_4    TCapLB_16_4  16
    T_16_4    TCapUB_16_4  -16
    T_16_4    R1226     -33
    T_16_4    R1227     33
    T_16_4    R1228     -33
    T_16_4    R1229     33
    T_16_4    LayerUB_16_4  15
    T_16_4    LayerLB_16_4  -4
    MARKER    'MARKER'                 'INTEND'
    F_16_4    ForceCap_16_4  1
    F_16_4    ForceBal_4  1
    F_16_4    ForceBal_16  -1
    P_16_4    PCapLB_16_4  1
    P_16_4    PCapUB_16_4  1
    P_16_4    R1226     1
    P_16_4    R1227     1
    P_16_4    R1228     1
    P_16_4    R1229     1
    Torque_16_4  TCapLB_16_4  1
    Torque_16_4  TCapUB_16_4  1
    Torque_16_4  TorqueBal_4  1
    Torque_16_4  TorqueBal_16  -1
    Torque_16_4  Bilinear_16_4  1
    MARKER    'MARKER'                 'INTORG'
    T_16_5    DAGSupMin_16  1
    T_16_5    DAGSupMax_16  1
    T_16_5    ForceCap_16_5  -1
    T_16_5    PCapLB_16_5  16
    T_16_5    PCapUB_16_5  -16
    T_16_5    TCapLB_16_5  16
    T_16_5    TCapUB_16_5  -16
    T_16_5    R1237     -33
    T_16_5    R1238     33
    T_16_5    R1239     -33
    T_16_5    R1240     33
    T_16_5    LayerUB_16_5  15
    T_16_5    LayerLB_16_5  -5
    MARKER    'MARKER'                 'INTEND'
    F_16_5    ForceCap_16_5  1
    F_16_5    ForceBal_5  1
    F_16_5    ForceBal_16  -1
    P_16_5    PCapLB_16_5  1
    P_16_5    PCapUB_16_5  1
    P_16_5    R1237     1
    P_16_5    R1238     1
    P_16_5    R1239     1
    P_16_5    R1240     1
    Torque_16_5  TCapLB_16_5  1
    Torque_16_5  TCapUB_16_5  1
    Torque_16_5  TorqueBal_5  1
    Torque_16_5  TorqueBal_16  -1
    Torque_16_5  Bilinear_16_5  1
    MARKER    'MARKER'                 'INTORG'
    T_16_6    DAGSupMin_16  1
    T_16_6    DAGSupMax_16  1
    T_16_6    ForceCap_16_6  -1
    T_16_6    PCapLB_16_6  16
    T_16_6    PCapUB_16_6  -16
    T_16_6    TCapLB_16_6  16
    T_16_6    TCapUB_16_6  -16
    T_16_6    R1248     -33
    T_16_6    R1249     33
    T_16_6    R1250     -33
    T_16_6    R1251     33
    T_16_6    LayerUB_16_6  15
    T_16_6    LayerLB_16_6  -6
    MARKER    'MARKER'                 'INTEND'
    F_16_6    ForceCap_16_6  1
    F_16_6    ForceBal_6  1
    F_16_6    ForceBal_16  -1
    P_16_6    PCapLB_16_6  1
    P_16_6    PCapUB_16_6  1
    P_16_6    R1248     1
    P_16_6    R1249     1
    P_16_6    R1250     1
    P_16_6    R1251     1
    Torque_16_6  TCapLB_16_6  1
    Torque_16_6  TCapUB_16_6  1
    Torque_16_6  TorqueBal_6  1
    Torque_16_6  TorqueBal_16  -1
    Torque_16_6  Bilinear_16_6  1
    MARKER    'MARKER'                 'INTORG'
    T_16_7    DAGSupMin_16  1
    T_16_7    DAGSupMax_16  1
    T_16_7    ForceCap_16_7  -1
    T_16_7    PCapLB_16_7  16
    T_16_7    PCapUB_16_7  -16
    T_16_7    TCapLB_16_7  16
    T_16_7    TCapUB_16_7  -16
    T_16_7    R1259     -33
    T_16_7    R1260     33
    T_16_7    R1261     -33
    T_16_7    R1262     33
    T_16_7    LayerUB_16_7  15
    T_16_7    LayerLB_16_7  -7
    MARKER    'MARKER'                 'INTEND'
    F_16_7    ForceCap_16_7  1
    F_16_7    ForceBal_7  1
    F_16_7    ForceBal_16  -1
    P_16_7    PCapLB_16_7  1
    P_16_7    PCapUB_16_7  1
    P_16_7    R1259     1
    P_16_7    R1260     1
    P_16_7    R1261     1
    P_16_7    R1262     1
    Torque_16_7  TCapLB_16_7  1
    Torque_16_7  TCapUB_16_7  1
    Torque_16_7  TorqueBal_7  1
    Torque_16_7  TorqueBal_16  -1
    Torque_16_7  Bilinear_16_7  1
    MARKER    'MARKER'                 'INTORG'
    T_16_8    DAGSupMin_16  1
    T_16_8    DAGSupMax_16  1
    T_16_8    ForceCap_16_8  -1
    T_16_8    PCapLB_16_8  16
    T_16_8    PCapUB_16_8  -16
    T_16_8    TCapLB_16_8  16
    T_16_8    TCapUB_16_8  -16
    T_16_8    R1270     -33
    T_16_8    R1271     33
    T_16_8    R1272     -33
    T_16_8    R1273     33
    T_16_8    LayerUB_16_8  15
    T_16_8    LayerLB_16_8  -8
    MARKER    'MARKER'                 'INTEND'
    F_16_8    ForceCap_16_8  1
    F_16_8    ForceBal_8  1
    F_16_8    ForceBal_16  -1
    P_16_8    PCapLB_16_8  1
    P_16_8    PCapUB_16_8  1
    P_16_8    R1270     1
    P_16_8    R1271     1
    P_16_8    R1272     1
    P_16_8    R1273     1
    Torque_16_8  TCapLB_16_8  1
    Torque_16_8  TCapUB_16_8  1
    Torque_16_8  TorqueBal_8  1
    Torque_16_8  TorqueBal_16  -1
    Torque_16_8  Bilinear_16_8  1
    MARKER    'MARKER'                 'INTORG'
    T_16_9    DAGSupMin_16  1
    T_16_9    DAGSupMax_16  1
    T_16_9    ForceCap_16_9  -1
    T_16_9    PCapLB_16_9  16
    T_16_9    PCapUB_16_9  -16
    T_16_9    TCapLB_16_9  16
    T_16_9    TCapUB_16_9  -16
    T_16_9    R1281     -33
    T_16_9    R1282     33
    T_16_9    R1283     -33
    T_16_9    R1284     33
    T_16_9    LayerUB_16_9  15
    T_16_9    LayerLB_16_9  -9
    MARKER    'MARKER'                 'INTEND'
    F_16_9    ForceCap_16_9  1
    F_16_9    ForceBal_9  1
    F_16_9    ForceBal_16  -1
    P_16_9    PCapLB_16_9  1
    P_16_9    PCapUB_16_9  1
    P_16_9    R1281     1
    P_16_9    R1282     1
    P_16_9    R1283     1
    P_16_9    R1284     1
    Torque_16_9  TCapLB_16_9  1
    Torque_16_9  TCapUB_16_9  1
    Torque_16_9  TorqueBal_9  1
    Torque_16_9  TorqueBal_16  -1
    Torque_16_9  Bilinear_16_9  1
    MARKER    'MARKER'                 'INTORG'
    T_16_10   DAGSupMin_16  1
    T_16_10   DAGSupMax_16  1
    T_16_10   ForceCap_16_10  -1
    T_16_10   PCapLB_16_10  16
    T_16_10   PCapUB_16_10  -16
    T_16_10   TCapLB_16_10  16
    T_16_10   TCapUB_16_10  -16
    T_16_10   R1292     -33
    T_16_10   R1293     33
    T_16_10   R1294     -33
    T_16_10   R1295     33
    T_16_10   LayerUB_16_10  15
    T_16_10   LayerLB_16_10  -10
    MARKER    'MARKER'                 'INTEND'
    F_16_10   ForceCap_16_10  1
    F_16_10   ForceBal_10  1
    F_16_10   ForceBal_16  -1
    P_16_10   PCapLB_16_10  1
    P_16_10   PCapUB_16_10  1
    P_16_10   R1292     1
    P_16_10   R1293     1
    P_16_10   R1294     1
    P_16_10   R1295     1
    Torque_16_10  TCapLB_16_10  1
    Torque_16_10  TCapUB_16_10  1
    Torque_16_10  TorqueBal_10  1
    Torque_16_10  TorqueBal_16  -1
    Torque_16_10  Bilinear_16_10  1
    MARKER    'MARKER'                 'INTORG'
    T_16_11   DAGSupMin_16  1
    T_16_11   DAGSupMax_16  1
    T_16_11   ForceCap_16_11  -1
    T_16_11   PCapLB_16_11  16
    T_16_11   PCapUB_16_11  -16
    T_16_11   TCapLB_16_11  16
    T_16_11   TCapUB_16_11  -16
    T_16_11   R1303     -33
    T_16_11   R1304     33
    T_16_11   R1305     -33
    T_16_11   R1306     33
    T_16_11   LayerUB_16_11  15
    T_16_11   LayerLB_16_11  -11
    MARKER    'MARKER'                 'INTEND'
    F_16_11   ForceCap_16_11  1
    F_16_11   ForceBal_11  1
    F_16_11   ForceBal_16  -1
    P_16_11   PCapLB_16_11  1
    P_16_11   PCapUB_16_11  1
    P_16_11   R1303     1
    P_16_11   R1304     1
    P_16_11   R1305     1
    P_16_11   R1306     1
    Torque_16_11  TCapLB_16_11  1
    Torque_16_11  TCapUB_16_11  1
    Torque_16_11  TorqueBal_11  1
    Torque_16_11  TorqueBal_16  -1
    Torque_16_11  Bilinear_16_11  1
    MARKER    'MARKER'                 'INTORG'
    T_16_12   DAGSupMin_16  1
    T_16_12   DAGSupMax_16  1
    T_16_12   ForceCap_16_12  -1
    T_16_12   PCapLB_16_12  16
    T_16_12   PCapUB_16_12  -16
    T_16_12   TCapLB_16_12  16
    T_16_12   TCapUB_16_12  -16
    T_16_12   R1314     -33
    T_16_12   R1315     33
    T_16_12   R1316     -33
    T_16_12   R1317     33
    T_16_12   LayerUB_16_12  15
    T_16_12   LayerLB_16_12  -12
    MARKER    'MARKER'                 'INTEND'
    F_16_12   ForceCap_16_12  1
    F_16_12   ForceBal_12  1
    F_16_12   ForceBal_16  -1
    P_16_12   PCapLB_16_12  1
    P_16_12   PCapUB_16_12  1
    P_16_12   R1314     1
    P_16_12   R1315     1
    P_16_12   R1316     1
    P_16_12   R1317     1
    Torque_16_12  TCapLB_16_12  1
    Torque_16_12  TCapUB_16_12  1
    Torque_16_12  TorqueBal_12  1
    Torque_16_12  TorqueBal_16  -1
    Torque_16_12  Bilinear_16_12  1
    MARKER    'MARKER'                 'INTORG'
    T_16_13   DAGSupMin_16  1
    T_16_13   DAGSupMax_16  1
    T_16_13   ForceCap_16_13  -1
    T_16_13   PCapLB_16_13  16
    T_16_13   PCapUB_16_13  -16
    T_16_13   TCapLB_16_13  16
    T_16_13   TCapUB_16_13  -16
    T_16_13   R1325     -33
    T_16_13   R1326     33
    T_16_13   R1327     -33
    T_16_13   R1328     33
    T_16_13   LayerUB_16_13  15
    T_16_13   LayerLB_16_13  -13
    MARKER    'MARKER'                 'INTEND'
    F_16_13   ForceCap_16_13  1
    F_16_13   ForceBal_13  1
    F_16_13   ForceBal_16  -1
    P_16_13   PCapLB_16_13  1
    P_16_13   PCapUB_16_13  1
    P_16_13   R1325     1
    P_16_13   R1326     1
    P_16_13   R1327     1
    P_16_13   R1328     1
    Torque_16_13  TCapLB_16_13  1
    Torque_16_13  TCapUB_16_13  1
    Torque_16_13  TorqueBal_13  1
    Torque_16_13  TorqueBal_16  -1
    Torque_16_13  Bilinear_16_13  1
    MARKER    'MARKER'                 'INTORG'
    T_16_14   DAGSupMin_16  1
    T_16_14   DAGSupMax_16  1
    T_16_14   ForceCap_16_14  -1
    T_16_14   PCapLB_16_14  16
    T_16_14   PCapUB_16_14  -16
    T_16_14   TCapLB_16_14  16
    T_16_14   TCapUB_16_14  -16
    T_16_14   R1336     -33
    T_16_14   R1337     33
    T_16_14   R1338     -33
    T_16_14   R1339     33
    T_16_14   LayerUB_16_14  15
    T_16_14   LayerLB_16_14  -14
    T_16_14   SP_8      -5.7956453692796064e+00
    MARKER    'MARKER'                 'INTEND'
    F_16_14   ForceCap_16_14  1
    F_16_14   ForceBal_14  1
    F_16_14   ForceBal_16  -1
    P_16_14   PCapLB_16_14  1
    P_16_14   PCapUB_16_14  1
    P_16_14   R1336     1
    P_16_14   R1337     1
    P_16_14   R1338     1
    P_16_14   R1339     1
    Torque_16_14  TCapLB_16_14  1
    Torque_16_14  TCapUB_16_14  1
    Torque_16_14  TorqueBal_14  1
    Torque_16_14  TorqueBal_16  -1
    Torque_16_14  Bilinear_16_14  1
    MARKER    'MARKER'                 'INTORG'
    T_16_15   DAGSupMin_16  1
    T_16_15   DAGSupMax_16  1
    T_16_15   ForceCap_16_15  -1
    T_16_15   PCapLB_16_15  16
    T_16_15   PCapUB_16_15  -16
    T_16_15   TCapLB_16_15  16
    T_16_15   TCapUB_16_15  -16
    T_16_15   R1347     -33
    T_16_15   R1348     33
    T_16_15   R1349     -33
    T_16_15   R1350     33
    T_16_15   LayerUB_16_15  15
    T_16_15   LayerLB_16_15  -15
    T_16_15   SP_8      -5.7956453692796064e+00
    MARKER    'MARKER'                 'INTEND'
    F_16_15   ForceCap_16_15  1
    F_16_15   ForceBal_15  1
    F_16_15   ForceBal_16  -1
    P_16_15   PCapLB_16_15  1
    P_16_15   PCapUB_16_15  1
    P_16_15   R1347     1
    P_16_15   R1348     1
    P_16_15   R1349     1
    P_16_15   R1350     1
    Torque_16_15  TCapLB_16_15  1
    Torque_16_15  TCapUB_16_15  1
    Torque_16_15  TorqueBal_15  1
    Torque_16_15  TorqueBal_16  -1
    Torque_16_15  Bilinear_16_15  1
    MARKER    'MARKER'                 'INTORG'
    LayerJump_1  R1354     -1
    LayerJump_1  R1355     -1
    LayerJump_1  NonOverlap_1  33
    LayerJump_2  R1358     -1
    LayerJump_2  R1359     -2
    LayerJump_2  NonOverlap_2  33
    LayerJump_2  S2_Lmin_3  -1
    LayerJump_2  S2_Lmin_5  -1
    LayerJump_2  S2_Lmin_6  -1
    LayerJump_2  S2_Lmin_7  -1
    LayerJump_2  S2_Lmin_9  -1
    LayerJump_2  S2_Lmin_10  -1
    LayerJump_2  S2_Lmin_11  -1
    LayerJump_2  S2_Lmin_12  -1
    LayerJump_2  S2_Lmin_13  -1
    LayerJump_2  S2_Lmin_15  -1
    LayerJump_2  S2_Lmin_16  -1
    LayerJump_2  S2_T31    1
    LayerJump_2  S2_T32    -1
    LayerJump_2  S2_F21lo  -14
    LayerJump_2  S2_F21hi  -1
    LayerJump_2  S2_F31lo  1
    LayerJump_2  S2_F31hi  14
    LayerJump_2  S2_sign2  1
    LayerJump_2  S2_sign3  -2
    LayerJump_3  R1362     -1
    LayerJump_3  R1363     -3
    LayerJump_3  NonOverlap_3  33
    LayerJump_4  R1366     -1
    LayerJump_4  R1367     -4
    LayerJump_4  NonOverlap_4  33
    LayerJump_5  R1370     -1
    LayerJump_5  R1371     -5
    LayerJump_5  NonOverlap_5  33
    LayerJump_6  R1374     -1
    LayerJump_6  R1375     -6
    LayerJump_6  NonOverlap_6  33
    LayerJump_7  R1378     -1
    LayerJump_7  R1379     -7
    LayerJump_7  NonOverlap_7  33
    LayerJump_8  R1382     -1
    LayerJump_8  R1383     -8
    LayerJump_8  NonOverlap_8  33
    LayerJump_9  R1386     -1
    LayerJump_9  R1387     -9
    LayerJump_9  NonOverlap_9  33
    LayerJump_10  R1390     -1
    LayerJump_10  R1391     -10
    LayerJump_10  NonOverlap_10  33
    LayerJump_11  R1394     -1
    LayerJump_11  R1395     -11
    LayerJump_11  NonOverlap_11  33
    LayerJump_12  R1398     -1
    LayerJump_12  R1399     -12
    LayerJump_12  NonOverlap_12  33
    LayerJump_13  R1402     -1
    LayerJump_13  R1403     -13
    LayerJump_13  NonOverlap_13  33
    LayerJump_14  R1406     -1
    LayerJump_14  R1407     -14
    LayerJump_14  NonOverlap_14  33
    LayerJump_15  R1410     -1
    LayerJump_15  R1411     -15
    LayerJump_15  NonOverlap_15  33
    MARKER    'MARKER'                 'INTEND'
    RE_1      R1446     1
    RE_2      R1447     1
    RE_3      R1448     1
    RE_4      R1449     1
    RE_5      R1450     1
    RE_6      R1451     1
    RE_7      R1452     1
    RE_8      R1453     1
    RE_9      R1454     1
    RE_10     R1455     1
    RE_11     R1456     1
    RE_12     R1457     1
    RE_13     R1458     1
    RE_14     R1459     1
    RE_15     R1460     1
    RE_16     R1461     1
    max_overhang  OBJ       0
RHS
    RHS1      OBJ       -0.5
    RHS1      BaseContact_LB  -0.5
    RHS1      BaseContact_UB  0.5
    RHS1      DAGSupMin_2  1
    RHS1      DAGSupMax_2  3
    RHS1      R10       -33.5
    RHS1      R11       33.5
    RHS1      R12       -33.5
    RHS1      R13       33.5
    RHS1      LayerUB_2_1  2
    RHS1      DAGSupMin_3  1
    RHS1      DAGSupMax_3  3
    RHS1      R23       -33.5
    RHS1      R24       33.5
    RHS1      R25       -33.5
    RHS1      R26       33.5
    RHS1      LayerUB_3_1  3
    RHS1      R34       -33.5
    RHS1      R35       33.5
    RHS1      R36       -33.5
    RHS1      R37       33.5
    RHS1      LayerUB_3_2  3
    RHS1      LayerLB_3_2  -1
    RHS1      DAGSupMin_4  1
    RHS1      DAGSupMax_4  3
    RHS1      R47       -33.5
    RHS1      R48       33.5
    RHS1      R49       -33.5
    RHS1      R50       33.5
    RHS1      LayerUB_4_1  4
    RHS1      R58       -33.5
    RHS1      R59       33.5
    RHS1      R60       -33.5
    RHS1      R61       33.5
    RHS1      LayerUB_4_2  4
    RHS1      LayerLB_4_2  -1
    RHS1      R69       -33.5
    RHS1      R70       33.5
    RHS1      R71       -33.5
    RHS1      R72       33.5
    RHS1      LayerUB_4_3  4
    RHS1      LayerLB_4_3  -2
    RHS1      DAGSupMin_5  1
    RHS1      DAGSupMax_5  3
    RHS1      R82       -33.5
    RHS1      R83       33.5
    RHS1      R84       -33.5
    RHS1      R85       33.5
    RHS1      LayerUB_5_1  5
    RHS1      R93       -33.5
    RHS1      R94       33.5
    RHS1      R95       -33.5
    RHS1      R96       33.5
    RHS1      LayerUB_5_2  5
    RHS1      LayerLB_5_2  -1
    RHS1      R104      -33.5
    RHS1      R105      33.5
    RHS1      R106      -33.5
    RHS1      R107      33.5
    RHS1      LayerUB_5_3  5
    RHS1      LayerLB_5_3  -2
    RHS1      R115      -33.5
    RHS1      R116      33.5
    RHS1      R117      -33.5
    RHS1      R118      33.5
    RHS1      LayerUB_5_4  5
    RHS1      LayerLB_5_4  -3
    RHS1      DAGSupMin_6  1
    RHS1      DAGSupMax_6  3
    RHS1      R128      -33.5
    RHS1      R129      33.5
    RHS1      R130      -33.5
    RHS1      R131      33.5
    RHS1      LayerUB_6_1  6
    RHS1      R139      -33.5
    RHS1      R140      33.5
    RHS1      R141      -33.5
    RHS1      R142      33.5
    RHS1      LayerUB_6_2  6
    RHS1      LayerLB_6_2  -1
    RHS1      R150      -33.5
    RHS1      R151      33.5
    RHS1      R152      -33.5
    RHS1      R153      33.5
    RHS1      LayerUB_6_3  6
    RHS1      LayerLB_6_3  -2
    RHS1      R161      -33.5
    RHS1      R162      33.5
    RHS1      R163      -33.5
    RHS1      R164      33.5
    RHS1      LayerUB_6_4  6
    RHS1      LayerLB_6_4  -3
    RHS1      R172      -33.5
    RHS1      R173      33.5
    RHS1      R174      -33.5
    RHS1      R175      33.5
    RHS1      LayerUB_6_5  6
    RHS1      LayerLB_6_5  -4
    RHS1      DAGSupMin_7  1
    RHS1      DAGSupMax_7  3
    RHS1      R185      -33.5
    RHS1      R186      33.5
    RHS1      R187      -33.5
    RHS1      R188      33.5
    RHS1      LayerUB_7_1  7
    RHS1      R196      -33.5
    RHS1      R197      33.5
    RHS1      R198      -33.5
    RHS1      R199      33.5
    RHS1      LayerUB_7_2  7
    RHS1      LayerLB_7_2  -1
    RHS1      R207      -33.5
    RHS1      R208      33.5
    RHS1      R209      -33.5
    RHS1      R210      33.5
    RHS1      LayerUB_7_3  7
    RHS1      LayerLB_7_3  -2
    RHS1      R218      -33.5
    RHS1      R219      33.5
    RHS1      R220      -33.5
    RHS1      R221      33.5
    RHS1      LayerUB_7_4  7
    RHS1      LayerLB_7_4  -3
    RHS1      R229      -33.5
    RHS1      R230      33.5
    RHS1      R231      -33.5
    RHS1      R232      33.5
    RHS1      LayerUB_7_5  7
    RHS1      LayerLB_7_5  -4
    RHS1      R240      -33.5
    RHS1      R241      33.5
    RHS1      R242      -33.5
    RHS1      R243      33.5
    RHS1      LayerUB_7_6  7
    RHS1      LayerLB_7_6  -5
    RHS1      DAGSupMin_8  1
    RHS1      DAGSupMax_8  3
    RHS1      R253      -33.5
    RHS1      R254      33.5
    RHS1      R255      -33.5
    RHS1      R256      33.5
    RHS1      LayerUB_8_1  8
    RHS1      R264      -33.5
    RHS1      R265      33.5
    RHS1      R266      -33.5
    RHS1      R267      33.5
    RHS1      LayerUB_8_2  8
    RHS1      LayerLB_8_2  -1
    RHS1      R275      -33.5
    RHS1      R276      33.5
    RHS1      R277      -33.5
    RHS1      R278      33.5
    RHS1      LayerUB_8_3  8
    RHS1      LayerLB_8_3  -2
    RHS1      R286      -33.5
    RHS1      R287      33.5
    RHS1      R288      -33.5
    RHS1      R289      33.5
    RHS1      LayerUB_8_4  8
    RHS1      LayerLB_8_4  -3
    RHS1      R297      -33.5
    RHS1      R298      33.5
    RHS1      R299      -33.5
    RHS1      R300      33.5
    RHS1      LayerUB_8_5  8
    RHS1      LayerLB_8_5  -4
    RHS1      R308      -33.5
    RHS1      R309      33.5
    RHS1      R310      -33.5
    RHS1      R311      33.5
    RHS1      LayerUB_8_6  8
    RHS1      LayerLB_8_6  -5
    RHS1      R319      -33.5
    RHS1      R320      33.5
    RHS1      R321      -33.5
    RHS1      R322      33.5
    RHS1      LayerUB_8_7  8
    RHS1      LayerLB_8_7  -6
    RHS1      DAGSupMin_9  1
    RHS1      DAGSupMax_9  3
    RHS1      R332      -33.5
    RHS1      R333      33.5
    RHS1      R334      -33.5
    RHS1      R335      33.5
    RHS1      LayerUB_9_1  9
    RHS1      R343      -33.5
    RHS1      R344      33.5
    RHS1      R345      -33.5
    RHS1      R346      33.5
    RHS1      LayerUB_9_2  9
    RHS1      LayerLB_9_2  -1
    RHS1      R354      -33.5
    RHS1      R355      33.5
    RHS1      R356      -33.5
    RHS1      R357      33.5
    RHS1      LayerUB_9_3  9
    RHS1      LayerLB_9_3  -2
    RHS1      R365      -33.5
    RHS1      R366      33.5
    RHS1      R367      -33.5
    RHS1      R368      33.5
    RHS1      LayerUB_9_4  9
    RHS1      LayerLB_9_4  -3
    RHS1      R376      -33.5
    RHS1      R377      33.5
    RHS1      R378      -33.5
    RHS1      R379      33.5
    RHS1      LayerUB_9_5  9
    RHS1      LayerLB_9_5  -4
    RHS1      R387      -33.5
    RHS1      R388      33.5
    RHS1      R389      -33.5
    RHS1      R390      33.5
    RHS1      LayerUB_9_6  9
    RHS1      LayerLB_9_6  -5
    RHS1      R398      -33.5
    RHS1      R399      33.5
    RHS1      R400      -33.5
    RHS1      R401      33.5
    RHS1      LayerUB_9_7  9
    RHS1      LayerLB_9_7  -6
    RHS1      R409      -33.5
    RHS1      R410      33.5
    RHS1      R411      -33.5
    RHS1      R412      33.5
    RHS1      LayerUB_9_8  9
    RHS1      LayerLB_9_8  -7
    RHS1      DAGSupMin_10  1
    RHS1      DAGSupMax_10  3
    RHS1      R422      -33.5
    RHS1      R423      33.5
    RHS1      R424      -33.5
    RHS1      R425      33.5
    RHS1      LayerUB_10_1  10
    RHS1      R433      -33.5
    RHS1      R434      33.5
    RHS1      R435      -33.5
    RHS1      R436      33.5
    RHS1      LayerUB_10_2  10
    RHS1      LayerLB_10_2  -1
    RHS1      R444      -33.5
    RHS1      R445      33.5
    RHS1      R446      -33.5
    RHS1      R447      33.5
    RHS1      LayerUB_10_3  10
    RHS1      LayerLB_10_3  -2
    RHS1      R455      -33.5
    RHS1      R456      33.5
    RHS1      R457      -33.5
    RHS1      R458      33.5
    RHS1      LayerUB_10_4  10
    RHS1      LayerLB_10_4  -3
    RHS1      R466      -33.5
    RHS1      R467      33.5
    RHS1      R468      -33.5
    RHS1      R469      33.5
    RHS1      LayerUB_10_5  10
    RHS1      LayerLB_10_5  -4
    RHS1      R477      -33.5
    RHS1      R478      33.5
    RHS1      R479      -33.5
    RHS1      R480      33.5
    RHS1      LayerUB_10_6  10
    RHS1      LayerLB_10_6  -5
    RHS1      R488      -33.5
    RHS1      R489      33.5
    RHS1      R490      -33.5
    RHS1      R491      33.5
    RHS1      LayerUB_10_7  10
    RHS1      LayerLB_10_7  -6
    RHS1      R499      -33.5
    RHS1      R500      33.5
    RHS1      R501      -33.5
    RHS1      R502      33.5
    RHS1      LayerUB_10_8  10
    RHS1      LayerLB_10_8  -7
    RHS1      R510      -33.5
    RHS1      R511      33.5
    RHS1      R512      -33.5
    RHS1      R513      33.5
    RHS1      LayerUB_10_9  10
    RHS1      LayerLB_10_9  -8
    RHS1      DAGSupMin_11  1
    RHS1      DAGSupMax_11  3
    RHS1      R523      -33.5
    RHS1      R524      33.5
    RHS1      R525      -33.5
    RHS1      R526      33.5
    RHS1      LayerUB_11_1  11
    RHS1      R534      -33.5
    RHS1      R535      33.5
    RHS1      R536      -33.5
    RHS1      R537      33.5
    RHS1      LayerUB_11_2  11
    RHS1      LayerLB_11_2  -1
    RHS1      R545      -33.5
    RHS1      R546      33.5
    RHS1      R547      -33.5
    RHS1      R548      33.5
    RHS1      LayerUB_11_3  11
    RHS1      LayerLB_11_3  -2
    RHS1      R556      -33.5
    RHS1      R557      33.5
    RHS1      R558      -33.5
    RHS1      R559      33.5
    RHS1      LayerUB_11_4  11
    RHS1      LayerLB_11_4  -3
    RHS1      R567      -33.5
    RHS1      R568      33.5
    RHS1      R569      -33.5
    RHS1      R570      33.5
    RHS1      LayerUB_11_5  11
    RHS1      LayerLB_11_5  -4
    RHS1      R578      -33.5
    RHS1      R579      33.5
    RHS1      R580      -33.5
    RHS1      R581      33.5
    RHS1      LayerUB_11_6  11
    RHS1      LayerLB_11_6  -5
    RHS1      R589      -33.5
    RHS1      R590      33.5
    RHS1      R591      -33.5
    RHS1      R592      33.5
    RHS1      LayerUB_11_7  11
    RHS1      LayerLB_11_7  -6
    RHS1      R600      -33.5
    RHS1      R601      33.5
    RHS1      R602      -33.5
    RHS1      R603      33.5
    RHS1      LayerUB_11_8  11
    RHS1      LayerLB_11_8  -7
    RHS1      R611      -33.5
    RHS1      R612      33.5
    RHS1      R613      -33.5
    RHS1      R614      33.5
    RHS1      LayerUB_11_9  11
    RHS1      LayerLB_11_9  -8
    RHS1      R622      -33.5
    RHS1      R623      33.5
    RHS1      R624      -33.5
    RHS1      R625      33.5
    RHS1      LayerUB_11_10  11
    RHS1      LayerLB_11_10  -9
    RHS1      DAGSupMin_12  1
    RHS1      DAGSupMax_12  3
    RHS1      R635      -33.5
    RHS1      R636      33.5
    RHS1      R637      -33.5
    RHS1      R638      33.5
    RHS1      LayerUB_12_1  12
    RHS1      R646      -33.5
    RHS1      R647      33.5
    RHS1      R648      -33.5
    RHS1      R649      33.5
    RHS1      LayerUB_12_2  12
    RHS1      LayerLB_12_2  -1
    RHS1      R657      -33.5
    RHS1      R658      33.5
    RHS1      R659      -33.5
    RHS1      R660      33.5
    RHS1      LayerUB_12_3  12
    RHS1      LayerLB_12_3  -2
    RHS1      R668      -33.5
    RHS1      R669      33.5
    RHS1      R670      -33.5
    RHS1      R671      33.5
    RHS1      LayerUB_12_4  12
    RHS1      LayerLB_12_4  -3
    RHS1      R679      -33.5
    RHS1      R680      33.5
    RHS1      R681      -33.5
    RHS1      R682      33.5
    RHS1      LayerUB_12_5  12
    RHS1      LayerLB_12_5  -4
    RHS1      R690      -33.5
    RHS1      R691      33.5
    RHS1      R692      -33.5
    RHS1      R693      33.5
    RHS1      LayerUB_12_6  12
    RHS1      LayerLB_12_6  -5
    RHS1      R701      -33.5
    RHS1      R702      33.5
    RHS1      R703      -33.5
    RHS1      R704      33.5
    RHS1      LayerUB_12_7  12
    RHS1      LayerLB_12_7  -6
    RHS1      R712      -33.5
    RHS1      R713      33.5
    RHS1      R714      -33.5
    RHS1      R715      33.5
    RHS1      LayerUB_12_8  12
    RHS1      LayerLB_12_8  -7
    RHS1      R723      -33.5
    RHS1      R724      33.5
    RHS1      R725      -33.5
    RHS1      R726      33.5
    RHS1      LayerUB_12_9  12
    RHS1      LayerLB_12_9  -8
    RHS1      R734      -33.5
    RHS1      R735      33.5
    RHS1      R736      -33.5
    RHS1      R737      33.5
    RHS1      LayerUB_12_10  12
    RHS1      LayerLB_12_10  -9
    RHS1      R745      -33.5
    RHS1      R746      33.5
    RHS1      R747      -33.5
    RHS1      R748      33.5
    RHS1      LayerUB_12_11  12
    RHS1      LayerLB_12_11  -10
    RHS1      DAGSupMin_13  1
    RHS1      DAGSupMax_13  3
    RHS1      R758      -33.5
    RHS1      R759      33.5
    RHS1      R760      -33.5
    RHS1      R761      33.5
    RHS1      LayerUB_13_1  13
    RHS1      R769      -33.5
    RHS1      R770      33.5
    RHS1      R771      -33.5
    RHS1      R772      33.5
    RHS1      LayerUB_13_2  13
    RHS1      LayerLB_13_2  -1
    RHS1      R780      -33.5
    RHS1      R781      33.5
    RHS1      R782      -33.5
    RHS1      R783      33.5
    RHS1      LayerUB_13_3  13
    RHS1      LayerLB_13_3  -2
    RHS1      R791      -33.5
    RHS1      R792      33.5
    RHS1      R793      -33.5
    RHS1      R794      33.5
    RHS1      LayerUB_13_4  13
    RHS1      LayerLB_13_4  -3
    RHS1      R802      -33.5
    RHS1      R803      33.5
    RHS1      R804      -33.5
    RHS1      R805      33.5
    RHS1      LayerUB_13_5  13
    RHS1      LayerLB_13_5  -4
    RHS1      R813      -33.5
    RHS1      R814      33.5
    RHS1      R815      -33.5
    RHS1      R816      33.5
    RHS1      LayerUB_13_6  13
    RHS1      LayerLB_13_6  -5
    RHS1      R824      -33.5
    RHS1      R825      33.5
    RHS1      R826      -33.5
    RHS1      R827      33.5
    RHS1      LayerUB_13_7  13
    RHS1      LayerLB_13_7  -6
    RHS1      R835      -33.5
    RHS1      R836      33.5
    RHS1      R837      -33.5
    RHS1      R838      33.5
    RHS1      LayerUB_13_8  13
    RHS1      LayerLB_13_8  -7
    RHS1      R846      -33.5
    RHS1      R847      33.5
    RHS1      R848      -33.5
    RHS1      R849      33.5
    RHS1      LayerUB_13_9  13
    RHS1      LayerLB_13_9  -8
    RHS1      R857      -33.5
    RHS1      R858      33.5
    RHS1      R859      -33.5
    RHS1      R860      33.5
    RHS1      LayerUB_13_10  13
    RHS1      LayerLB_13_10  -9
    RHS1      R868      -33.5
    RHS1      R869      33.5
    RHS1      R870      -33.5
    RHS1      R871      33.5
    RHS1      LayerUB_13_11  13
    RHS1      LayerLB_13_11  -10
    RHS1      R879      -33.5
    RHS1      R880      33.5
    RHS1      R881      -33.5
    RHS1      R882      33.5
    RHS1      LayerUB_13_12  13
    RHS1      LayerLB_13_12  -11
    RHS1      DAGSupMin_14  1
    RHS1      DAGSupMax_14  3
    RHS1      R892      -33.5
    RHS1      R893      33.5
    RHS1      R894      -33.5
    RHS1      R895      33.5
    RHS1      LayerUB_14_1  14
    RHS1      R903      -33.5
    RHS1      R904      33.5
    RHS1      R905      -33.5
    RHS1      R906      33.5
    RHS1      LayerUB_14_2  14
    RHS1      LayerLB_14_2  -1
    RHS1      R914      -33.5
    RHS1      R915      33.5
    RHS1      R916      -33.5
    RHS1      R917      33.5
    RHS1      LayerUB_14_3  14
    RHS1      LayerLB_14_3  -2
    RHS1      R925      -33.5
    RHS1      R926      33.5
    RHS1      R927      -33.5
    RHS1      R928      33.5
    RHS1      LayerUB_14_4  14
    RHS1      LayerLB_14_4  -3
    RHS1      R936      -33.5
    RHS1      R937      33.5
    RHS1      R938      -33.5
    RHS1      R939      33.5
    RHS1      LayerUB_14_5  14
    RHS1      LayerLB_14_5  -4
    RHS1      R947      -33.5
    RHS1      R948      33.5
    RHS1      R949      -33.5
    RHS1      R950      33.5
    RHS1      LayerUB_14_6  14
    RHS1      LayerLB_14_6  -5
    RHS1      R958      -33.5
    RHS1      R959      33.5
    RHS1      R960      -33.5
    RHS1      R961      33.5
    RHS1      LayerUB_14_7  14
    RHS1      LayerLB_14_7  -6
    RHS1      R969      -33.5
    RHS1      R970      33.5
    RHS1      R971      -33.5
    RHS1      R972      33.5
    RHS1      LayerUB_14_8  14
    RHS1      LayerLB_14_8  -7
    RHS1      R980      -33.5
    RHS1      R981      33.5
    RHS1      R982      -33.5
    RHS1      R983      33.5
    RHS1      LayerUB_14_9  14
    RHS1      LayerLB_14_9  -8
    RHS1      R991      -33.5
    RHS1      R992      33.5
    RHS1      R993      -33.5
    RHS1      R994      33.5
    RHS1      LayerUB_14_10  14
    RHS1      LayerLB_14_10  -9
    RHS1      R1002     -33.5
    RHS1      R1003     33.5
    RHS1      R1004     -33.5
    RHS1      R1005     33.5
    RHS1      LayerUB_14_11  14
    RHS1      LayerLB_14_11  -10
    RHS1      R1013     -33.5
    RHS1      R1014     33.5
    RHS1      R1015     -33.5
    RHS1      R1016     33.5
    RHS1      LayerUB_14_12  14
    RHS1      LayerLB_14_12  -11
    RHS1      R1024     -33.5
    RHS1      R1025     33.5
    RHS1      R1026     -33.5
    RHS1      R1027     33.5
    RHS1      LayerUB_14_13  14
    RHS1      LayerLB_14_13  -12
    RHS1      DAGSupMin_15  1
    RHS1      DAGSupMax_15  3
    RHS1      R1037     -33.5
    RHS1      R1038     33.5
    RHS1      R1039     -33.5
    RHS1      R1040     33.5
    RHS1      LayerUB_15_1  15
    RHS1      R1048     -33.5
    RHS1      R1049     33.5
    RHS1      R1050     -33.5
    RHS1      R1051     33.5
    RHS1      LayerUB_15_2  15
    RHS1      LayerLB_15_2  -1
    RHS1      R1059     -33.5
    RHS1      R1060     33.5
    RHS1      R1061     -33.5
    RHS1      R1062     33.5
    RHS1      LayerUB_15_3  15
    RHS1      LayerLB_15_3  -2
    RHS1      R1070     -33.5
    RHS1      R1071     33.5
    RHS1      R1072     -33.5
    RHS1      R1073     33.5
    RHS1      LayerUB_15_4  15
    RHS1      LayerLB_15_4  -3
    RHS1      R1081     -33.5
    RHS1      R1082     33.5
    RHS1      R1083     -33.5
    RHS1      R1084     33.5
    RHS1      LayerUB_15_5  15
    RHS1      LayerLB_15_5  -4
    RHS1      R1092     -33.5
    RHS1      R1093     33.5
    RHS1      R1094     -33.5
    RHS1      R1095     33.5
    RHS1      LayerUB_15_6  15
    RHS1      LayerLB_15_6  -5
    RHS1      R1103     -33.5
    RHS1      R1104     33.5
    RHS1      R1105     -33.5
    RHS1      R1106     33.5
    RHS1      LayerUB_15_7  15
    RHS1      LayerLB_15_7  -6
    RHS1      R1114     -33.5
    RHS1      R1115     33.5
    RHS1      R1116     -33.5
    RHS1      R1117     33.5
    RHS1      LayerUB_15_8  15
    RHS1      LayerLB_15_8  -7
    RHS1      R1125     -33.5
    RHS1      R1126     33.5
    RHS1      R1127     -33.5
    RHS1      R1128     33.5
    RHS1      LayerUB_15_9  15
    RHS1      LayerLB_15_9  -8
    RHS1      R1136     -33.5
    RHS1      R1137     33.5
    RHS1      R1138     -33.5
    RHS1      R1139     33.5
    RHS1      LayerUB_15_10  15
    RHS1      LayerLB_15_10  -9
    RHS1      R1147     -33.5
    RHS1      R1148     33.5
    RHS1      R1149     -33.5
    RHS1      R1150     33.5
    RHS1      LayerUB_15_11  15
    RHS1      LayerLB_15_11  -10
    RHS1      R1158     -33.5
    RHS1      R1159     33.5
    RHS1      R1160     -33.5
    RHS1      R1161     33.5
    RHS1      LayerUB_15_12  15
    RHS1      LayerLB_15_12  -11
    RHS1      R1169     -33.5
    RHS1      R1170     33.5
    RHS1      R1171     -33.5
    RHS1      R1172     33.5
    RHS1      LayerUB_15_13  15
    RHS1      LayerLB_15_13  -12
    RHS1      R1180     -33.5
    RHS1      R1181     33.5
    RHS1      R1182     -33.5
    RHS1      R1183     33.5
    RHS1      LayerUB_15_14  15
    RHS1      LayerLB_15_14  -13
    RHS1      DAGSupMin_16  1
    RHS1      DAGSupMax_16  3
    RHS1      R1193     -33.5
    RHS1      R1194     33.5
    RHS1      R1195     -33.5
    RHS1      R1196     33.5
    RHS1      LayerUB_16_1  16
    RHS1      R1204     -33.5
    RHS1      R1205     33.5
    RHS1      R1206     -33.5
    RHS1      R1207     33.5
    RHS1      LayerUB_16_2  16
    RHS1      LayerLB_16_2  -1
    RHS1      R1215     -33.5
    RHS1      R1216     33.5
    RHS1      R1217     -33.5
    RHS1      R1218     33.5
    RHS1      LayerUB_16_3  16
    RHS1      LayerLB_16_3  -2
    RHS1      R1226     -33.5
    RHS1      R1227     33.5
    RHS1      R1228     -33.5
    RHS1      R1229     33.5
    RHS1      LayerUB_16_4  16
    RHS1      LayerLB_16_4  -3
    RHS1      R1237     -33.5
    RHS1      R1238     33.5
    RHS1      R1239     -33.5
    RHS1      R1240     33.5
    RHS1      LayerUB_16_5  16
    RHS1      LayerLB_16_5  -4
    RHS1      R1248     -33.5
    RHS1      R1249     33.5
    RHS1      R1250     -33.5
    RHS1      R1251     33.5
    RHS1      LayerUB_16_6  16
    RHS1      LayerLB_16_6  -5
    RHS1      R1259     -33.5
    RHS1      R1260     33.5
    RHS1      R1261     -33.5
    RHS1      R1262     33.5
    RHS1      LayerUB_16_7  16
    RHS1      LayerLB_16_7  -6
    RHS1      R1270     -33.5
    RHS1      R1271     33.5
    RHS1      R1272     -33.5
    RHS1      R1273     33.5
    RHS1      LayerUB_16_8  16
    RHS1      LayerLB_16_8  -7
    RHS1      R1281     -33.5
    RHS1      R1282     33.5
    RHS1      R1283     -33.5
    RHS1      R1284     33.5
    RHS1      LayerUB_16_9  16
    RHS1      LayerLB_16_9  -8
    RHS1      R1292     -33.5
    RHS1      R1293     33.5
    RHS1      R1294     -33.5
    RHS1      R1295     33.5
    RHS1      LayerUB_16_10  16
    RHS1      LayerLB_16_10  -9
    RHS1      R1303     -33.5
    RHS1      R1304     33.5
    RHS1      R1305     -33.5
    RHS1      R1306     33.5
    RHS1      LayerUB_16_11  16
    RHS1      LayerLB_16_11  -10
    RHS1      R1314     -33.5
    RHS1      R1315     33.5
    RHS1      R1316     -33.5
    RHS1      R1317     33.5
    RHS1      LayerUB_16_12  16
    RHS1      LayerLB_16_12  -11
    RHS1      R1325     -33.5
    RHS1      R1326     33.5
    RHS1      R1327     -33.5
    RHS1      R1328     33.5
    RHS1      LayerUB_16_13  16
    RHS1      LayerLB_16_13  -12
    RHS1      R1336     -33.5
    RHS1      R1337     33.5
    RHS1      R1338     -33.5
    RHS1      R1339     33.5
    RHS1      LayerUB_16_14  16
    RHS1      LayerLB_16_14  -13
    RHS1      R1347     -33.5
    RHS1      R1348     33.5
    RHS1      R1349     -33.5
    RHS1      R1350     33.5
    RHS1      LayerUB_16_15  16
    RHS1      LayerLB_16_15  -14
    RHS1      NonOverlap_1  1
    RHS1      NonOverlap_2  1
    RHS1      NonOverlap_3  1
    RHS1      NonOverlap_4  1
    RHS1      NonOverlap_5  1
    RHS1      NonOverlap_6  1
    RHS1      NonOverlap_7  1
    RHS1      NonOverlap_8  1
    RHS1      NonOverlap_9  1
    RHS1      NonOverlap_10  1
    RHS1      NonOverlap_11  1
    RHS1      NonOverlap_12  1
    RHS1      NonOverlap_13  1
    RHS1      NonOverlap_14  1
    RHS1      NonOverlap_15  1
    RHS1      ForceBal_1  -1
    RHS1      ForceBal_2  -1
    RHS1      ForceBal_3  -1
    RHS1      ForceBal_4  -1
    RHS1      ForceBal_5  -1
    RHS1      ForceBal_6  -1
    RHS1      ForceBal_7  -1
    RHS1      ForceBal_8  -1
    RHS1      ForceBal_9  -1
    RHS1      ForceBal_10  -1
    RHS1      ForceBal_11  -1
    RHS1      ForceBal_12  -1
    RHS1      ForceBal_13  -1
    RHS1      ForceBal_14  -1
    RHS1      ForceBal_15  -1
    RHS1      ForceBal_16  -1
    RHS1      R1446     0.5
    RHS1      R1447     0.5
    RHS1      R1448     0.5
    RHS1      R1449     0.5
    RHS1      R1450     0.5
    RHS1      R1451     0.5
    RHS1      R1452     0.5
    RHS1      R1453     0.5
    RHS1      R1454     0.5
    RHS1      R1455     0.5
    RHS1      R1456     0.5
    RHS1      R1457     0.5
    RHS1      R1458     0.5
    RHS1      R1459     0.5
    RHS1      R1460     0.5
    RHS1      R1461     0.5
    RHS1      S2_Lmin_3  2
    RHS1      S2_Lmin_5  3
    RHS1      S2_Lmin_6  3
    RHS1      S2_Lmin_7  3
    RHS1      S2_Lmin_9  4
    RHS1      S2_Lmin_10  4
    RHS1      S2_Lmin_11  4
    RHS1      S2_Lmin_12  4
    RHS1      S2_Lmin_13  4
    RHS1      S2_Lmin_15  5
    RHS1      S2_Lmin_16  5
    RHS1      S2_T21    1
    RHS1      S2_T31    1
    RHS1      S2_F21lo  1
    RHS1      S2_F21hi  14
    RHS1      S2_F31lo  1
    RHS1      S2_F31hi  14
    RHS1      TightUp_2  -1
    RHS1      TightDn_2  -1
    RHS1      TightUp_3  -1
    RHS1      TightDn_3  -1
    RHS1      TightUp_4  -1
    RHS1      TightDn_4  -1
    RHS1      TightUp_5  -1
    RHS1      TightDn_5  -1
    RHS1      TightUp_6  -1
    RHS1      TightDn_6  -1
    RHS1      TightUp_7  -1
    RHS1      TightDn_7  -1
    RHS1      TightUp_8  -1
    RHS1      TightDn_8  -1
    RHS1      TightUp_9  -1
    RHS1      TightDn_9  -1
    RHS1      TightUp_10  -1
    RHS1      TightDn_10  -1
    RHS1      TightUp_11  -1
    RHS1      TightDn_11  -1
    RHS1      TightUp_12  -1
    RHS1      TightDn_12  -1
    RHS1      TightUp_13  -1
    RHS1      TightDn_13  -1
    RHS1      TightUp_14  -1
    RHS1      TightDn_14  -1
    RHS1      TightUp_15  -1
    RHS1      TightDn_15  -1
    RHS1      TightUp_16  -1
    RHS1      TightDn_16  -1
    RHS1      S4_BaseRightCorner  0.5
    RHS1      C2_b      -14
    RHS1      C2_d      -1
    RHS1      RB_up_2   1
    RHS1      RB_dn_3   1
    RHS1      RB_up_4   2
    RHS1      RB_dn_4   1
    RHS1      RB_up_5   1
    RHS1      RB_dn_5   2
    RHS1      RB_up_6   3
    RHS1      RB_dn_6   2
    RHS1      RB_up_7   2
    RHS1      RB_dn_7   3
    RHS1      RB_up_8   4
    RHS1      RB_dn_8   3
    RHS1      RB_up_9   3
    RHS1      RB_dn_9   4
    RHS1      RB_up_10  5
    RHS1      RB_dn_10  3
    RHS1      RB_up_11  4
    RHS1      RB_dn_11  4
    RHS1      RB_up_12  3
    RHS1      RB_dn_12  5
    RHS1      RB_up_13  6
    RHS1      RB_dn_13  4
    RHS1      RB_up_14  5
    RHS1      RB_dn_14  5
    RHS1      RB_up_15  4
    RHS1      RB_dn_15  6
    RHS1      RB_up_16  7
    RHS1      RB_dn_16  7
    RHS1      SP_3      1.4330738276140063e+00
    RHS1      SP_4      1.5760284125495430e+00
    RHS1      SP_5      1.6319589464655371e+00
    RHS1      SP_6      1.6438427976304739e+00
    RHS1      SP_7      1.6330428386545863e+00
    RHS1      SP_8      1.6106046307203941e+00
    RHS1      NC_10_12_8_9  1
    RHS1      NC_13_14_10_12  1
    RHS1      NC_13_15_10_11  1
    RHS1      NC_13_15_10_12  1
    RHS1      NC_13_15_11_12  1
    RHS1      NC_14_15_10_12  1
    RHS1      C2L_DeltaUB_2  2
    RHS1      C2L_a_2   -6.5
    RHS1      C2L_b_2   -32.5
    RHS1      C2L_c_2   -6.5
    RHS1      C2L_d_2   6.5
    RHS1      C2L_DeltaUB_3  4
    RHS1      C2L_a_3   -5.5
    RHS1      C2L_b_3   -49.5
    RHS1      C2L_c_3   -5.5
    RHS1      C2L_d_3   5.5
    RHS1      C2L_DeltaUB_4  6
    RHS1      C2L_a_4   -4.5
    RHS1      C2L_b_4   -58.5
    RHS1      C2L_c_4   -4.5
    RHS1      C2L_d_4   4.5
    RHS1      C2L_DeltaUB_5  8
    RHS1      C2L_a_5   -3.5
    RHS1      C2L_b_5   -59.5
    RHS1      C2L_c_5   -3.5
    RHS1      C2L_d_5   3.5
    RHS1      RM_beats_cutoff  1.6224043686641689e+00
    RHS1      NonSpinal_t0  1
    RHS1      LowerSpine  1.1151966104067264e+00
BOUNDS
 FX BND1      X_0       0
 LO BND1      X_1       -0.5
 UP BND1      X_1       0.40625
 LO BND1      X_2       -0.5
 UP BND1      X_2       1.40625
 LO BND1      X_3       -1.5
 UP BND1      X_3       0.40625
 LO BND1      X_4       -1.5
 UP BND1      X_4       2.40625
 LO BND1      X_5       -2.5
 UP BND1      X_5       1.40625
 LO BND1      X_6       -1.3775956313358311e+00
 UP BND1      X_6       3.40625
 LO BND1      X_7       -3.5
 UP BND1      X_7       2.40625
 LO BND1      X_8       -3.7759563133583107e-01
 UP BND1      X_8       4.40625
 LO BND1      X_9       -4.5
 UP BND1      X_9       3.40625
 LO BND1      X_10      6.2240436866416893e-01
 UP BND1      X_10      5.40625
 LO BND1      X_11      -4.5
 UP BND1      X_11      4.40625
 LO BND1      X_12      -5.5
 UP BND1      X_12      3.40625
 LO BND1      X_13      1.6224043686641689e+00
 UP BND1      X_13      6.40625
 LO BND1      X_14      -5.5
 UP BND1      X_14      5.40625
 LO BND1      X_15      -6.5
 UP BND1      X_15      4.40625
 LO BND1      X_16      -7.5
 UP BND1      X_16      7.40625
 FX BND1      L_0       0
 FX BND1      L_1       1
 FX BND1      L_2       2
 FX BND1      L_3       2
 FX BND1      L_4       3
 FX BND1      L_5       3
 FX BND1      L_6       4
 FX BND1      L_7       4
 FX BND1      L_8       5
 FX BND1      L_9       5
 FX BND1      L_10      6
 FX BND1      L_11      6
 FX BND1      L_12      6
 FX BND1      L_13      7
 FX BND1      L_14      7
 FX BND1      L_15      7
 FX BND1      L_16      8
 FX BND1      T_1_0     1
 BV BND1      T_1_0   
 FX BND1      F_1_0     16
 FX BND1      P_1_0     0
 LO BND1      Torque_1_0  -16
 UP BND1      Torque_1_0  0
 FX BND1      T_2_1     1
 BV BND1      T_2_1   
 UP BND1      F_2_1     14
 UP BND1      P_2_1     0.90625
 UP BND1      Torque_2_1  12.6875
 FX BND1      T_3_1     1
 BV BND1      T_3_1   
 UP BND1      F_3_1     14
 LO BND1      P_3_1     -1
 UP BND1      P_3_1     0.90625
 LO BND1      Torque_3_1  -14
 UP BND1      Torque_3_1  12.6875
 FX BND1      T_3_2     0
 BV BND1      T_3_2   
 FX BND1      F_3_2     0
 FX BND1      P_3_2     0
 FX BND1      Torque_3_2  0
 FX BND1      T_4_1     0
 BV BND1      T_4_1   
 FX BND1      F_4_1     0
 FX BND1      P_4_1     0
 FX BND1      Torque_4_1  0
 BV BND1      T_4_2   
 UP BND1      F_4_2     13
 LO BND1      P_4_2     -1
 UP BND1      P_4_2     1.90625
 LO BND1      Torque_4_2  -13
 UP BND1      Torque_4_2  24.78125
 BV BND1      T_4_3   
 UP BND1      F_4_3     13
 LO BND1      P_4_3     -2
 UP BND1      P_4_3     0.90625
 LO BND1      Torque_4_3  -26
 UP BND1      Torque_4_3  11.78125
 FX BND1      T_5_1     0
 BV BND1      T_5_1   
 FX BND1      F_5_1     0
 FX BND1      P_5_1     0
 FX BND1      Torque_5_1  0
 BV BND1      T_5_2   
 UP BND1      F_5_2     12
 LO BND1      P_5_2     -1
 UP BND1      P_5_2     1.90625
 LO BND1      Torque_5_2  -12
 UP BND1      Torque_5_2  22.875
 BV BND1      T_5_3   
 UP BND1      F_5_3     12
 LO BND1      P_5_3     -2
 UP BND1      P_5_3     0.90625
 LO BND1      Torque_5_3  -24
 UP BND1      Torque_5_3  10.875
 FX BND1      T_5_4     0
 BV BND1      T_5_4   
 FX BND1      F_5_4     0
 FX BND1      P_5_4     0
 FX BND1      Torque_5_4  0
 FX BND1      T_6_1     0
 BV BND1      T_6_1   
 FX BND1      F_6_1     0
 FX BND1      P_6_1     0
 FX BND1      Torque_6_1  0
 FX BND1      T_6_2     0
 BV BND1      T_6_2   
 FX BND1      F_6_2     0
 FX BND1      P_6_2     0
 FX BND1      Torque_6_2  0
 FX BND1      T_6_3     0
 BV BND1      T_6_3   
 FX BND1      F_6_3     0
 FX BND1      P_6_3     0
 FX BND1      Torque_6_3  0
 BV BND1      T_6_4   
 UP BND1      F_6_4     11
 LO BND1      P_6_4     -1.8775956313358311e+00
 UP BND1      P_6_4     2.90625
 LO BND1      Torque_6_4  -2.0653551944694144e+01
 UP BND1      Torque_6_4  31.96875
 BV BND1      T_6_5   
 UP BND1      F_6_5     11
 LO BND1      P_6_5     -1.8775956313358311e+00
 UP BND1      P_6_5     1.90625
 LO BND1      Torque_6_5  -2.0653551944694144e+01
 UP BND1      Torque_6_5  20.96875
 FX BND1      T_7_1     0
 BV BND1      T_7_1   
 FX BND1      F_7_1     0
 FX BND1      P_7_1     0
 FX BND1      Torque_7_1  0
 FX BND1      T_7_2     0
 BV BND1      T_7_2   
 FX BND1      F_7_2     0
 FX BND1      P_7_2     0
 FX BND1      Torque_7_2  0
 FX BND1      T_7_3     0
 BV BND1      T_7_3   
 FX BND1      F_7_3     0
 FX BND1      P_7_3     0
 FX BND1      Torque_7_3  0
 BV BND1      T_7_4   
 UP BND1      F_7_4     10
 LO BND1      P_7_4     -2
 UP BND1      P_7_4     2.90625
 LO BND1      Torque_7_4  -20
 UP BND1      Torque_7_4  29.0625
 BV BND1      T_7_5   
 UP BND1      F_7_5     10
 LO BND1      P_7_5     -3
 UP BND1      P_7_5     1.90625
 LO BND1      Torque_7_5  -30
 UP BND1      Torque_7_5  19.0625
 FX BND1      T_7_6     0
 BV BND1      T_7_6   
 FX BND1      F_7_6     0
 FX BND1      P_7_6     0
 FX BND1      Torque_7_6  0
 FX BND1      T_8_1     0
 BV BND1      T_8_1   
 FX BND1      F_8_1     0
 FX BND1      P_8_1     0
 FX BND1      Torque_8_1  0
 FX BND1      T_8_2     0
 BV BND1      T_8_2   
 FX BND1      F_8_2     0
 FX BND1      P_8_2     0
 FX BND1      Torque_8_2  0
 FX BND1      T_8_3     0
 BV BND1      T_8_3   
 FX BND1      F_8_3     0
 FX BND1      P_8_3     0
 FX BND1      Torque_8_3  0
 FX BND1      T_8_4     0
 BV BND1      T_8_4   
 FX BND1      F_8_4     0
 FX BND1      P_8_4     0
 FX BND1      Torque_8_4  0
 FX BND1      T_8_5     0
 BV BND1      T_8_5   
 FX BND1      F_8_5     0
 FX BND1      P_8_5     0
 FX BND1      Torque_8_5  0
 BV BND1      T_8_6   
 UP BND1      F_8_6     9
 LO BND1      P_8_6     -8.7759563133583107e-01
 UP BND1      P_8_6     3.90625
 LO BND1      Torque_8_6  -7.89836068202248
 UP BND1      Torque_8_6  35.15625
 BV BND1      T_8_7   
 UP BND1      F_8_7     9
 LO BND1      P_8_7     -8.7759563133583107e-01
 UP BND1      P_8_7     2.90625
 LO BND1      Torque_8_7  -7.89836068202248
 UP BND1      Torque_8_7  26.15625
 FX BND1      T_9_1     0
 BV BND1      T_9_1   
 FX BND1      F_9_1     0
 FX BND1      P_9_1     0
 FX BND1      Torque_9_1  0
 FX BND1      T_9_2     0
 BV BND1      T_9_2   
 FX BND1      F_9_2     0
 FX BND1      P_9_2     0
 FX BND1      Torque_9_2  0
 FX BND1      T_9_3     0
 BV BND1      T_9_3   
 FX BND1      F_9_3     0
 FX BND1      P_9_3     0
 FX BND1      Torque_9_3  0
 FX BND1      T_9_4     0
 BV BND1      T_9_4   
 FX BND1      F_9_4     0
 FX BND1      P_9_4     0
 FX BND1      Torque_9_4  0
 FX BND1      T_9_5     0
 BV BND1      T_9_5   
 FX BND1      F_9_5     0
 FX BND1      P_9_5     0
 FX BND1      Torque_9_5  0
 BV BND1      T_9_6   
 UP BND1      F_9_6     8
 LO BND1      P_9_6     -1.8775956313358311e+00
 UP BND1      P_9_6     3.90625
 LO BND1      Torque_9_6  -1.5020765050686649e+01
 UP BND1      Torque_9_6  31.25
 BV BND1      T_9_7   
 UP BND1      F_9_7     8
 LO BND1      P_9_7     -4
 UP BND1      P_9_7     2.90625
 LO BND1      Torque_9_7  -32
 UP BND1      Torque_9_7  23.25
 FX BND1      T_9_8     0
 BV BND1      T_9_8   
 FX BND1      F_9_8     0
 FX BND1      P_9_8     0
 FX BND1      Torque_9_8  0
 FX BND1      T_10_1    0
 BV BND1      T_10_1  
 FX BND1      F_10_1    0
 FX BND1      P_10_1    0
 FX BND1      Torque_10_1  0
 FX BND1      T_10_2    0
 BV BND1      T_10_2  
 FX BND1      F_10_2    0
 FX BND1      P_10_2    0
 FX BND1      Torque_10_2  0
 FX BND1      T_10_3    0
 BV BND1      T_10_3  
 FX BND1      F_10_3    0
 FX BND1      P_10_3    0
 FX BND1      Torque_10_3  0
 FX BND1      T_10_4    0
 BV BND1      T_10_4  
 FX BND1      F_10_4    0
 FX BND1      P_10_4    0
 FX BND1      Torque_10_4  0
 FX BND1      T_10_5    0
 BV BND1      T_10_5  
 FX BND1      F_10_5    0
 FX BND1      P_10_5    0
 FX BND1      Torque_10_5  0
 FX BND1      T_10_6    0
 BV BND1      T_10_6  
 FX BND1      F_10_6    0
 FX BND1      P_10_6    0
 FX BND1      Torque_10_6  0
 FX BND1      T_10_7    0
 BV BND1      T_10_7  
 FX BND1      F_10_7    0
 FX BND1      P_10_7    0
 FX BND1      Torque_10_7  0
 BV BND1      T_10_8  
 UP BND1      F_10_8    7
 UP BND1      P_10_8    4.90625
 UP BND1      Torque_10_8  34.34375
 BV BND1      T_10_9  
 UP BND1      F_10_9    7
 UP BND1      P_10_9    3.90625
 UP BND1      Torque_10_9  27.34375
 FX BND1      T_11_1    0
 BV BND1      T_11_1  
 FX BND1      F_11_1    0
 FX BND1      P_11_1    0
 FX BND1      Torque_11_1  0
 FX BND1      T_11_2    0
 BV BND1      T_11_2  
 FX BND1      F_11_2    0
 FX BND1      P_11_2    0
 FX BND1      Torque_11_2  0
 FX BND1      T_11_3    0
 BV BND1      T_11_3  
 FX BND1      F_11_3    0
 FX BND1      P_11_3    0
 FX BND1      Torque_11_3  0
 FX BND1      T_11_4    0
 BV BND1      T_11_4  
 FX BND1      F_11_4    0
 FX BND1      P_11_4    0
 FX BND1      Torque_11_4  0
 FX BND1      T_11_5    0
 BV BND1      T_11_5  
 FX BND1      F_11_5    0
 FX BND1      P_11_5    0
 FX BND1      Torque_11_5  0
 FX BND1      T_11_6    0
 BV BND1      T_11_6  
 FX BND1      F_11_6    0
 FX BND1      P_11_6    0
 FX BND1      Torque_11_6  0
 FX BND1      T_11_7    0
 BV BND1      T_11_7  
 FX BND1      F_11_7    0
 FX BND1      P_11_7    0
 FX BND1      Torque_11_7  0
 BV BND1      T_11_8  
 UP BND1      F_11_8    6
 LO BND1      P_11_8    -8.7759563133583107e-01
 UP BND1      P_11_8    4.90625
 LO BND1      Torque_11_8  -5.2655737880149864e+00
 UP BND1      Torque_11_8  29.4375
 BV BND1      T_11_9  
 UP BND1      F_11_9    6
 LO BND1      P_11_9    -5
 UP BND1      P_11_9    3.90625
 LO BND1      Torque_11_9  -30
 UP BND1      Torque_11_9  23.4375
 FX BND1      T_11_10   0
 BV BND1      T_11_10 
 FX BND1      F_11_10   0
 FX BND1      P_11_10   0
 FX BND1      Torque_11_10  0
 FX BND1      T_12_1    0
 BV BND1      T_12_1  
 FX BND1      F_12_1    0
 FX BND1      P_12_1    0
 FX BND1      Torque_12_1  0
 FX BND1      T_12_2    0
 BV BND1      T_12_2  
 FX BND1      F_12_2    0
 FX BND1      P_12_2    0
 FX BND1      Torque_12_2  0
 FX BND1      T_12_3    0
 BV BND1      T_12_3  
 FX BND1      F_12_3    0
 FX BND1      P_12_3    0
 FX BND1      Torque_12_3  0
 FX BND1      T_12_4    0
 BV BND1      T_12_4  
 FX BND1      F_12_4    0
 FX BND1      P_12_4    0
 FX BND1      Torque_12_4  0
 FX BND1      T_12_5    0
 BV BND1      T_12_5  
 FX BND1      F_12_5    0
 FX BND1      P_12_5    0
 FX BND1      Torque_12_5  0
 FX BND1      T_12_6    0
 BV BND1      T_12_6  
 FX BND1      F_12_6    0
 FX BND1      P_12_6    0
 FX BND1      Torque_12_6  0
 FX BND1      T_12_7    0
 BV BND1      T_12_7  
 FX BND1      F_12_7    0
 FX BND1      P_12_7    0
 FX BND1      Torque_12_7  0
 BV BND1      T_12_8  
 UP BND1      F_12_8    5
 LO BND1      P_12_8    -8.7759563133583107e-01
 UP BND1      P_12_8    3.90625
 LO BND1      Torque_12_8  -4.3879781566791554e+00
 UP BND1      Torque_12_8  19.53125
 BV BND1      T_12_9  
 UP BND1      F_12_9    5
 LO BND1      P_12_9    -5
 UP BND1      P_12_9    3.90625
 LO BND1      Torque_12_9  -25
 UP BND1      Torque_12_9  19.53125
 FX BND1      T_12_10   0
 BV BND1      T_12_10 
 FX BND1      F_12_10   0
 FX BND1      P_12_10   0
 FX BND1      Torque_12_10  0
 FX BND1      T_12_11   0
 BV BND1      T_12_11 
 FX BND1      F_12_11   0
 FX BND1      P_12_11   0
 FX BND1      Torque_12_11  0
 FX BND1      T_13_1    0
 BV BND1      T_13_1  
 FX BND1      F_13_1    0
 FX BND1      P_13_1    0
 FX BND1      Torque_13_1  0
 FX BND1      T_13_2    0
 BV BND1      T_13_2  
 FX BND1      F_13_2    0
 FX BND1      P_13_2    0
 FX BND1      Torque_13_2  0
 FX BND1      T_13_3    0
 BV BND1      T_13_3  
 FX BND1      F_13_3    0
 FX BND1      P_13_3    0
 FX BND1      Torque_13_3  0
 FX BND1      T_13_4    0
 BV BND1      T_13_4  
 FX BND1      F_13_4    0
 FX BND1      P_13_4    0
 FX BND1      Torque_13_4  0
 FX BND1      T_13_5    0
 BV BND1      T_13_5  
 FX BND1      F_13_5    0
 FX BND1      P_13_5    0
 FX BND1      Torque_13_5  0
 FX BND1      T_13_6    0
 BV BND1      T_13_6  
 FX BND1      F_13_6    0
 FX BND1      P_13_6    0
 FX BND1      Torque_13_6  0
 FX BND1      T_13_7    0
 BV BND1      T_13_7  
 FX BND1      F_13_7    0
 FX BND1      P_13_7    0
 FX BND1      Torque_13_7  0
 FX BND1      T_13_8    0
 BV BND1      T_13_8  
 FX BND1      F_13_8    0
 FX BND1      P_13_8    0
 FX BND1      Torque_13_8  0
 FX BND1      T_13_9    0
 BV BND1      T_13_9  
 FX BND1      F_13_9    0
 FX BND1      P_13_9    0
 FX BND1      Torque_13_9  0
 BV BND1      T_13_10 
 UP BND1      F_13_10   4
 UP BND1      P_13_10   5.90625
 UP BND1      Torque_13_10  23.625
 BV BND1      T_13_11 
 UP BND1      F_13_11   4
 UP BND1      P_13_11   4.90625
 UP BND1      Torque_13_11  19.625
 BV BND1      T_13_12 
 UP BND1      F_13_12   4
 UP BND1      P_13_12   3.90625
 UP BND1      Torque_13_12  15.625
 FX BND1      T_14_1    0
 BV BND1      T_14_1  
 FX BND1      F_14_1    0
 FX BND1      P_14_1    0
 FX BND1      Torque_14_1  0
 FX BND1      T_14_2    0
 BV BND1      T_14_2  
 FX BND1      F_14_2    0
 FX BND1      P_14_2    0
 FX BND1      Torque_14_2  0
 FX BND1      T_14_3    0
 BV BND1      T_14_3  
 FX BND1      F_14_3    0
 FX BND1      P_14_3    0
 FX BND1      Torque_14_3  0
 FX BND1      T_14_4    0
 BV BND1      T_14_4  
 FX BND1      F_14_4    0
 FX BND1      P_14_4    0
 FX BND1      Torque_14_4  0
 FX BND1      T_14_5    0
 BV BND1      T_14_5  
 FX BND1      F_14_5    0
 FX BND1      P_14_5    0
 FX BND1      Torque_14_5  0
 FX BND1      T_14_6    0
 BV BND1      T_14_6  
 FX BND1      F_14_6    0
 FX BND1      P_14_6    0
 FX BND1      Torque_14_6  0
 FX BND1      T_14_7    0
 BV BND1      T_14_7  
 FX BND1      F_14_7    0
 FX BND1      P_14_7    0
 FX BND1      Torque_14_7  0
 FX BND1      T_14_8    0
 BV BND1      T_14_8  
 FX BND1      F_14_8    0
 FX BND1      P_14_8    0
 FX BND1      Torque_14_8  0
 FX BND1      T_14_9    0
 BV BND1      T_14_9  
 FX BND1      F_14_9    0
 FX BND1      P_14_9    0
 FX BND1      Torque_14_9  0
 BV BND1      T_14_10 
 UP BND1      F_14_10   3
 UP BND1      P_14_10   5.90625
 UP BND1      Torque_14_10  17.71875
 BV BND1      T_14_11 
 UP BND1      F_14_11   3
 LO BND1      P_14_11   -5
 UP BND1      P_14_11   4.90625
 LO BND1      Torque_14_11  -15
 UP BND1      Torque_14_11  14.71875
 BV BND1      T_14_12 
 UP BND1      F_14_12   3
 LO BND1      P_14_12   -6
 UP BND1      P_14_12   3.90625
 LO BND1      Torque_14_12  -18
 UP BND1      Torque_14_12  11.71875
 FX BND1      T_14_13   0
 BV BND1      T_14_13 
 FX BND1      F_14_13   0
 FX BND1      P_14_13   0
 FX BND1      Torque_14_13  0
 FX BND1      T_15_1    0
 BV BND1      T_15_1  
 FX BND1      F_15_1    0
 FX BND1      P_15_1    0
 FX BND1      Torque_15_1  0
 FX BND1      T_15_2    0
 BV BND1      T_15_2  
 FX BND1      F_15_2    0
 FX BND1      P_15_2    0
 FX BND1      Torque_15_2  0
 FX BND1      T_15_3    0
 BV BND1      T_15_3  
 FX BND1      F_15_3    0
 FX BND1      P_15_3    0
 FX BND1      Torque_15_3  0
 FX BND1      T_15_4    0
 BV BND1      T_15_4  
 FX BND1      F_15_4    0
 FX BND1      P_15_4    0
 FX BND1      Torque_15_4  0
 FX BND1      T_15_5    0
 BV BND1      T_15_5  
 FX BND1      F_15_5    0
 FX BND1      P_15_5    0
 FX BND1      Torque_15_5  0
 FX BND1      T_15_6    0
 BV BND1      T_15_6  
 FX BND1      F_15_6    0
 FX BND1      P_15_6    0
 FX BND1      Torque_15_6  0
 FX BND1      T_15_7    0
 BV BND1      T_15_7  
 FX BND1      F_15_7    0
 FX BND1      P_15_7    0
 FX BND1      Torque_15_7  0
 FX BND1      T_15_8    0
 BV BND1      T_15_8  
 FX BND1      F_15_8    0
 FX BND1      P_15_8    0
 FX BND1      Torque_15_8  0
 FX BND1      T_15_9    0
 BV BND1      T_15_9  
 FX BND1      F_15_9    0
 FX BND1      P_15_9    0
 FX BND1      Torque_15_9  0
 BV BND1      T_15_10 
 UP BND1      F_15_10   2
 UP BND1      P_15_10   4.90625
 UP BND1      Torque_15_10  9.8125
 BV BND1      T_15_11 
 UP BND1      F_15_11   2
 LO BND1      P_15_11   -5
 UP BND1      P_15_11   4.90625
 LO BND1      Torque_15_11  -10
 UP BND1      Torque_15_11  9.8125
 BV BND1      T_15_12 
 UP BND1      F_15_12   2
 LO BND1      P_15_12   -6
 UP BND1      P_15_12   3.90625
 LO BND1      Torque_15_12  -12
 UP BND1      Torque_15_12  7.8125
 FX BND1      T_15_13   0
 BV BND1      T_15_13 
 FX BND1      F_15_13   0
 FX BND1      P_15_13   0
 FX BND1      Torque_15_13  0
 FX BND1      T_15_14   0
 BV BND1      T_15_14 
 FX BND1      F_15_14   0
 FX BND1      P_15_14   0
 FX BND1      Torque_15_14  0
 FX BND1      T_16_1    0
 BV BND1      T_16_1  
 FX BND1      F_16_1    0
 FX BND1      P_16_1    0
 FX BND1      Torque_16_1  0
 FX BND1      T_16_2    0
 BV BND1      T_16_2  
 FX BND1      F_16_2    0
 FX BND1      P_16_2    0
 FX BND1      Torque_16_2  0
 FX BND1      T_16_3    0
 BV BND1      T_16_3  
 FX BND1      F_16_3    0
 FX BND1      P_16_3    0
 FX BND1      Torque_16_3  0
 FX BND1      T_16_4    0
 BV BND1      T_16_4  
 FX BND1      F_16_4    0
 FX BND1      P_16_4    0
 FX BND1      Torque_16_4  0
 FX BND1      T_16_5    0
 BV BND1      T_16_5  
 FX BND1      F_16_5    0
 FX BND1      P_16_5    0
 FX BND1      Torque_16_5  0
 FX BND1      T_16_6    0
 BV BND1      T_16_6  
 FX BND1      F_16_6    0
 FX BND1      P_16_6    0
 FX BND1      Torque_16_6  0
 FX BND1      T_16_7    0
 BV BND1      T_16_7  
 FX BND1      F_16_7    0
 FX BND1      P_16_7    0
 FX BND1      Torque_16_7  0
 FX BND1      T_16_8    0
 BV BND1      T_16_8  
 FX BND1      F_16_8    0
 FX BND1      P_16_8    0
 FX BND1      Torque_16_8  0
 FX BND1      T_16_9    0
 BV BND1      T_16_9  
 FX BND1      F_16_9    0
 FX BND1      P_16_9    0
 FX BND1      Torque_16_9  0
 FX BND1      T_16_10   0
 BV BND1      T_16_10 
 FX BND1      F_16_10   0
 FX BND1      P_16_10   0
 FX BND1      Torque_16_10  0
 FX BND1      T_16_11   0
 BV BND1      T_16_11 
 FX BND1      F_16_11   0
 FX BND1      P_16_11   0
 FX BND1      Torque_16_11  0
 FX BND1      T_16_12   0
 BV BND1      T_16_12 
 FX BND1      F_16_12   0
 FX BND1      P_16_12   0
 FX BND1      Torque_16_12  0
 BV BND1      T_16_13 
 UP BND1      F_16_13   1
 UP BND1      P_16_13   6.90625
 UP BND1      Torque_16_13  6.90625
 BV BND1      T_16_14 
 UP BND1      F_16_14   1
 LO BND1      P_16_14   -6
 UP BND1      P_16_14   5.90625
 LO BND1      Torque_16_14  -6
 UP BND1      Torque_16_14  5.90625
 BV BND1      T_16_15 
 UP BND1      F_16_15   1
 LO BND1      P_16_15   -7
 UP BND1      P_16_15   4.90625
 LO BND1      Torque_16_15  -7
 UP BND1      Torque_16_15  4.90625
 FX BND1      LayerJump_1  1
 BV BND1      LayerJump_1
 FX BND1      LayerJump_2  0
 BV BND1      LayerJump_2
 FX BND1      LayerJump_3  1
 BV BND1      LayerJump_3
 FX BND1      LayerJump_4  0
 BV BND1      LayerJump_4
 FX BND1      LayerJump_5  1
 BV BND1      LayerJump_5
 FX BND1      LayerJump_6  0
 BV BND1      LayerJump_6
 FX BND1      LayerJump_7  1
 BV BND1      LayerJump_7
 FX BND1      LayerJump_8  0
 BV BND1      LayerJump_8
 FX BND1      LayerJump_9  1
 BV BND1      LayerJump_9
 FX BND1      LayerJump_10  0
 BV BND1      LayerJump_10
 FX BND1      LayerJump_11  0
 BV BND1      LayerJump_11
 FX BND1      LayerJump_12  1
 BV BND1      LayerJump_12
 FX BND1      LayerJump_13  0
 BV BND1      LayerJump_13
 FX BND1      LayerJump_14  0
 BV BND1      LayerJump_14
 FX BND1      LayerJump_15  1
 BV BND1      LayerJump_15
 LO BND1      RE_1      -16
 UP BND1      RE_1      16
 LO BND1      RE_2      -16
 UP BND1      RE_2      16
 LO BND1      RE_3      -16
 UP BND1      RE_3      16
 LO BND1      RE_4      -16
 UP BND1      RE_4      16
 LO BND1      RE_5      -16
 UP BND1      RE_5      16
 LO BND1      RE_6      -16
 UP BND1      RE_6      16
 LO BND1      RE_7      -16
 UP BND1      RE_7      16
 LO BND1      RE_8      -16
 UP BND1      RE_8      16
 LO BND1      RE_9      -16
 UP BND1      RE_9      16
 LO BND1      RE_10     -16
 UP BND1      RE_10     16
 LO BND1      RE_11     -16
 UP BND1      RE_11     16
 LO BND1      RE_12     -16
 UP BND1      RE_12     16
 LO BND1      RE_13     -16
 UP BND1      RE_13     16
 LO BND1      RE_14     -16
 UP BND1      RE_14     16
 LO BND1      RE_15     -16
 UP BND1      RE_15     16
 LO BND1      RE_16     -16
 UP BND1      RE_16     16
 LO BND1      max_overhang  0.5
 UP BND1      max_overhang  16
QCMATRIX   Bilinear_2_1
    F_2_1     P_2_1     -0.5
    P_2_1     F_2_1     -0.5
QCMATRIX   Bilinear_3_1
    F_3_1     P_3_1     -0.5
    P_3_1     F_3_1     -0.5
QCMATRIX   Bilinear_3_2
    F_3_2     P_3_2     -0.5
    P_3_2     F_3_2     -0.5
QCMATRIX   Bilinear_4_1
    F_4_1     P_4_1     -0.5
    P_4_1     F_4_1     -0.5
QCMATRIX   Bilinear_4_2
    F_4_2     P_4_2     -0.5
    P_4_2     F_4_2     -0.5
QCMATRIX   Bilinear_4_3
    F_4_3     P_4_3     -0.5
    P_4_3     F_4_3     -0.5
QCMATRIX   Bilinear_5_1
    F_5_1     P_5_1     -0.5
    P_5_1     F_5_1     -0.5
QCMATRIX   Bilinear_5_2
    F_5_2     P_5_2     -0.5
    P_5_2     F_5_2     -0.5
QCMATRIX   Bilinear_5_3
    F_5_3     P_5_3     -0.5
    P_5_3     F_5_3     -0.5
QCMATRIX   Bilinear_5_4
    F_5_4     P_5_4     -0.5
    P_5_4     F_5_4     -0.5
QCMATRIX   Bilinear_6_1
    F_6_1     P_6_1     -0.5
    P_6_1     F_6_1     -0.5
QCMATRIX   Bilinear_6_2
    F_6_2     P_6_2     -0.5
    P_6_2     F_6_2     -0.5
QCMATRIX   Bilinear_6_3
    F_6_3     P_6_3     -0.5
    P_6_3     F_6_3     -0.5
QCMATRIX   Bilinear_6_4
    F_6_4     P_6_4     -0.5
    P_6_4     F_6_4     -0.5
QCMATRIX   Bilinear_6_5
    F_6_5     P_6_5     -0.5
    P_6_5     F_6_5     -0.5
QCMATRIX   Bilinear_7_1
    F_7_1     P_7_1     -0.5
    P_7_1     F_7_1     -0.5
QCMATRIX   Bilinear_7_2
    F_7_2     P_7_2     -0.5
    P_7_2     F_7_2     -0.5
QCMATRIX   Bilinear_7_3
    F_7_3     P_7_3     -0.5
    P_7_3     F_7_3     -0.5
QCMATRIX   Bilinear_7_4
    F_7_4     P_7_4     -0.5
    P_7_4     F_7_4     -0.5
QCMATRIX   Bilinear_7_5
    F_7_5     P_7_5     -0.5
    P_7_5     F_7_5     -0.5
QCMATRIX   Bilinear_7_6
    F_7_6     P_7_6     -0.5
    P_7_6     F_7_6     -0.5
QCMATRIX   Bilinear_8_1
    F_8_1     P_8_1     -0.5
    P_8_1     F_8_1     -0.5
QCMATRIX   Bilinear_8_2
    F_8_2     P_8_2     -0.5
    P_8_2     F_8_2     -0.5
QCMATRIX   Bilinear_8_3
    F_8_3     P_8_3     -0.5
    P_8_3     F_8_3     -0.5
QCMATRIX   Bilinear_8_4
    F_8_4     P_8_4     -0.5
    P_8_4     F_8_4     -0.5
QCMATRIX   Bilinear_8_5
    F_8_5     P_8_5     -0.5
    P_8_5     F_8_5     -0.5
QCMATRIX   Bilinear_8_6
    F_8_6     P_8_6     -0.5
    P_8_6     F_8_6     -0.5
QCMATRIX   Bilinear_8_7
    F_8_7     P_8_7     -0.5
    P_8_7     F_8_7     -0.5
QCMATRIX   Bilinear_9_1
    F_9_1     P_9_1     -0.5
    P_9_1     F_9_1     -0.5
QCMATRIX   Bilinear_9_2
    F_9_2     P_9_2     -0.5
    P_9_2     F_9_2     -0.5
QCMATRIX   Bilinear_9_3
    F_9_3     P_9_3     -0.5
    P_9_3     F_9_3     -0.5
QCMATRIX   Bilinear_9_4
    F_9_4     P_9_4     -0.5
    P_9_4     F_9_4     -0.5
QCMATRIX   Bilinear_9_5
    F_9_5     P_9_5     -0.5
    P_9_5     F_9_5     -0.5
QCMATRIX   Bilinear_9_6
    F_9_6     P_9_6     -0.5
    P_9_6     F_9_6     -0.5
QCMATRIX   Bilinear_9_7
    F_9_7     P_9_7     -0.5
    P_9_7     F_9_7     -0.5
QCMATRIX   Bilinear_9_8
    F_9_8     P_9_8     -0.5
    P_9_8     F_9_8     -0.5
QCMATRIX   Bilinear_10_1
    F_10_1    P_10_1    -0.5
    P_10_1    F_10_1    -0.5
QCMATRIX   Bilinear_10_2
    F_10_2    P_10_2    -0.5
    P_10_2    F_10_2    -0.5
QCMATRIX   Bilinear_10_3
    F_10_3    P_10_3    -0.5
    P_10_3    F_10_3    -0.5
QCMATRIX   Bilinear_10_4
    F_10_4    P_10_4    -0.5
    P_10_4    F_10_4    -0.5
QCMATRIX   Bilinear_10_5
    F_10_5    P_10_5    -0.5
    P_10_5    F_10_5    -0.5
QCMATRIX   Bilinear_10_6
    F_10_6    P_10_6    -0.5
    P_10_6    F_10_6    -0.5
QCMATRIX   Bilinear_10_7
    F_10_7    P_10_7    -0.5
    P_10_7    F_10_7    -0.5
QCMATRIX   Bilinear_10_8
    F_10_8    P_10_8    -0.5
    P_10_8    F_10_8    -0.5
QCMATRIX   Bilinear_10_9
    F_10_9    P_10_9    -0.5
    P_10_9    F_10_9    -0.5
QCMATRIX   Bilinear_11_1
    F_11_1    P_11_1    -0.5
    P_11_1    F_11_1    -0.5
QCMATRIX   Bilinear_11_2
    F_11_2    P_11_2    -0.5
    P_11_2    F_11_2    -0.5
QCMATRIX   Bilinear_11_3
    F_11_3    P_11_3    -0.5
    P_11_3    F_11_3    -0.5
QCMATRIX   Bilinear_11_4
    F_11_4    P_11_4    -0.5
    P_11_4    F_11_4    -0.5
QCMATRIX   Bilinear_11_5
    F_11_5    P_11_5    -0.5
    P_11_5    F_11_5    -0.5
QCMATRIX   Bilinear_11_6
    F_11_6    P_11_6    -0.5
    P_11_6    F_11_6    -0.5
QCMATRIX   Bilinear_11_7
    F_11_7    P_11_7    -0.5
    P_11_7    F_11_7    -0.5
QCMATRIX   Bilinear_11_8
    F_11_8    P_11_8    -0.5
    P_11_8    F_11_8    -0.5
QCMATRIX   Bilinear_11_9
    F_11_9    P_11_9    -0.5
    P_11_9    F_11_9    -0.5
QCMATRIX   Bilinear_11_10
    F_11_10   P_11_10   -0.5
    P_11_10   F_11_10   -0.5
QCMATRIX   Bilinear_12_1
    F_12_1    P_12_1    -0.5
    P_12_1    F_12_1    -0.5
QCMATRIX   Bilinear_12_2
    F_12_2    P_12_2    -0.5
    P_12_2    F_12_2    -0.5
QCMATRIX   Bilinear_12_3
    F_12_3    P_12_3    -0.5
    P_12_3    F_12_3    -0.5
QCMATRIX   Bilinear_12_4
    F_12_4    P_12_4    -0.5
    P_12_4    F_12_4    -0.5
QCMATRIX   Bilinear_12_5
    F_12_5    P_12_5    -0.5
    P_12_5    F_12_5    -0.5
QCMATRIX   Bilinear_12_6
    F_12_6    P_12_6    -0.5
    P_12_6    F_12_6    -0.5
QCMATRIX   Bilinear_12_7
    F_12_7    P_12_7    -0.5
    P_12_7    F_12_7    -0.5
QCMATRIX   Bilinear_12_8
    F_12_8    P_12_8    -0.5
    P_12_8    F_12_8    -0.5
QCMATRIX   Bilinear_12_9
    F_12_9    P_12_9    -0.5
    P_12_9    F_12_9    -0.5
QCMATRIX   Bilinear_12_10
    F_12_10   P_12_10   -0.5
    P_12_10   F_12_10   -0.5
QCMATRIX   Bilinear_12_11
    F_12_11   P_12_11   -0.5
    P_12_11   F_12_11   -0.5
QCMATRIX   Bilinear_13_1
    F_13_1    P_13_1    -0.5
    P_13_1    F_13_1    -0.5
QCMATRIX   Bilinear_13_2
    F_13_2    P_13_2    -0.5
    P_13_2    F_13_2    -0.5
QCMATRIX   Bilinear_13_3
    F_13_3    P_13_3    -0.5
    P_13_3    F_13_3    -0.5
QCMATRIX   Bilinear_13_4
    F_13_4    P_13_4    -0.5
    P_13_4    F_13_4    -0.5
QCMATRIX   Bilinear_13_5
    F_13_5    P_13_5    -0.5
    P_13_5    F_13_5    -0.5
QCMATRIX   Bilinear_13_6
    F_13_6    P_13_6    -0.5
    P_13_6    F_13_6    -0.5
QCMATRIX   Bilinear_13_7
    F_13_7    P_13_7    -0.5
    P_13_7    F_13_7    -0.5
QCMATRIX   Bilinear_13_8
    F_13_8    P_13_8    -0.5
    P_13_8    F_13_8    -0.5
QCMATRIX   Bilinear_13_9
    F_13_9    P_13_9    -0.5
    P_13_9    F_13_9    -0.5
QCMATRIX   Bilinear_13_10
    F_13_10   P_13_10   -0.5
    P_13_10   F_13_10   -0.5
QCMATRIX   Bilinear_13_11
    F_13_11   P_13_11   -0.5
    P_13_11   F_13_11   -0.5
QCMATRIX   Bilinear_13_12
    F_13_12   P_13_12   -0.5
    P_13_12   F_13_12   -0.5
QCMATRIX   Bilinear_14_1
    F_14_1    P_14_1    -0.5
    P_14_1    F_14_1    -0.5
QCMATRIX   Bilinear_14_2
    F_14_2    P_14_2    -0.5
    P_14_2    F_14_2    -0.5
QCMATRIX   Bilinear_14_3
    F_14_3    P_14_3    -0.5
    P_14_3    F_14_3    -0.5
QCMATRIX   Bilinear_14_4
    F_14_4    P_14_4    -0.5
    P_14_4    F_14_4    -0.5
QCMATRIX   Bilinear_14_5
    F_14_5    P_14_5    -0.5
    P_14_5    F_14_5    -0.5
QCMATRIX   Bilinear_14_6
    F_14_6    P_14_6    -0.5
    P_14_6    F_14_6    -0.5
QCMATRIX   Bilinear_14_7
    F_14_7    P_14_7    -0.5
    P_14_7    F_14_7    -0.5
QCMATRIX   Bilinear_14_8
    F_14_8    P_14_8    -0.5
    P_14_8    F_14_8    -0.5
QCMATRIX   Bilinear_14_9
    F_14_9    P_14_9    -0.5
    P_14_9    F_14_9    -0.5
QCMATRIX   Bilinear_14_10
    F_14_10   P_14_10   -0.5
    P_14_10   F_14_10   -0.5
QCMATRIX   Bilinear_14_11
    F_14_11   P_14_11   -0.5
    P_14_11   F_14_11   -0.5
QCMATRIX   Bilinear_14_12
    F_14_12   P_14_12   -0.5
    P_14_12   F_14_12   -0.5
QCMATRIX   Bilinear_14_13
    F_14_13   P_14_13   -0.5
    P_14_13   F_14_13   -0.5
QCMATRIX   Bilinear_15_1
    F_15_1    P_15_1    -0.5
    P_15_1    F_15_1    -0.5
QCMATRIX   Bilinear_15_2
    F_15_2    P_15_2    -0.5
    P_15_2    F_15_2    -0.5
QCMATRIX   Bilinear_15_3
    F_15_3    P_15_3    -0.5
    P_15_3    F_15_3    -0.5
QCMATRIX   Bilinear_15_4
    F_15_4    P_15_4    -0.5
    P_15_4    F_15_4    -0.5
QCMATRIX   Bilinear_15_5
    F_15_5    P_15_5    -0.5
    P_15_5    F_15_5    -0.5
QCMATRIX   Bilinear_15_6
    F_15_6    P_15_6    -0.5
    P_15_6    F_15_6    -0.5
QCMATRIX   Bilinear_15_7
    F_15_7    P_15_7    -0.5
    P_15_7    F_15_7    -0.5
QCMATRIX   Bilinear_15_8
    F_15_8    P_15_8    -0.5
    P_15_8    F_15_8    -0.5
QCMATRIX   Bilinear_15_9
    F_15_9    P_15_9    -0.5
    P_15_9    F_15_9    -0.5
QCMATRIX   Bilinear_15_10
    F_15_10   P_15_10   -0.5
    P_15_10   F_15_10   -0.5
QCMATRIX   Bilinear_15_11
    F_15_11   P_15_11   -0.5
    P_15_11   F_15_11   -0.5
QCMATRIX   Bilinear_15_12
    F_15_12   P_15_12   -0.5
    P_15_12   F_15_12   -0.5
QCMATRIX   Bilinear_15_13
    F_15_13   P_15_13   -0.5
    P_15_13   F_15_13   -0.5
QCMATRIX   Bilinear_15_14
    F_15_14   P_15_14   -0.5
    P_15_14   F_15_14   -0.5
QCMATRIX   Bilinear_16_1
    F_16_1    P_16_1    -0.5
    P_16_1    F_16_1    -0.5
QCMATRIX   Bilinear_16_2
    F_16_2    P_16_2    -0.5
    P_16_2    F_16_2    -0.5
QCMATRIX   Bilinear_16_3
    F_16_3    P_16_3    -0.5
    P_16_3    F_16_3    -0.5
QCMATRIX   Bilinear_16_4
    F_16_4    P_16_4    -0.5
    P_16_4    F_16_4    -0.5
QCMATRIX   Bilinear_16_5
    F_16_5    P_16_5    -0.5
    P_16_5    F_16_5    -0.5
QCMATRIX   Bilinear_16_6
    F_16_6    P_16_6    -0.5
    P_16_6    F_16_6    -0.5
QCMATRIX   Bilinear_16_7
    F_16_7    P_16_7    -0.5
    P_16_7    F_16_7    -0.5
QCMATRIX   Bilinear_16_8
    F_16_8    P_16_8    -0.5
    P_16_8    F_16_8    -0.5
QCMATRIX   Bilinear_16_9
    F_16_9    P_16_9    -0.5
    P_16_9    F_16_9    -0.5
QCMATRIX   Bilinear_16_10
    F_16_10   P_16_10   -0.5
    P_16_10   F_16_10   -0.5
QCMATRIX   Bilinear_16_11
    F_16_11   P_16_11   -0.5
    P_16_11   F_16_11   -0.5
QCMATRIX   Bilinear_16_12
    F_16_12   P_16_12   -0.5
    P_16_12   F_16_12   -0.5
QCMATRIX   Bilinear_16_13
    F_16_13   P_16_13   -0.5
    P_16_13   F_16_13   -0.5
QCMATRIX   Bilinear_16_14
    F_16_14   P_16_14   -0.5
    P_16_14   F_16_14   -0.5
QCMATRIX   Bilinear_16_15
    F_16_15   P_16_15   -0.5
    P_16_15   F_16_15   -0.5
ENDATA
